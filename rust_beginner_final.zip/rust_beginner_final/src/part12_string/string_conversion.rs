// ┌─────────────────────────────────────────────────────────────────────┐
// │  문자열 타입 변환 흐름도                                              │
// │                                                                     │
// │  &str ──to_string()──▶ String                                       │
// │  &str ──String::from()──▶ String                                    │
// │  String ──as_str()──▶ &str                                          │
// │  String ──&s[..]──▶ &str                                            │
// │                                                                     │
// │  숫자 ↔ 문자열:                                                     │
// │  42_i32 ──to_string()──▶ "42"                                       │
// │  "42" ──parse::<i32>()──▶ Ok(42)                                    │
// │  "abc" ──parse::<i32>()──▶ Err(ParseIntError)                       │
// │                                                                     │
// │  bytes ↔ String:                                                    │
// │  "hello" ──as_bytes()──▶ [104,101,108,108,111]                      │
// │  bytes ──from_utf8()──▶ Ok(&str) / Err                              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 12-3: 문자열 변환
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [12-3: 문자열 변환]");
    demo_parse();
    demo_number_to_string();
    demo_utf8();
}

fn demo_parse() {
    println!("\n  ── parse: 문자열 → 숫자 ──");

    // parse::<T>() 또는 타입 어노테이션으로 추론
    let age: u32 = "5".parse().unwrap();
    let weight: f64 = "190.5".parse().unwrap();
    println!("  나이: {}, 체중: {}", age, weight);

    // 실패 처리
    let bad: Result<u32, _> = "abc".parse();
    println!("  잘못된 파싱: {:?}", bad);

    // 여러 필드 파싱
    let data = "Simba 5 190.5";
    let parts: Vec<&str> = data.split_whitespace().collect();
    if parts.len() == 3 {
        let name = parts[0];
        let age: u32 = parts[1].parse().unwrap_or(0);
        let weight: f64 = parts[2].parse().unwrap_or(0.0);
        println!("  파싱: {} {}살 {}kg", name, age, weight);
    }
}

fn demo_number_to_string() {
    println!("\n  ── 숫자 → 문자열 ──");

    let age: u32 = 5;
    let weight: f64 = 190.567;

    // to_string()
    println!("  to_string: {}", age.to_string());

    // format!: 포매팅 지정
    println!("  format 소수점2: {:.2}", weight);
    println!("  format 정수: {}", weight as u32);
    println!("  format 패딩: {:>10}", age);    // 오른쪽 정렬
    println!("  format 패딩: {:<10}", age);    // 왼쪽 정렬
    println!("  format 0패딩: {:05}", age);    // 0으로 패딩
    println!("  format 16진수: {:x}", 255u32); // ff
    println!("  format 2진수: {:b}", 10u32);   // 1010
}

fn demo_utf8() {
    println!("\n  ── UTF-8과 문자 ──");

    let korean = "사자";
    println!("  '사자' 바이트: {}", korean.len());       // 6 (3×2)
    println!("  '사자' 문자수: {}", korean.chars().count()); // 2

    // 바이트 단위 접근
    let bytes: Vec<u8> = korean.bytes().collect();
    println!("  바이트: {:?}", bytes);

    // chars(): 유니코드 스칼라값 이터레이터
    for (i, c) in "Simba".chars().enumerate() {
        print!("  [{}]'{}'", i, c);
    }
    println!();

    // 문자열이 유효한 UTF-8인지
    let valid = std::str::from_utf8(&[0xEC, 0x82, 0xAC]); // "사"
    println!("  from_utf8: {:?}", valid);
}
