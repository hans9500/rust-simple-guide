// ┌──────────────────────────────────────────────────────────────────
// │ Part 12: 문자열 완전 가이드
// │
// │ 공식 문서: Rust Book Ch.8.2, std::str, std::string
// │
// │ Rust의 문자열 타입:
// │   &str    — 문자열 슬라이스 (참조, 고정 크기)
// │   String  — 소유된 문자열 (힙, 가변)
// │   &String — String에 대한 참조 (거의 &str로 대신함)
// │   str     — DST, 직접 사용 불가 (항상 &str 형태로)
// └──────────────────────────────────────────────────────────────────

pub mod string_types;
pub mod string_ops;
pub mod string_conversion;
pub mod string_advanced;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 12: 문자열 완전 가이드");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    string_types::run();
    string_ops::run();
    string_conversion::run();
    string_advanced::run();
}
