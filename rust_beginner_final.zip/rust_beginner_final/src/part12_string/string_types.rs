// ┌─────────────────────────────────────────────────────────────────────┐
// │  String vs &str 메모리 구조                                          │
// │                                                                     │
// │  let s = String::from("hello");                                     │
// │  스택:  [ ptr │ len:5 │ cap:5 ]                                     │
// │            │                                                        │
// │            └──▶ 힙: [ h │ e │ l │ l │ o ]                          │
// │                                                                     │
// │  let s2: &str = &s[1..3];   // "el"                                │
// │  스택:  [ ptr │ len:2 ]                                             │
// │            │                                                        │
// │            └──▶ 힙: [ h │[e │ l]│ l │ o ]  (일부 참조)             │
// │                                                                     │
// │  String: 힙에 소유, 가변, 크기 변경 가능                             │
// │  &str:   어딘가를 참조, 불변, 크기 고정                              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 12-1: &str vs String vs &String vs str
// │
// │ str:     동적 크기 타입(DST). 메모리 어딘가의 UTF-8 바이트 시퀀스.
// │           직접 사용 불가, 항상 참조(&str)로 접근.
// │
// │ &str:    str에 대한 참조 = fat pointer (ptr + len).
// │           스택, 데이터 세그먼트(리터럴), 힙 어디든 가리킬 수 있음.
// │           불변, 크기 불변.
// │
// │ String:  힙에 할당된 소유된 문자열.
// │           내부: ptr + len + capacity (Vec<u8> 기반).
// │           가변, 크기 가변.
// │
// │ &String: String에 대한 참조. 거의 항상 &str로 대신 사용.
// │           Deref 강제변환: &String → &str 자동 변환.
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [12-1: 문자열 타입]");
    demo_str_literal();
    demo_string_heap();
    demo_deref_coercion();
    demo_when_to_use();
}

fn demo_str_literal() {
    println!("\n  ── &str: 문자열 리터럴 ──");

    // 리터럴은 바이너리의 데이터 세그먼트에 저장됨
    // 'static lifetime: 프로그램 실행 내내 유효
    let name: &'static str = "Simba";
    let species: &str       = "사자";     // 'static 생략 가능

    println!("  이름: {}, 종: {}", name, species);
    println!("  &str 크기: {} bytes (ptr+len)", std::mem::size_of::<&str>());

    // &str은 슬라이싱 가능
    let full = "안녕하세요 동물원";
    // 바이트 인덱스로 슬라이스 — UTF-8 경계여야 함
    let greeting = &full[..15];  // "안녕하세요" (한글 3바이트 × 5)
    println!("  슬라이스: '{}'", greeting);

    // chars()로 문자 단위 접근 (UTF-8 안전)
    let char_count = full.chars().count();
    println!("  문자 수: {}", char_count);
}

fn demo_string_heap() {
    println!("\n  ── String: 힙 할당, 소유 ──");

    // String 생성 방법들
    let s1 = String::new();                        // 빈 String
    let s2 = String::from("Simba");                // &str → String
    let s3 = "Donald".to_string();                 // &str → String
    let s4 = "Nagini".to_owned();                  // &str → String
    let s5 = format!("{} 와 {}", s2, "Nala");      // 포매팅

    println!("  new(): {:?}", s1);
    println!("  from(): {}", s2);
    println!("  to_string(): {}", s3);
    println!("  to_owned(): {}", s4);
    println!("  format!(): {}", s5);

    // String 내부 구조
    let mut s = String::with_capacity(10);
    println!("  len={}, cap={}", s.len(), s.capacity());
    s.push_str("안녕");
    s.push('!');
    println!("  push 후: '{}', len={}", s, s.len());
    println!("  String 크기: {} bytes (ptr+len+cap)",
             std::mem::size_of::<String>());
}

fn demo_deref_coercion() {
    println!("\n  ── Deref 강제변환: &String → &str ──");

    let owned = String::from("서울 동물원");

    // &String은 자동으로 &str로 변환 (Deref 강제변환)
    print_str(&owned);      // &String → &str 자동 변환
    print_str("부산 동물원"); // &str 그대로

    // 함수 시그니처: &str 권장 (더 유연)
    fn print_str(s: &str) {
        println!("  동물원: {}", s);
    }

    // &String을 명시적으로 &str로
    let s_ref: &str = &owned;
    let s_ref2: &str = owned.as_str();
    println!("  명시적 변환: {}, {}", s_ref, s_ref2);
}

fn demo_when_to_use() {
    println!("\n  ── 언제 무엇을 쓰나 ──");

    //  &str  → 읽기 전용, 함수 파라미터, 리터럴
    //  String → 소유, 수정 필요, 반환값, 구조체 필드

    // 함수 파라미터: &str 권장 (String도 받을 수 있음)
    fn greet(name: &str) -> String {
        format!("안녕, {}!", name)
    }

    let owned_name = String::from("Simba");
    let literal_name = "Donald";

    println!("  {}", greet(&owned_name));   // &String → &str
    println!("  {}", greet(literal_name));  // &str 그대로

    // 구조체 필드: 소유권이 있어야 하면 String
    struct Animal {
        name:    String,   // 소유 — 구조체가 독립적
        species: String,
    }
    let lion = Animal {
        name:    String::from("Simba"),
        species: "사자".to_string(),
    };
    println!("  구조체: {} ({})", lion.name, lion.species);

    // 반환값: 새로 만든 문자열은 String
    fn make_tag(animal: &str) -> String {
        format!("[{}]", animal)  // 새 String 반환
    }
    println!("  태그: {}", make_tag("사자"));

    // &str 반환: 입력의 일부를 반환할 때
    fn first_word(s: &str) -> &str {
        match s.find(' ') {
            Some(i) => &s[..i],
            None    => s,
        }
    }
    println!("  첫 단어: '{}'", first_word("사자 Simba 5살"));
}
