// ┌─────────────────────────────────────────────────────────────────────┐
// │  String 주요 조작 흐름                                               │
// │                                                                     │
// │  push_str / push:  String에 추가                                    │
// │    "hello" ──push_str(" world")──▶ "hello world"                   │
// │                                                                     │
// │  +  연산자:  String + &str  (왼쪽 소유권 이동)                       │
// │    s1 + &s2  →  s1 소비,  새 String 반환                            │
// │                                                                     │
// │  format!:  소유권 이동 없이 결합                                      │
// │    format!("{}-{}", s1, s2)  →  s1, s2 모두 유효                    │
// │                                                                     │
// │  split / join:                                                      │
// │    "a,b,c".split(',')  →  ["a","b","c"]                             │
// │    ["a","b","c"].join("-")  →  "a-b-c"                              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 12-2: 문자열 조작
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [12-2: 문자열 조작]");
    demo_modify();
    demo_search();
    demo_split_join();
}

fn demo_modify() {
    println!("\n  ── 수정 ──");

    let mut s = String::from("안녕 동물원");

    s.push_str(" 방문");
    s.push('!');
    println!("  push 후: {}", s);

    // replace: 새 String 반환 (원본 불변)
    let replaced = s.replace("동물원", "서울 동물원");
    println!("  replace: {}", replaced);

    // 대소문자
    let eng = "Hello Zoo";
    println!("  upper: {}", eng.to_uppercase());
    println!("  lower: {}", eng.to_lowercase());

    // trim: 공백 제거
    let padded = "  Simba  ";
    println!("  trim: '{}'", padded.trim());
    println!("  trim_start: '{}'", padded.trim_start());
}

fn demo_search() {
    println!("\n  ── 검색 ──");

    let text = "사자 Simba는 서울 동물원의 사자입니다.";

    println!("  contains '사자': {}", text.contains("사자"));
    println!("  starts_with: {}", text.starts_with("사자"));
    println!("  ends_with: {}", text.ends_with("입니다."));
    println!("  find '동물원': {:?}", text.find("동물원"));
    println!("  '사자' 개수: {}", text.matches("사자").count());
}

fn demo_split_join() {
    println!("\n  ── split / join ──");

    let csv = "Simba,5,사자,190.0";
    let fields: Vec<&str> = csv.split(',').collect();
    println!("  split: {:?}", fields);

    let lines = "사자\n오리\n뱀";
    let animals: Vec<&str> = lines.lines().collect();
    println!("  lines: {:?}", animals);

    // join
    let joined = animals.join(" | ");
    println!("  join: {}", joined);

    // splitn: 최대 n개로 분리
    let limited: Vec<&str> = csv.splitn(3, ',').collect();
    println!("  splitn(3): {:?}", limited);
}
