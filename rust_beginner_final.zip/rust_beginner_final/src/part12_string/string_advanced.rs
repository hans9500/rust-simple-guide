// ┌─────────────────────────────────────────────────────────────────────┐
// │  UTF-8 인덱싱 주의사항                                               │
// │                                                                     │
// │  let s = "안녕";   // 한글: 3바이트 × 2 = 6바이트                   │
// │                                                                     │
// │  s[0]      → 컴파일 에러 (바이트 인덱싱 불가)                        │
// │  s[0..2]   → 런타임 패닉 (문자 경계 아님)                            │
// │  s[0..3]   → "안" (첫 번째 문자, 3바이트)                            │
// │                                                                     │
// │  올바른 문자 순회:                                                   │
// │  s.chars()      → '안', '녕'  (문자 단위)                           │
// │  s.bytes()      → 6개 바이트  (바이트 단위)                         │
// │  s.char_indices()→ (0,'안'), (3,'녕')  (인덱스+문자)               │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 12-4: 문자열 심화
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [12-4: 문자열 심화]");
    demo_common_mistakes();
    demo_string_building();
}

fn demo_common_mistakes() {
    println!("\n  ── 흔한 실수 ──");

    // 실수1: &str 인덱스 접근 (UTF-8 경계 주의)
    let s = "hello";
    // s[0] // 컴파일 에러: cannot index into &str
    let first = &s[0..1]; // OK: 바이트 인덱스
    println!("  바이트 슬라이스: '{}'", first);

    // 안전한 방법: chars().nth()
    let ch = "사자".chars().nth(0);
    println!("  chars().nth(0): {:?}", ch);

    // 실수2: String + &str 연산
    let s1 = String::from("Hello");
    let s2 = String::from(" Zoo");
    let s3 = s1 + &s2;  // s1 소유권 이동
    // println!("{}", s1); // 에러: s1 moved
    println!("  + 연산: {}", s3);

    // 여러 개 합칠 때는 format! 권장
    let a = String::from("사자");
    let b = String::from("오리");
    let c = String::from("뱀");
    let combined = format!("{}, {}, {}", a, b, c);
    println!("  format!: {}", combined);
    // a, b, c 모두 여전히 유효
    println!("  원본 유효: {}, {}, {}", a, b, c);
}

fn demo_string_building() {
    println!("\n  ── 효율적인 문자열 구성 ──");

    // String::with_capacity: 재할당 최소화
    let animals = ["사자", "오리", "뱀", "코끼리"];
    let mut result = String::with_capacity(64);
    for (i, animal) in animals.iter().enumerate() {
        if i > 0 { result.push_str(", "); }
        result.push_str(animal);
    }
    println!("  구성 결과: {}", result);

    // join이 더 간결
    let joined = animals.join(", ");
    println!("  join: {}", joined);

    // collect::<String>
    let collected: String = animals.iter()
        .map(|&a| format!("[{}]", a))
        .collect::<Vec<_>>()
        .join(" ");
    println!("  collect: {}", collected);
}
