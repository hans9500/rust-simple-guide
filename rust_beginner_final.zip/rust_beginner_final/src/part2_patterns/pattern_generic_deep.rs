// ┌─────────────────────────────────────────────────────────────────────┐
// │  제네릭 심화 — 단형화, 축약 해제, 실전 예제                           │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  단형화(Monomorphization) 코드 생성 흐름                             │
// │                                                                     │
// │  작성:  fn max<T: PartialOrd>(a: T, b: T) -> T { ... }             │
// │                                                                     │
// │  사용:  max(1_i32, 2)   → T = i32  발견                             │
// │         max(1.0_f64, 2.0) → T = f64 발견                            │
// │                                                                     │
// │  생성:  fn max_i32(a: i32, b: i32) -> i32 { ... }                  │
// │         fn max_f64(a: f64, b: f64) -> f64 { ... }                  │
// │                                                                     │
// │  런타임: vtable 없음, 인라인 최적화 가능 → C 수준 성능               │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  impl Trait 축약 해제(Desugaring) 3단계                              │
// │                                                                     │
// │  ① fn f(x: impl Sound) -> impl Sound                               │
// │          ↓ 축약 해제                                                │
// │  ② fn f<T: Sound>(x: T) -> impl Sound                              │
// │          ↓ where 절                                                 │
// │  ③ fn f<T>(x: T) -> impl Sound where T: Sound                      │
// │                                                                     │
// │  세 가지 모두 동일한 코드 생성 → 단형화 → 정적 디스패치              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  제네릭 구조체 — 타입별 독립 구현                                     │
// │                                                                     │
// │  struct Cage<T> { animal: T }                                       │
// │                                                                     │
// │  impl<T> Cage<T>            → T 무관 항상 존재                      │
// │  impl<T: Sound> Cage<T>     → T가 Sound일 때만                      │
// │  impl<T: Display> Cage<T>   → T가 Display일 때만                    │
// │                                                                     │
// │  컴파일러가 타입별로:                                                 │
// │    Cage<Lion> { ... impl Sound 메서드 포함 }                         │
// │    Cage<Duck> { ... impl Sound 메서드 포함 }                         │
// └─────────────────────────────────────────────────────────────────────┘

use std::fmt;

#[allow(unused_imports)]
use crate::part2_patterns::animals::{Lion, Duck};
#[allow(unused_imports)]
use crate::part2_patterns::pattern2_trait::Sound;

pub fn run() {
    println!("\n  [제네릭 심화]");
    demo_monomorphization();
    demo_desugar();
    demo_generic_struct();
    demo_multiple_bounds();
    demo_generic_return();
}

fn demo_monomorphization() {
    println!("\n  ── 단형화: 컴파일러가 타입별 함수 생성 ──");

    // 제네릭 함수 하나
    fn largest<T: PartialOrd>(a: T, b: T) -> T {
        if a > b { a } else { b }
    }

    // 컴파일러가 largest_i32, largest_f64, largest_str 각각 생성
    println!("  largest(3, 7): {}", largest(3i32, 7));
    println!("  largest(3.14, 2.72): {}", largest(3.14f64, 2.72));
    println!("  largest(\"사자\", \"오리\"): {}", largest("사자", "오리"));

    // 각 호출은 독립된 함수 → vtable 없음
    println!("  → 세 호출 모두 별도 함수로 컴파일됨");
}

fn demo_desugar() {
    println!("\n  ── 축약 해제(Desugaring) ──");

    // 방법 1: impl Trait (가장 간결)
    fn describe1(animal: impl Sound) -> String {
        animal.make_sound()
    }

    // 방법 2: 타입 파라미터
    fn describe2<T: Sound>(animal: T) -> String {
        animal.make_sound()
    }

    // 방법 3: where 절
    fn describe3<T>(animal: T) -> String
    where T: Sound
    {
        animal.make_sound()
    }

    // 세 함수 모두 동일 동작
    let lion = Lion::new("Simba", 5);
    println!("  impl Trait: {}", describe1(Lion::new("A", 1)));
    println!("  <T:Bound>:  {}", describe2(Lion::new("B", 1)));
    println!("  where:      {}", describe3(Lion::new("C", 1)));
    println!("  모두 동일한 코드 생성 → lion: {}", lion.make_sound());
}

fn demo_generic_struct() {
    println!("\n  ── 제네릭 구조체 조건부 impl ──");

    struct Cage<T> {
        animal: T,
        id: u32,
    }

    // T 무관 — 항상 존재
    impl<T> Cage<T> {
        fn new(animal: T, id: u32) -> Self {
            Cage { animal, id }
        }
        fn id(&self) -> u32 { self.id }
    }

    // T: Sound — Sound 구현체만
    impl<T: Sound> Cage<T> {
        fn make_sound(&self) -> String {
            self.animal.make_sound()
        }
    }

    // T: fmt::Display — Display 구현체만
    impl<T: fmt::Display> fmt::Display for Cage<T> {
        fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
            write!(f, "[우리#{}] {}", self.id, self.animal)
        }
    }

    let lion_cage = Cage::new(Lion::new("Simba", 5), 1);
    let duck_cage = Cage::new(Duck::new("Donald", 3), 2);

    println!("  lion_cage id: {}", lion_cage.id());
    println!("  lion 소리: {}", lion_cage.make_sound());
    println!("  Display: {}", lion_cage);
    println!("  duck 소리: {}", duck_cage.make_sound());
}

fn demo_multiple_bounds() {
    println!("\n  ── 복수 바운드 + where ──");

    fn print_and_sound<T>(animal: T)
    where
        T: Sound + fmt::Display + Clone,
    {
        let copy = animal.clone();
        println!("  표시: {}", animal);
        println!("  소리: {}", copy.make_sound());
    }

    print_and_sound(Lion::new("Simba", 5));
    print_and_sound(Duck::new("Donald", 3));

    // 연관 타입 바운드 — where만 가능
    fn print_items<I>(iter: I)
    where
        I: Iterator,
        I::Item: fmt::Display,
    {
        for item in iter { print!("  {} ", item); }
        println!();
    }

    print_items(vec!["사자", "오리", "뱀"].into_iter());
    print_items(vec![1u32, 2, 3].into_iter());
}

fn demo_generic_return() {
    println!("\n  ── -> impl Trait 반환 ──");

    // 클로저 반환 — 타입 이름 없으므로 impl Fn 사용
    fn make_greeter(zoo_name: &str) -> impl Fn(&str) -> String + '_ {
        move |animal| format!("[{}] {} 환영!", zoo_name, animal)
    }

    let greet = make_greeter("서울동물원");
    println!("  {}", greet("사자"));
    println!("  {}", greet("오리"));

    // Iterator 반환 — 복잡한 타입 숨김
    fn adult_animals<'a>(animals: &'a [(&'a str, u32)]) -> Vec<&'a str> {
        animals.iter()
            .filter(|(_, age)| *age >= 5)
            .map(|(name, _)| *name)
            .collect()
    }

    let data = vec![("Simba",5u32),("Donald",3),("Nagini",8)];
    println!("  성체: {:?}", adult_animals(&data));
}
