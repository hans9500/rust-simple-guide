// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 2 심화.  impl 패턴 고급 — 컴파일 에러 해부와 실수 패턴            │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;

// ─── 심화 1: object safety — dyn Trait이 되려면 ──────────────────────────
//
//  dyn Trait을 만들려면 trait이 "object-safe"해야 한다.
//  vtable에 함수 포인터를 넣을 수 없으면 object-safe하지 않다.
//
//  object-safe 조건:
//    1. 모든 메서드의 반환 타입이 Self가 아닐 것
//    2. 모든 메서드가 제네릭 타입 파라미터를 가지지 않을 것
//    3. self 없는 연관 함수가 없을 것 (단, where Self: Sized 로 제외 가능)
//
//  [위반 예 1] Clone — Self 반환:
//  trait Clone {
//      fn clone(&self) -> Self;   // Self 반환 → object-safe 아님
//  }
//  let x: &dyn Clone = &5;       // ← 컴파일 에러
//  // 에러: the trait `Clone` cannot be made into an object
//  // note: method `clone` references the `Self` type in its return type
//
//  왜 불가능한가:
//    vtable의 clone 포인터는 fn(*const ()) -> ??? 형태여야 하는데
//    반환 타입이 Self(= Lion or Duck or ...) → 크기를 모름 → vtable 불가
//
//  해결 1: where Self: Sized 로 dyn에서 제외
//  trait MyClone {
//      fn clone_box(&self) -> Box<dyn MyClone>;  // Box로 감싸서 크기 확정
//      fn clone_copy(&self) -> Self where Self: Sized;  // Sized 제약 → dyn 제외
//  }
//
//  [위반 예 2] 제네릭 메서드:
//  trait Comparable {
//      fn compare<T>(&self, other: T) -> bool;  // 제네릭 → vtable 불가
//  }
//  // vtable에 compare::<Lion>, compare::<Duck>, ... 무한히 넣을 수 없음

// object-safe trait
trait ObjectSafeTrait {
    fn describe(&self) -> String;           // OK: &self, 구체 반환
    fn print(&self) { println!("{}", self.describe()); } // OK: 기본 구현
}

// object-safe + where Self: Sized로 dyn 제외
// clone_box: Box<dyn ClonableSound> 반환 → 크기 확정 → object-safe
// type_name: where Self: Sized → dyn에서 제외 → vtable에 없음
trait ClonableSound: Sound {
    fn clone_box(&self) -> Box<dyn ClonableSound>;
    fn type_name(&self) -> &'static str where Self: Sized;
}

impl ClonableSound for Lion {
    fn clone_box(&self) -> Box<dyn ClonableSound> {
        Box::new(self.clone())  // Lion: Clone 구현 → clone_box 가능
    }
    fn type_name(&self) -> &'static str where Self: Sized {
        "Lion"  // where Self: Sized 제약 → dyn ClonableSound로는 호출 불가
    }
}

impl ClonableSound for Snake {
    fn clone_box(&self) -> Box<dyn ClonableSound> {
        Box::new(self.clone())
    }
    fn type_name(&self) -> &'static str where Self: Sized {
        "Snake"
    }
}

impl ObjectSafeTrait for Lion {
    fn describe(&self) -> String { format!("사자 {}", self.name()) }
}
impl ObjectSafeTrait for Snake {
    fn describe(&self) -> String {
        format!("뱀 {} ({})", self.name(), if self.is_venomous() { "독" } else { "무독" })
    }
}

fn demo_object_safety() {
    println!("\n  [심화1: object safety]");

    // object-safe trait → dyn 가능
    let animals: Vec<Box<dyn ObjectSafeTrait>> = vec![
        Box::new(Lion::new("Simba", 5)),
        Box::new(Snake::new("Nagini", 8, true)),
    ];
    for a in &animals {
        a.print();
    }

    // ClonableSound — clone_box 실제 호출
    println!("\n  [ClonableSound — clone_box 사용]");
    let original: Box<dyn ClonableSound> = Box::new(Lion::new("Simba", 5));
    let cloned = original.clone_box();   // clone_box: object-safe → dyn으로 호출 가능
    println!("  original: {}", original.make_sound());
    println!("  cloned:   {}", cloned.make_sound());
    // type_name()은 where Self: Sized → dyn으로 호출 불가
    // Lion::type_name(&simba) 처럼 구체 타입으로만 호출 가능
    let simba = Lion::new("Simba", 5);
    println!("  type_name (구체 타입으로만): {}", simba.type_name());

    // 크기 확인 — fat pointer = 16바이트
    println!("\n  [fat pointer 크기]");
    println!("  size_of::<&Lion>():         {} bytes", std::mem::size_of::<&Lion>());
    println!("  size_of::<&dyn Sound>():    {} bytes", std::mem::size_of::<&dyn Sound>());
    println!("  size_of::<Box<dyn Sound>>(): {} bytes", std::mem::size_of::<Box<dyn Sound>>());
    // 결과: &Lion=8, &dyn Sound=16, Box<dyn Sound>=16
    // → fat pointer = data_ptr(8) + vtable_ptr(8) = 16
}

// ─── 심화 2: 블랭킷 구현 충돌 ────────────────────────────────────────────
//
//  impl<T: Sound> Announce for T { ... }  // 블랭킷
//  impl Announce for Lion { ... }         // 특정 타입
//
//  이 두 impl이 동시에 존재하면 컴파일 에러:
//  error[E0119]: conflicting implementations of trait `Announce` for type `Lion`
//
//  왜 에러인가:
//    Lion은 Sound를 구현함 → 블랭킷이 Lion에 적용
//    별도 impl도 Lion에 적용
//    → 어느 것을 쓸지 모호 (컴파일러가 선택할 수 없음)
//
//  해결: 블랭킷과 특정 구현 중 하나만 사용.
//  특정 타입의 동작을 다르게 하려면:
//    - 블랭킷의 기본 구현을 오버라이드
//    - 또는 다른 trait을 정의

trait Reportable {
    fn report(&self) -> String;
    // 기본 구현 제공 → 블랭킷에서 오버라이드 가능
    fn full_report(&self) -> String {
        format!("[기본 리포트] {}", self.report())
    }
}

// 블랭킷 구현
impl<T: Sound> Reportable for T {
    fn report(&self) -> String {
        format!("소리: {}", self.make_sound())
    }
    // full_report는 기본 구현 사용
}

// Lion에 대해 full_report를 다르게 하고 싶다면:
// impl Reportable for Lion은 안 됨 (블랭킷과 충돌)
// 대신: 별도 메서드나 별도 trait 사용

fn demo_blanket_conflict() {
    println!("\n  [심화2: 블랭킷 구현 충돌 방지]");

    let simba  = Lion::new("Simba", 5);
    let nagini = Snake::new("Nagini", 8, true);

    println!("  Lion report: {}", simba.report());
    println!("  Snake report: {}", nagini.report());
    println!("  Lion full: {}", simba.full_report());
}

// ─── 심화 3: 연관 타입 vs 제네릭 trait — 호출자 관점 차이 ──────────────
//
//  제네릭 trait: trait Feed<F>
//    호출자가 F를 명시해야 할 때가 있음:
//    let lion: &dyn Feed<Meat> = &simba;   // F를 명시
//    let lion2: &dyn Feed<Fish> = &simba;  // 다른 F로 또 가능
//    → 같은 타입이 여러 impl을 가질 때 좋음
//
//  연관 타입: trait Iterator { type Item; }
//    호출자가 타입을 명시하지 않아도 됨:
//    fn process<T: Iterator>(iter: T) { ... }
//    // T::Item은 컴파일러가 추론
//    → 하나의 impl만 가질 때 좋음 (Iterator는 Item이 하나)
//
//  제네릭 trait을 dyn으로 쓸 때:
//    &dyn Iterator         → OK (Item은 연관 타입, 구체 타입은 vtable에 포함)
//    &dyn Feed<Meat>       → OK (Meat를 명시해야 함)
//    &dyn Feed             → 에러 (F가 뭔지 모름)
//
//  where 절의 연관 타입 바운드:
//    fn f<T>(iter: T) where T: Iterator, T::Item: Display { ... }
//    // "T의 Item이 Display를 구현해야 한다"

fn demo_assoc_vs_generic() {
    println!("\n  [심화3: 연관 타입 vs 제네릭 trait]");

    // Iterator — 연관 타입. T::Item 바운드.
    fn print_all<T: Iterator>(mut iter: T)
    where
        T::Item: fmt::Display,  // 연관 타입에 바운드
    {
        for item in &mut iter {
            print!("  {} ", item);
        }
        println!();
    }

    let names = vec!["Simba", "Nala", "Mufasa"];
    print!("  Iterator::Item: ");
    print_all(names.iter());

    // 제네릭 trait — F를 명시해야 함
    use crate::part2_patterns::pattern5_generic_trait::{Feed, Meat, Fish};

    fn feed_meat(animal: &mut impl Feed<Meat>) {
        animal.eat(Meat { weight_kg: 3.0 });
    }
    fn feed_fish(animal: &mut impl Feed<Fish>) {
        animal.eat(Fish { count: 2 });
    }

    let mut simba = Lion::new("Simba", 5);
    feed_meat(&mut simba);
    feed_fish(&mut simba);
}

// ─── 심화 4: 제네릭 타입의 단형화 vs dyn 트레이드오프 ───────────────────
//
//  단형화(impl Trait / 제네릭):
//    + 인라인 최적화 가능 → 빠름
//    + vtable 없음
//    - 타입마다 코드 생성 → 바이너리 크기 증가
//    - 컴파일 시간 증가
//
//  dyn Trait:
//    + 바이너리 크기 작음 (함수 하나)
//    + 런타임에 타입 선택 가능
//    - vtable 조회 비용
//    - 인라인 불가
//
//  실제 크기 차이 확인:

fn show_sizes() {
    println!("\n  [심화4: 단형화 vs dyn — 크기 비교]");

    // 포인터 크기
    println!("  &Lion:          {} bytes (일반 참조)", std::mem::size_of::<&Lion>());
    println!("  &Duck:          {} bytes (일반 참조)", std::mem::size_of::<&Duck>());
    println!("  &Snake:         {} bytes (일반 참조)", std::mem::size_of::<&Snake>());
    println!("  &dyn Sound:     {} bytes (fat pointer)", std::mem::size_of::<&dyn Sound>());
    println!("  Box<dyn Sound>: {} bytes (fat pointer, 힙 소유)",
        std::mem::size_of::<Box<dyn Sound>>());

    // 실제 struct 크기
    println!("  Lion 크기:  {} bytes", std::mem::size_of::<Lion>());
    println!("  Duck 크기:  {} bytes", std::mem::size_of::<Duck>());
    println!("  Snake 크기: {} bytes", std::mem::size_of::<Snake>());

    // Option<Box<T>> 최적화 (NPO: Null Pointer Optimization)
    println!("\n  [Null Pointer Optimization]");
    println!("  Box<Lion>:          {} bytes", std::mem::size_of::<Box<Lion>>());
    println!("  Option<Box<Lion>>:  {} bytes", std::mem::size_of::<Option<Box<Lion>>>());
    // 결과: 동일! None = null pointer로 표현
}

// ─── 심화 5: where 절 vs 인라인 바운드 — 가독성 ─────────────────────────
//
//  인라인 바운드 (짧을 때 좋음):
//  fn f<T: Sound + fmt::Display>(x: &T) { ... }
//
//  where 절 (복잡할 때 가독성 좋음):
//  fn f<T>(x: &T)
//  where
//      T: Sound + fmt::Display,
//      T::Output: Clone,          // 연관 타입 바운드
//  { ... }
//
//  동일한 의미 — 스타일 차이만 있음
//
//  where Self: Sized 패턴:
//  trait MyTrait {
//      fn method(&self);                          // dyn에서도 호출 가능
//      fn generic_method<T>(&self) where Self: Sized; // dyn에서 제외
//  }
//  // generic_method는 vtable에 넣을 수 없으므로 where Self: Sized로 dyn에서 제외

fn demo_where_clause() {
    println!("\n  [심화5: where 절 활용]");

    // 복잡한 바운드는 where가 더 읽기 쉬움
    fn zoo_summary<T>(animals: &[T])
    where
        T: Sound + fmt::Display + fmt::Debug,
    {
        println!("  동물 {}마리:", animals.len());
        for a in animals {
            println!("    Display: {} | Debug: {:?} | Sound: {}",
                a, a, a.make_sound());
        }
    }

    let lions = vec![
        Lion::new("Simba", 5),
        Lion::new("Nala", 4),
    ];
    zoo_summary(&lions);
}

pub fn run() {
    println!("\n══════ Part 2 심화: impl 패턴 고급 ══════");
    demo_object_safety();
    demo_blanket_conflict();
    demo_assoc_vs_generic();
    show_sizes();
    demo_where_clause();
}
