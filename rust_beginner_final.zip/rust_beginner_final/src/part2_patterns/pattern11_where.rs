// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴11: where 절                                                      │
// │                                                                       │
// │  공식 문서: Rust Book Ch.10.2 "Trait Bounds with where Clauses"        │
// │                                                                       │
// │  where를 쓰는 이유:                                                     │
// │    1. 바운드가 복잡하면 함수 시그니처가 길어져 읽기 어려움                │
// │    2. 연관 타입에 바운드 지정할 때 where만 가능                          │
// │    3. 가독성 — 타입과 바운드를 분리해서 명확하게                         │
// │                                                                       │
// │  등가:                                                                  │
// │    fn f<T: A + B, U: C>(t: T, u: U) { }                              │
// │    fn f<T, U>(t: T, u: U) where T: A + B, U: C { }   ← where 버전    │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use crate::part2_patterns::pattern2_trait::Sound;

// ── 바운드가 많을 때 where 가독성 비교 ───────────────────────────────────

// where 없이 — 바운드가 많으면 줄이 길어짐
fn describe_inline<T: fmt::Display + fmt::Debug + Clone + Send>(animal: &T) -> String {
    format!("Display: {}, Debug: {:?}", animal, animal)
}

// where 사용 — 타입 목록과 바운드 분리, 가독성 향상
fn describe_where<T>(animal: &T) -> String
where
    T: fmt::Display + fmt::Debug + Clone + Send,
{
    format!("Display: {}, Debug: {:?}", animal, animal)
}

// ── 연관 타입에 바운드 — where만 가능 ────────────────────────────────────
// T::Item 처럼 연관 타입에 바운드를 걸 때는 where 절만 가능
fn print_first<I>(iter: I)
where
    I: Iterator,
    I::Item: fmt::Display,  // 연관 타입에 바운드 → where만 가능
{
    // into_iter()는 이미 IntoIterator이므로 iter() 직접 사용
    let mut it = iter;
    if let Some(first) = it.next() {
        println!("    첫 번째: {}", first);
    }
}

// ── 복수 타입 파라미터 where ──────────────────────────────────────────────
fn compare_and_show<T, U>(a: T, b: U) -> String
where
    T: fmt::Display + PartialOrd,
    U: fmt::Display + PartialOrd,
    T: Into<f64>,   // T에 추가 바운드
    U: Into<f64>,
{
    let fa: f64 = a.into();
    let fb: f64 = b.into();
    if fa > fb {
        format!("첫 번째가 큼")
    } else {
        format!("두 번째가 크거나 같음")
    }
}

// ── struct impl에서 where ─────────────────────────────────────────────────
struct Zoo<T, U> {
    main_animal: T,
    backup:      U,
}

// where로 각 타입 파라미터의 바운드를 명확히 분리
impl<T, U> Zoo<T, U>
where
    T: Sound + fmt::Display,
    U: fmt::Display,
{
    fn new(main: T, backup: U) -> Self {
        Zoo { main_animal: main, backup }
    }

    fn show(&self) {
        println!("    주요: {} (소리: {})", self.main_animal, self.main_animal.make_sound());
        println!("    보조: {}", self.backup);
    }
}

// impl 블록 분리 — 바운드별로 기능 분리
impl<T, U> fmt::Display for Zoo<T, U>
where
    T: fmt::Display,
    U: fmt::Display,
{
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Zoo({}, {})", self.main_animal, self.backup)
    }
}

// ── trait 정의에서 where ──────────────────────────────────────────────────
trait Summary
where
    Self: fmt::Display,  // 이 trait을 구현하려면 Display도 필요
{
    fn summarize(&self) -> String {
        format!("요약: {}", self)  // Self: Display 보장되므로 사용 가능
    }
}

use crate::part2_patterns::animals::Lion;

impl Summary for Lion {}  // Lion: Display이므로 Summary 구현 가능

pub fn run() {
    println!("\n  [패턴11: where 절]");

    // 가독성 비교
    println!("\n  ── inline vs where 가독성 ──");
    let lion = Lion::new("Simba", 5);
    println!("  inline: {}", describe_inline(&lion));
    println!("  where:  {}", describe_where(&lion));
    // 결과는 동일, where가 더 읽기 쉬움

    // 연관 타입 바운드
    println!("\n  ── 연관 타입 바운드 (where만 가능) ──");
    print_first(vec!["사자", "오리", "뱀"].into_iter());
    print_first(vec![1u32, 2, 3].into_iter());

    // 복수 타입 파라미터
    println!("\n  ── 복수 타입 파라미터 ──");
    println!("  {}", compare_and_show(5u32, 3u32));
    println!("  {}", compare_and_show(2u32, 7u32));

    // struct impl where
    println!("\n  ── struct impl where ──");
    use crate::part2_patterns::animals::Duck;
    let zoo = Zoo::new(Lion::new("Simba", 5), Duck::new("Donald", 3));
    zoo.show();
    println!("  Display: {}", zoo);

    // trait에서 where
    println!("\n  ── trait 정의 where ──");
    println!("  {}", lion.summarize());

    println!("\n  ── 패턴11 정리 ──");
    println!("  where 사용 권장 상황:");
    println!("    1. 바운드가 3개 이상일 때");
    println!("    2. 타입 파라미터가 2개 이상일 때");
    println!("    3. 연관 타입(T::Item)에 바운드가 필요할 때");
    println!("    4. impl 블록 시그니처가 길어질 때");
}
