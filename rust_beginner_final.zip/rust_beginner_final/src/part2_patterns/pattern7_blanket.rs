// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴7: impl<T: Bound> Trait for T — 블랭킷(blanket) 구현              │
// │                                                                       │
// │  패턴4와의 차이:                                                        │
// │    패턴4: for Cage<T>   — 특정 struct에 구현                           │
// │    패턴7: for T         — struct 이름 없음. 조건 만족하는 모든 T에 적용  │
// │                                                                       │
// │  표준 라이브러리 블랭킷 구현 예시:                                       │
// │    impl<T: Display> ToString for T                                    │
// │      → Display 구현하면 .to_string() 자동으로 생긴다                    │
// │    impl<T, U: From<T>> Into<U> for T                                  │
// │      → From 구현하면 .into() 자동으로 생긴다                            │
// └───────────────────────────────────────────────────────────────────────┘
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;

pub trait Announce {
    fn announce(&self);
    fn announce_loud(&self);
}

// struct 이름 없음 — Sound를 구현한 모든 T에 자동 적용
// Lion, Duck, Snake 각각에 impl Announce를 쓰지 않아도 된다.
// 나중에 Bear, Tiger 등을 추가해도 Sound만 구현하면 Announce는 공짜.
impl<T: Sound> Announce for T {
    fn announce(&self) {
        println!("    [방송] {}", self.make_sound());
    }
    fn announce_loud(&self) {
        let sound = self.make_sound().to_uppercase();
        println!("    [긴급방송] *** {} ***", sound);
    }
}

// 다른 블랭킷 예시: Sound + fmt::Display 둘 다 있으면 show() 가능
pub trait ShowAndSound {
    fn show_and_sound(&self);
}

impl<T: Sound + std::fmt::Display> ShowAndSound for T {
    fn show_and_sound(&self) {
        println!("    [전시+소리] {} → {}",
            self,              // T: Display
            self.make_sound()); // T: Sound
    }
}

pub fn run() {
    println!("\n─── 패턴7: 블랭킷(blanket) 구현 ───");

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    let nagini = Snake::new("Nagini", 8, true);
    let kaa    = Snake::new("Kaa", 5, false);

    println!("\n  [Announce — Sound만 있으면 자동 적용]");
    // impl Announce for Lion/Duck/Snake 를 따로 쓰지 않았다
    simba.announce();
    donald.announce();
    nagini.announce();
    kaa.announce();

    println!("\n  [announce_loud]");
    simba.announce_loud();
    nagini.announce_loud();

    println!("\n  [ShowAndSound — Sound + Display 이중 바운드]");
    // Lion, Duck, Snake 모두 Display를 구현했으므로 자동 적용
    simba.show_and_sound();
    donald.show_and_sound();
    nagini.show_and_sound();
    kaa.show_and_sound();
}
