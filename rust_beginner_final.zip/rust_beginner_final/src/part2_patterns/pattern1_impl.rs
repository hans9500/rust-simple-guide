// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴1: impl Struct — 고유 메서드                                       │
// │                                                                       │
// │  impl 블록은 struct 전용 메서드 공간이다. trait과 무관하다.               │
// │  같은 struct에 impl 블록을 여러 개 쓸 수 있다.                           │
// │  각 블록은 독립적으로 컴파일되며 서로 다른 바운드를 가질 수 있다.          │
// │                                                                       │
// │  self 세 가지 형태 요약:                                                │
// │    &self     — 공유 빌림.  읽기 전용.  호출 후 변수 유효.                │
// │    &mut self — 배타 빌림.  읽기+쓰기. 호출 후 변수 유효.                 │
// │    self      — 소유권 소비. 호출 후 변수 무효. 컴파일 에러.              │
// └───────────────────────────────────────────────────────────────────────┘
use crate::part2_patterns::animals::{Lion, Duck, Snake};

pub fn run() {
    println!("\n─── 패턴1: impl Struct ───");

    // ── 연관 상수 ──────────────────────────────────────────────────────────
    println!("  [연관 상수]");
    println!("  Lion::MAX_AGE   = {}", Lion::MAX_AGE);
    println!("  Lion::SPECIES   = {}", Lion::SPECIES);
    println!("  Duck::SPECIES   = {}", Duck::SPECIES);
    println!("  Snake::SPECIES_VENOMOUS = {}", Snake::SPECIES_VENOMOUS);

    // ── 빌더 패턴 (Self 반환 체이닝) ─────────────────────────────────────
    println!("\n  [빌더 패턴 — with_xxx 체이닝]");
    let simba  = Lion::new("Simba", 1).with_age(5).with_hungry(false);
    let donald = Duck::new("Donald", 1).with_feathers(300);
    let nagini = Snake::new("Nagini", 8, true).with_length(200);
    println!("  {}", simba.status());
    println!("  {}", donald.status());
    println!("  {}", nagini.status());

    // ── &self — 읽기, 여러 번 호출 가능 ──────────────────────────────────
    println!("\n  [&self — 읽기]");
    let lion = Lion::new("Mufasa", 10);
    println!("  name():      {}", lion.name());
    println!("  age():       {}", lion.age());
    println!("  is_hungry(): {}", lion.is_hungry());
    println!("  is_senior(): {}", lion.is_senior());
    println!("  status():    {}", lion.status());
    // lion은 여기서도 유효 — &self는 소유권을 가져가지 않음
    println!("  다시 name(): {}", lion.name());

    // ── &mut self — 수정, let mut 필요 ────────────────────────────────────
    println!("\n  [&mut self — 수정]");
    let mut mufasa = Lion::new("Mufasa", 9);
    println!("  before: {}", mufasa.status());
    mufasa.feed();       // hungry = false
    mufasa.birthday();   // age += 1
    mufasa.birthday();   // age += 1
    println!("  after:  {}", mufasa.status());
    // mufasa는 여전히 유효

    let mut duck = Duck::new("Donald", 3);
    duck.lose_feathers(600);
    println!("  Duck 털갈이: {}", duck.is_molting());
    duck.regrow_feathers();
    println!("  Duck 재생 후 털갈이: {}", duck.is_molting());

    let mut kaa = Snake::new("Kaa", 5, false).with_length(120);
    kaa.warn();
    kaa.shed_skin();
    kaa.shed_skin();
    println!("  Snake: {}", kaa.status());

    // ── self — 소유권 소비, 호출 후 무효 ─────────────────────────────────
    println!("\n  [self — 소유권 소비]");
    let nala = Lion::new("Nala", 7);
    println!("  은퇴 전: {}", nala.name());
    let msg = nala.retire();  // nala 소유권 소비
    println!("  {}", msg);
    // println!("{}", nala.name()); // ← 컴파일 에러: value borrowed here after move

    // ── 연관 함수 — 인스턴스 없이 타입으로 호출 ──────────────────────────
    println!("\n  [연관 함수 — Lion::eldest]");
    let pride = vec![
        Lion::new("Simba", 5),
        Lion::new("Mufasa", 12),
        Lion::new("Scar", 9),
        Lion::new("Nala", 4),
    ];
    if let Some(eldest) = Lion::eldest(&pride) {
        println!("  가장 나이 많은 사자: {}", eldest.status());
    }
}
