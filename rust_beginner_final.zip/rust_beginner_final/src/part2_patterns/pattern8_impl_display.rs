// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴8: impl<T: Display> Display for Cage<T>                          │
// │                                                                       │
// │  "특정 struct<T>에, T가 특정 trait을 구현할 때만,                       │
// │   표준 trait을 조건부로 구현한다"                                        │
// │                                                                       │
// │  패턴4와의 차이:                                                        │
// │    패턴4: impl<T: Sound> MyTrait  for Cage<T>  → 커스텀 trait 구현     │
// │    패턴8: impl<T: Display> Display for Cage<T> → 표준 trait 조건부 구현 │
// │                                                                       │
// │  핵심:                                                                  │
// │    T가 Display를 구현하면 → Cage<T>도 자동으로 Display 구현             │
// │    T가 Display 없으면    → Cage<T>는 println!("{}", cage) 컴파일 에러   │
// │                                                                       │
// │  표준 라이브러리 실제 사용:                                              │
// │    impl<T: Display> Display for Vec<T>  → 아니지만 유사 개념            │
// │    impl<T: Display> Display for Option<T>  → 유사                     │
// │    impl<T: Debug>   Debug   for Vec<T>  → 실제로 이 방식               │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;

// ── 기본 Cage<T> 구조체 ──────────────────────────────────────────────────
#[derive(Debug)]
pub struct Cage<T> {
    pub animal: T,
    pub id:     u32,
    pub label:  String,
}

impl<T> Cage<T> {
    pub fn new(animal: T, id: u32) -> Self {
        Cage { animal, id, label: format!("우리 #{}", id) }
    }
    pub fn with_label(mut self, label: &str) -> Self {
        self.label = label.to_string();
        self
    }
}

// ── 패턴8 핵심: T가 Display이면 Cage<T>도 Display ────────────────────────
// "T: Display" 바운드 → T를 {:?} 아닌 {} 로 출력 가능
impl<T: fmt::Display> fmt::Display for Cage<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "[{}] {}", self.label, self.animal)
    }
}

// ── T가 Sound이면 Cage<T>도 make_sound() 가능 ────────────────────────────
impl<T: Sound> Cage<T> {
    pub fn make_sound(&self) -> String {
        self.animal.make_sound()
    }
}

// ── T가 Display + Sound 둘 다이면 announce() 가능 ─────────────────────────
impl<T: fmt::Display + Sound> Cage<T> {
    pub fn announce(&self) {
        println!("    {} 이(가) 소리를 냅니다: {}",
            self.animal,           // T: Display
            self.animal.make_sound() // T: Sound
        );
    }
}

// ── Display가 없는 타입 ───────────────────────────────────────────────────
// Display를 구현하지 않은 타입을 Cage에 넣으면
// println!("{}", cage)는 컴파일 에러
struct Mystery;  // Display 없음

pub fn run() {
    println!("\n  [패턴8: impl<T: Display> Display for Cage<T>]");

    // Lion이 Display를 구현하면 Cage<Lion>도 Display
    let lion_cage = Cage::new(Lion::new("Simba", 5), 1)
        .with_label("아프리카관 1호");

    // {} 출력 가능 — Cage<Lion>: Display
    println!("  Display: {}", lion_cage);

    // {:?} 출력 가능 — Cage<Lion>: Debug (#[derive(Debug)])
    println!("  Debug:   {:?}", lion_cage);

    // T: Display + Sound 둘 다 있으면 announce() 가능
    lion_cage.announce();

    // 여러 타입에 적용
    let duck_cage  = Cage::new(Duck::new("Donald", 3), 2).with_label("조류관 2호");
    let snake_cage = Cage::new(Snake::new("Nagini", 8, true), 3).with_label("파충류관 3호");

    let cages_display: Vec<String> = vec![
        lion_cage.to_string(),
        duck_cage.to_string(),
        snake_cage.to_string(),
    ];
    println!("\n  전체 우리 목록 (Display):");
    for s in &cages_display {
        println!("    {}", s);
    }

    // Mystery는 Display 없으므로 Cage<Mystery>는 Display 구현 안 됨
    let mystery_cage = Cage::new(Mystery, 99);
    // println!("{}", mystery_cage);  // 컴파일 에러: Mystery: Display 없음
    // {:?}도 안 됨 — Mystery: Debug 없음
    // mystery_cage가 사용됨을 컴파일러에 알림
    let _ = mystery_cage.id;
    println!("\n  Cage<Mystery>는 Display 없음 → println!(\"{{}}\", ...) 컴파일 에러");

    // 핵심 정리
    println!("\n  ── 패턴8 핵심 ──");
    println!("  impl<T: Display> Display for Cage<T>");
    println!("    → T가 Display를 구현한 경우에만 Cage<T>도 Display");
    println!("    → T마다 impl Display for Cage<Lion/Duck/Snake> 를 따로 안 써도 됨");
    println!("    → 컴파일 타임에 T의 능력에 따라 Cage의 능력이 결정됨");
}
