// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴6: trait Reproduce — 연관 타입(associated type)                   │
// │                                                                       │
// │  패턴5 vs 패턴6:                                                        │
// │    패턴5: "하나의 타입이 여러 F에 대해 구현" → Feed<Meat>, Feed<Fish>    │
// │    패턴6: "출력 타입이 정확히 하나"          → Offspring = Lion         │
// │                                                                       │
// │  표준 라이브러리 연관 타입:                                              │
// │    Iterator::Item   — 반복자가 yield하는 원소 타입                       │
// │    Add::Output      — a + b 의 결과 타입                               │
// │    Deref::Target    — *x 의 타입                                       │
// └───────────────────────────────────────────────────────────────────────┘
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;

pub trait Reproduce {
    type Offspring;                             // 연관 타입 — 구현 쪽에서 확정

    fn give_birth(&self) -> Self::Offspring;
    fn litter_size(&self) -> u32;
    fn gestation_days(&self) -> u32;            // 임신 기간 (일)
}

impl Reproduce for Lion {
    type Offspring = Lion;                      // Lion 새끼는 항상 Lion

    fn give_birth(&self) -> Lion {
        println!("    [Lion] {} 가 새끼를 낳았다! (임신기간: {}일)",
            self.name, self.gestation_days());
        Lion::new("새끼 사자", 0)
    }
    fn litter_size(&self) -> u32    { 3 }
    fn gestation_days(&self) -> u32 { 110 }
}

impl Reproduce for Duck {
    type Offspring = Duck;

    fn give_birth(&self) -> Duck {
        println!("    [Duck] {} 가 알을 낳았다! (임신기간: {}일)",
            self.name, self.gestation_days());
        Duck::new("아기 오리", 0)
    }
    fn litter_size(&self) -> u32    { 8 }
    fn gestation_days(&self) -> u32 { 28 }
}

impl Reproduce for Snake {
    type Offspring = Snake;                     // Snake 새끼는 항상 Snake

    fn give_birth(&self) -> Snake {
        // 뱀은 알을 낳거나 새끼를 낳는다 — 여기서는 간략화
        println!("    [Snake] {} 가 새끼를 낳았다! (독: {}, 임신기간: {}일)",
            self.name, self.is_venomous, self.gestation_days());
        Snake::new("새끼 뱀", 0, self.is_venomous) // 독성은 유전
    }
    fn litter_size(&self) -> u32    { 12 }
    fn gestation_days(&self) -> u32 { 60 }
}

// where 절 — 연관 타입에 바운드: "새끼가 Sound를 구현해야 함"
fn birth_and_announce<T>(parent: &T)
where
    T: Reproduce,
    T::Offspring: Sound,
{
    let baby = parent.give_birth();
    println!("    새끼 소리: {}", baby.make_sound());
}

// 여러 바운드: 새끼가 Sound + Debug여야 함
fn birth_inspect<T>(parent: &T)
where
    T: Reproduce,
    T::Offspring: Sound + std::fmt::Debug,
{
    let baby = parent.give_birth();
    println!("    새끼 소리: {}", baby.make_sound());
    println!("    새끼 Debug: {:?}", baby);
}

pub fn run() {
    println!("\n─── 패턴6: 연관 타입 (associated type) ───");

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    let nagini = Snake::new("Nagini", 8, true);
    let kaa    = Snake::new("Kaa", 5, false);

    println!("\n  [Lion Reproduce]");
    let baby_lion = simba.give_birth();
    println!("  새끼: {}, 마릿수: {}, 임신기간: {}일",
        baby_lion.name(), simba.litter_size(), simba.gestation_days());

    println!("\n  [Duck Reproduce]");
    let baby_duck = donald.give_birth();
    println!("  새끼: {}, 마릿수: {}, 임신기간: {}일",
        baby_duck.name(), donald.litter_size(), donald.gestation_days());

    println!("\n  [Snake Reproduce — 독성 유전]");
    let baby_nagini = nagini.give_birth();
    println!("  독사 새끼 독성: {}", baby_nagini.is_venomous());
    let baby_kaa = kaa.give_birth();
    println!("  무독 새끼 독성: {}", baby_kaa.is_venomous());

    println!("\n  [birth_and_announce — T::Offspring: Sound]");
    birth_and_announce(&simba);
    birth_and_announce(&donald);
    birth_and_announce(&nagini);
    birth_and_announce(&kaa);

    println!("\n  [birth_inspect — T::Offspring: Sound + Debug]");
    birth_inspect(&simba);
    birth_inspect(&nagini);
}
