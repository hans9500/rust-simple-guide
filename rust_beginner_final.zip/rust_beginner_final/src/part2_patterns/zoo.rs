// ┌───────────────────────────────────────────────────────────────────────┐
// │  Zoo<T> — 패턴 1~7 통합                                                │
// │                                                                       │
// │  ① impl<T: Sound> Zoo<T>                  고유 메서드                  │
// │  ② impl<T: Sound + Display> Display        T를 {} 로 출력              │
// │  ③ impl<T: Sound> From<Vec<Cage<T>>>       From (패턴5) → Into 자동    │
// │  ④ impl<T: Sound> IntoIterator for Zoo<T>  for cage in zoo 가능       │
// └───────────────────────────────────────────────────────────────────────┘
use std::fmt;
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;
use crate::part2_patterns::pattern3_generic::{Cage, Describable};

pub struct Zoo<T> {
    pub name:  String,
    pub cages: Vec<Cage<T>>,
}

// ① 고유 메서드
impl<T: Sound> Zoo<T> {
    pub fn new(name: &str) -> Self {
        Zoo { name: name.to_string(), cages: Vec::new() }
    }
    pub fn add_cage(&mut self, cage: Cage<T>) {
        println!("    [Zoo] {} ← {} 추가",
            self.name, cage.animal_sound());
        self.cages.push(cage);
    }
    pub fn total_cages(&self) -> usize { self.cages.len() }
    pub fn describe_all(&self) {
        println!("    === {} 전체 현황 ({} 우리) ===", self.name, self.cages.len());
        for cage in &self.cages { cage.describe(); }
    }
    pub fn open_all(&mut self) {
        for cage in &mut self.cages { cage.open(); }
    }
    pub fn close_all(&mut self) {
        for cage in &mut self.cages { cage.close(); }
    }
}

// ② Display — T: Sound + Display 이중 바운드
impl<T: Sound + fmt::Display> fmt::Display for Zoo<T> {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        writeln!(f, "╔═══ {} ({} 우리) ═══╗", self.name, self.cages.len())?;
        for cage in &self.cages {
            writeln!(f, "  {} [{}] | {}",
                cage.label(),
                if cage.is_open() { "열림" } else { "잠김" },
                cage.get_animal())?;   // &T → T: Display 필요
        }
        writeln!(f, "╚══════════════════╝")
    }
}

// ③ From<Vec<Cage<T>>> — 패턴5 (From<T>는 제네릭 trait)
// From 구현 → Into 블랭킷(패턴7)으로 자동 생성
impl<T: Sound> From<Vec<Cage<T>>> for Zoo<T> {
    fn from(cages: Vec<Cage<T>>) -> Self {
        let name = format!("동물원 ({}개 우리)", cages.len());
        Zoo { name, cages }
    }
}

// ④ IntoIterator — for cage in zoo 구문 가능
// Iterator를 직접 구현하는 대신 Vec의 into_iter()를 위임
impl<T: Sound> IntoIterator for Zoo<T> {
    type Item = Cage<T>;
    type IntoIter = std::vec::IntoIter<Cage<T>>;

    fn into_iter(self) -> Self::IntoIter {
        self.cages.into_iter()
    }
}

// &Zoo<T>에도 IntoIterator 구현 — for cage in &zoo (소유권 유지)
impl<'a, T: Sound> IntoIterator for &'a Zoo<T> {
    type Item = &'a Cage<T>;
    type IntoIter = std::slice::Iter<'a, Cage<T>>;

    fn into_iter(self) -> Self::IntoIter {
        self.cages.iter()
    }
}

pub fn run() {
    println!("\n─── Zoo<T>: 패턴 1~7 통합 ───");

    // Zoo<Lion>
    println!("\n  [Zoo<Lion>]");
    let mut lion_zoo: Zoo<Lion> = Zoo::new("사자 동물원");
    lion_zoo.add_cage(Cage::new(Lion::new("Simba",  5), 1).with_label("왕 우리"));
    lion_zoo.add_cage(Cage::new(Lion::new("Mufasa", 10), 2).with_label("어른 우리"));
    lion_zoo.add_cage(Cage::new(Lion::new("Nala",   4), 3).with_label("암사자 우리"));
    println!("  총 우리: {}", lion_zoo.total_cages());
    lion_zoo.describe_all();

    // Display (Lion: Sound + Display → Zoo<Lion>: Display)
    println!("\n  [Zoo<Lion> Display]");
    println!("{}", lion_zoo);

    // Zoo<Snake>
    println!("  [Zoo<Snake>]");
    let mut snake_zoo: Zoo<Snake> = Zoo::new("파충류관");
    snake_zoo.add_cage(Cage::new(Snake::new("Nagini", 8, true),  1).with_label("독사 #1"));
    snake_zoo.add_cage(Cage::new(Snake::new("Kaa",    5, false), 2).with_label("비단뱀"));
    snake_zoo.add_cage(Cage::new(Snake::new("Cobra",  6, true),  3).with_label("코브라"));
    snake_zoo.describe_all();

    // From<Vec<Cage<T>>> → Zoo<T>
    println!("\n  [From<Vec<Cage<Duck>>> → Zoo<Duck>]");
    let duck_cages = vec![
        Cage::new(Duck::new("Donald", 3), 1).with_label("오리 연못 A"),
        Cage::new(Duck::new("Daffy",  4), 2).with_label("오리 연못 B"),
    ];
    let duck_zoo: Zoo<Duck> = duck_cages.into();  // From → Into 자동 생성
    println!("  into()로 생성된 Zoo: {} 우리", duck_zoo.total_cages());

    // IntoIterator — for cage in &zoo
    println!("\n  [IntoIterator — for cage in &lion_zoo]");
    for cage in &lion_zoo {
        println!("  → {}", cage.animal_sound());
    }
}
