// ┌──────────────────────────────────────────────────────────────────
// │ Part 2 보강: 빌더 패턴 (Builder Pattern) 심화
// │
// │ 빌더 패턴이 필요한 이유:
// │   - 필드가 많은 구조체의 생성을 단계별로
// │   - 선택적 필드 처리
// │   - 생성 시 검증
// │   - 메서드 체이닝으로 가독성 향상
// │
// │ Rust에서 세 가지 빌더 스타일:
// │   1. 별도 Builder 구조체
// │   2. Default + 수정
// │   3. 타입 상태 빌더 (컴파일 타임 강제)
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [Part 2 보강: 빌더 패턴 심화]");
    demo_basic_builder();
    demo_validated_builder();
    demo_typestate_builder();
}

// ══════════════════════════════════════════════════════════════════
// 1. 기본 빌더 패턴
// ══════════════════════════════════════════════════════════════════
#[derive(Debug)]
struct Animal {
    name:        String,
    species:     String,
    age:         u32,
    weight_kg:   f64,
    is_venomous: bool,
    enclosure:   String,
}

struct AnimalBuilder {
    name:        String,
    species:     String,
    age:         u32,
    weight_kg:   f64,
    is_venomous: bool,
    enclosure:   String,
}

impl AnimalBuilder {
    // 필수 필드만 생성자에서
    fn new(name: &str, species: &str) -> Self {
        AnimalBuilder {
            name:        name.to_string(),
            species:     species.to_string(),
            age:         0,
            weight_kg:   0.0,
            is_venomous: false,
            enclosure:   String::from("일반관"),
        }
    }

    // 선택적 필드 — self를 반환해서 체이닝 가능
    fn age(mut self, age: u32) -> Self {
        self.age = age;
        self
    }

    fn weight_kg(mut self, weight: f64) -> Self {
        self.weight_kg = weight;
        self
    }

    fn venomous(mut self) -> Self {
        self.is_venomous = true;
        self
    }

    fn enclosure(mut self, enclosure: &str) -> Self {
        self.enclosure = enclosure.to_string();
        self
    }

    fn build(self) -> Animal {
        Animal {
            name:        self.name,
            species:     self.species,
            age:         self.age,
            weight_kg:   self.weight_kg,
            is_venomous: self.is_venomous,
            enclosure:   self.enclosure,
        }
    }
}

fn demo_basic_builder() {
    println!("\n  ── 1. 기본 빌더 패턴 ──");

    let lion = AnimalBuilder::new("Simba", "사자")
        .age(5)
        .weight_kg(190.5)
        .enclosure("아프리카관")
        .build();

    let snake = AnimalBuilder::new("Nagini", "뱀")
        .age(8)
        .weight_kg(15.0)
        .venomous()
        .enclosure("파충류관")
        .build();

    let duck = AnimalBuilder::new("Donald", "오리")
        .age(3)
        .weight_kg(2.5)
        .build();  // 선택 필드는 기본값

    println!("  {:?}", lion);
    println!("    → 나이:{} 체중:{}kg 독:{} 구역:{}",
             lion.age, lion.weight_kg, lion.is_venomous, lion.enclosure);
    println!("  {:?}", snake);
    println!("  {:?}", duck);
}

// ══════════════════════════════════════════════════════════════════
// 2. 검증이 있는 빌더 (build → Result 반환)
// ══════════════════════════════════════════════════════════════════
#[derive(Debug)]
struct ZooConfig {
    name:        String,
    max_capacity: u32,
    open_hour:   u8,
    close_hour:  u8,
    entrance_fee: f64,
}

#[derive(Debug)]
enum ConfigError {
    EmptyName,
    InvalidCapacity,
    InvalidHours { open: u8, close: u8 },
    InvalidFee(f64),
}

impl std::fmt::Display for ConfigError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::EmptyName              => write!(f, "동물원 이름이 비어있음"),
            Self::InvalidCapacity        => write!(f, "수용 인원은 1 이상이어야 함"),
            Self::InvalidHours{open,close} =>
                write!(f, "운영 시간 오류: {}시~{}시 (개장이 폐장보다 앞이어야 함)", open, close),
            Self::InvalidFee(fee)        => write!(f, "입장료 {}는 0 이상이어야 함", fee),
        }
    }
}

struct ZooConfigBuilder {
    name:         String,
    max_capacity: u32,
    open_hour:    u8,
    close_hour:   u8,
    entrance_fee: f64,
}

impl ZooConfigBuilder {
    fn new(name: &str) -> Self {
        ZooConfigBuilder {
            name:         name.to_string(),
            max_capacity: 100,
            open_hour:    9,
            close_hour:   18,
            entrance_fee: 0.0,
        }
    }

    fn max_capacity(mut self, cap: u32) -> Self {
        self.max_capacity = cap; self
    }
    fn hours(mut self, open: u8, close: u8) -> Self {
        self.open_hour = open; self.close_hour = close; self
    }
    fn entrance_fee(mut self, fee: f64) -> Self {
        self.entrance_fee = fee; self
    }

    fn build(self) -> Result<ZooConfig, ConfigError> {
        // 검증
        if self.name.trim().is_empty() {
            return Err(ConfigError::EmptyName);
        }
        if self.max_capacity == 0 {
            return Err(ConfigError::InvalidCapacity);
        }
        if self.open_hour >= self.close_hour {
            return Err(ConfigError::InvalidHours {
                open: self.open_hour, close: self.close_hour
            });
        }
        if self.entrance_fee < 0.0 {
            return Err(ConfigError::InvalidFee(self.entrance_fee));
        }
        Ok(ZooConfig {
            name:         self.name,
            max_capacity: self.max_capacity,
            open_hour:    self.open_hour,
            close_hour:   self.close_hour,
            entrance_fee: self.entrance_fee,
        })
    }
}

fn demo_validated_builder() {
    println!("\n  ── 2. 검증 빌더 (build → Result) ──");

    let ok = ZooConfigBuilder::new("서울 동물원")
        .max_capacity(500)
        .hours(9, 18)
        .entrance_fee(5000.0)
        .build();
    println!("  유효: {:?}", ok.map(|c|
        format!("{} 수용:{} {}~{}시 {}원",
            c.name, c.max_capacity, c.open_hour, c.close_hour, c.entrance_fee)));

    let err1 = ZooConfigBuilder::new("")
        .build();
    println!("  빈 이름: {}", err1.unwrap_err());

    let err2 = ZooConfigBuilder::new("테스트")
        .hours(18, 9)  // 개장이 폐장보다 늦음
        .build();
    println!("  잘못된 시간: {}", err2.unwrap_err());

    let err3 = ZooConfigBuilder::new("테스트")
        .entrance_fee(-1000.0)
        .build();
    println!("  음수 요금: {}", err3.unwrap_err());
}

// ══════════════════════════════════════════════════════════════════
// 3. 타입 상태 빌더 (Typestate Pattern)
//    — 컴파일 타임에 순서 강제
// ══════════════════════════════════════════════════════════════════
// 상태를 타입으로 표현
struct NoName;
struct HasName(String);
struct HasSpecies { name: String, species: String }

struct TypedBuilder<State> {
    state: State,
}

impl TypedBuilder<NoName> {
    fn new() -> Self {
        TypedBuilder { state: NoName }
    }
    // name 없이는 다음 단계로 못 감
    fn name(self, name: &str) -> TypedBuilder<HasName> {
        TypedBuilder { state: HasName(name.to_string()) }
    }
}

impl TypedBuilder<HasName> {
    // name 있어야 species 설정 가능
    fn species(self, species: &str) -> TypedBuilder<HasSpecies> {
        TypedBuilder {
            state: HasSpecies {
                name:    self.state.0,
                species: species.to_string(),
            }
        }
    }
}

impl TypedBuilder<HasSpecies> {
    // 완성 — name + species 있어야 build 가능
    fn build(self) -> Animal {
        AnimalBuilder::new(&self.state.name, &self.state.species)
            .build()
    }
}

fn demo_typestate_builder() {
    println!("\n  ── 3. 타입 상태 빌더 (컴파일 타임 순서 강제) ──");

    let animal = TypedBuilder::new()
        .name("Simba")     // NoName → HasName
        .species("사자")   // HasName → HasSpecies
        .build();          // HasSpecies → Animal

    println!("  typestate 빌더: {} ({})", animal.name, animal.species);

    // TypedBuilder::new().build()  // 컴파일 에러: NoName에는 build 없음
    // TypedBuilder::new().name("x").build()  // 에러: HasName에는 build 없음
    println!("  순서 어기면 컴파일 에러 — 런타임 에러 불가");
}
