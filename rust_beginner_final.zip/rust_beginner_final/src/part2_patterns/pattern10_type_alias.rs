// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴10: type 별칭(alias) & 뉴타입(newtype) 패턴                       │
// │                                                                       │
// │  type 별칭: 긴 타입에 짧은 이름. 타입 안전성 없음 (같은 타입)            │
// │    type ZooResult<T> = Result<T, ZooError>;                           │
// │    type Callback      = Box<dyn Fn(u32) -> String>;                   │
// │                                                                       │
// │  뉴타입 패턴: 단일 필드 튜플 struct. 타입 안전성 있음 (다른 타입)        │
// │    struct Meters(f64);   — f64와 다른 타입                             │
// │    struct Kilograms(f64); — Meters와 혼용 불가                         │
// │                                                                       │
// │  뉴타입 용도:                                                           │
// │    1. 외부 타입에 trait 구현 (orphan rule 우회)                         │
// │    2. 단위 혼용 방지                                                    │
// │    3. 의미 명확화                                                       │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use std::ops::Add;

// ── type 별칭 ─────────────────────────────────────────────────────────────
#[derive(Debug)]
pub enum ZooError {
    NotFound(String),
    CapacityFull,
}

impl fmt::Display for ZooError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::NotFound(s) => write!(f, "찾을 수 없음: {}", s),
            Self::CapacityFull => write!(f, "수용 한계 초과"),
        }
    }
}

// type 별칭 — 긴 타입을 짧게
type ZooResult<T>  = Result<T, ZooError>;
type AnimalId      = u32;
#[allow(dead_code)]
type Weight        = f64;  // 예시용 — 뉴타입 Kilograms와 대비
type Callback      = Box<dyn Fn(AnimalId) -> String>;

fn find_animal(id: AnimalId) -> ZooResult<String> {
    if id == 0 {
        Err(ZooError::NotFound(format!("id={}", id)))
    } else {
        Ok(format!("동물 #{}", id))
    }
}

fn make_callback(prefix: &str) -> Callback {
    let p = prefix.to_string();
    Box::new(move |id| format!("{}-{}", p, id))
}

// ── 뉴타입 패턴 ──────────────────────────────────────────────────────────
// 단위 타입 — f64와 다른 타입이므로 혼용 불가
#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
struct Meters(f64);

#[derive(Debug, Clone, Copy, PartialEq, PartialOrd)]
struct Kilograms(f64);

#[derive(Debug, Clone, Copy)]
struct AgeYears(u32);

// Meters끼리 덧셈 가능
impl Add for Meters {
    type Output = Meters;
    fn add(self, other: Meters) -> Meters {
        Meters(self.0 + other.0)
    }
}

impl fmt::Display for Meters {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}m", self.0)
    }
}
impl fmt::Display for Kilograms {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}kg", self.0)
    }
}
impl fmt::Display for AgeYears {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}살", self.0)
    }
}

struct Animal {
    name:   String,
    weight: Kilograms,
    age:    AgeYears,
}

impl Animal {
    fn new(name: &str, weight: Kilograms, age: AgeYears) -> Self {
        Animal { name: name.to_string(), weight, age }
    }
}

impl fmt::Display for Animal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} ({}, {})", self.name, self.weight, self.age)
    }
}

// ── orphan rule 우회 ──────────────────────────────────────────────────────
// 외부 타입(Vec<String>)에 외부 trait(Display)을 직접 구현 불가
// → 뉴타입으로 감싸서 구현
struct AnimalList(Vec<String>);

impl fmt::Display for AnimalList {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "동물 목록: [{}]", self.0.join(", "))
    }
}

// ── 의미 명확화 ───────────────────────────────────────────────────────────
// u32 대신 뉴타입으로 의도 명확히
#[derive(Debug, Clone, Copy)]
struct VisitorCount(u32);

#[derive(Debug, Clone, Copy)]
struct CageNumber(u32);

fn assign_cage(visitor: VisitorCount, cage: CageNumber) -> String {
    format!("방문객 {} 번이 {} 번 우리 배정", visitor.0, cage.0)
}
// assign_cage(CageNumber(3), VisitorCount(1))  // 순서 바꾸면 컴파일 에러!

pub fn run() {
    println!("\n  [패턴10: type 별칭 & 뉴타입 패턴]");

    // type 별칭
    println!("\n  ── type 별칭 ──");
    println!("  find(1): {:?}", find_animal(1));
    println!("  find(0): {:?}", find_animal(0));
    let cb = make_callback("동물");
    println!("  callback: {}", cb(42));

    // 뉴타입 — 단위 안전성
    println!("\n  ── 뉴타입: 단위 안전성 ──");
    let lion = Animal::new("Simba", Kilograms(190.5), AgeYears(5));
    let duck = Animal::new("Donald", Kilograms(2.5), AgeYears(3));
    println!("  {}", lion);
    println!("  {}", duck);

    let fence1 = Meters(10.0);
    let fence2 = Meters(5.0);
    println!("  울타리 합계: {}", fence1 + fence2);

    // 컴파일 타임 타입 혼용 방지
    // let wrong = lion.weight + lion.age;  // 에러: Kilograms + AgeYears
    // let wrong2 = fence1 + lion.weight;   // 에러: Meters + Kilograms
    println!("  Kilograms + AgeYears → 컴파일 에러 (타입 혼용 방지)");

    // orphan rule 우회
    println!("\n  ── 뉴타입: orphan rule 우회 ──");
    let list = AnimalList(vec!["사자".into(),"오리".into(),"뱀".into()]);
    println!("  {}", list);
    // Vec<String>에는 Display 직접 구현 불가
    // AnimalList(Vec<String>)는 우리 타입이므로 Display 구현 가능

    // 의미 명확화
    println!("\n  ── 뉴타입: 의미 명확화 ──");
    println!("  {}", assign_cage(VisitorCount(7), CageNumber(3)));

    println!("\n  ── 패턴10 정리 ──");
    println!("  type Alias = T     → 같은 타입, 이름만 짧게, 타입 안전성 없음");
    println!("  struct New(T)      → 다른 타입, 단위/의미 강제, orphan rule 우회");
}
