// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴3: impl<T> Struct<T> — 제네릭 고유 메서드                          │
// │                                                                       │
// │  단형화(Monomorphization):                                             │
// │  컴파일러는 사용된 구체 타입마다 별도 코드를 생성한다.                   │
// │  런타임에 타입 확인 코드가 전혀 없다 → C 수준 성능.                      │
// │                                                                       │
// │  같은 struct에 바운드가 다른 impl 블록 여러 개 가능:                     │
// │    impl<T> Cage<T>         — T에 무관하게 항상 존재                     │
// │    impl<T: Sound> Cage<T>  — T가 Sound일 때만 존재                     │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 단형화 도식 ─────────────────────────────────────────────────────────
//
//  작성한 코드:              컴파일러가 생성하는 코드 (개념적):
//
//  impl<T> Cage<T> {         impl Cage<Lion>  { fn get_animal(&self) -> &Lion  }
//    fn get_animal            impl Cage<Duck>  { fn get_animal(&self) -> &Duck  }
//      (&self) -> &T  ──▶    impl Cage<Snake> { fn get_animal(&self) -> &Snake }
//  }
//
//  각 타입별로 독립된 코드 → 인라인 최적화 가능, vtable 없음
//  단점: 타입이 많으면 바이너리 크기 증가

use std::fmt;
use crate::part2_patterns::pattern2_trait::Sound;
use crate::part2_patterns::animals::{Lion, Duck, Snake};

pub struct Cage<T> {
    pub animal:      T,
    pub cage_number: u32,
    pub is_open:     bool,
    pub label:       String,    // 우리 이름표
}

// ── 바운드 없음 — T가 무엇이든 항상 존재 ─────────────────────────────────
impl<T> Cage<T> {
    pub fn new(animal: T, cage_number: u32) -> Self {
        Cage {
            animal,
            cage_number,
            is_open: false,
            label: format!("우리 #{}", cage_number),
        }
    }
    pub fn with_label(mut self, label: &str) -> Self {
        self.label = label.to_string();
        self
    }

    pub fn cage_number(&self) -> u32  { self.cage_number }
    pub fn is_open(&self) -> bool     { self.is_open }
    pub fn label(&self) -> &str       { &self.label }

    // &T 반환 — T가 뭔지 몰라도 참조는 줄 수 있다
    // 호출자가 T의 구체 타입을 알면 T의 고유 메서드를 쓸 수 있다
    pub fn get_animal(&self) -> &T    { &self.animal }

    pub fn open(&mut self) {
        self.is_open = true;
        println!("    {} 문이 열렸다.", self.label);
    }
    pub fn close(&mut self) {
        self.is_open = false;
        println!("    {} 문이 닫혔다.", self.label);
    }
}

// ── T: Sound 바운드 — Sound 구현 타입일 때만 이 블록 활성화 ─────────────
impl<T: Sound> Cage<T> {
    pub fn animal_sound(&self) -> String {
        self.animal.make_sound()    // T: Sound 덕분에 가능
    }
    pub fn loud_animal(&self) {
        self.animal.loud_sound();
    }
}

// ── 패턴4: impl<T: Bound> Trait for Struct<T> ────────────────────────────
// "T가 Sound이면 Cage<T>도 자동으로 Display를 가진다"
//
//  Cage<Lion>   — Lion이 Sound → Display 생김   ✅
//  Cage<Duck>   — Duck이 Sound → Display 생김   ✅
//  Cage<Snake>  — Snake가 Sound → Display 생김  ✅
//  Cage<String> — String이 Sound 아님 → Display 없음 ❌
impl<T: Sound> fmt::Display for Cage<T> {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{} [{}] — {}",
            self.label,
            if self.is_open { "열림" } else { "잠김" },
            self.animal.make_sound())
    }
}

pub trait Describable { fn describe(&self); }

impl<T: Sound> Describable for Cage<T> {
    fn describe(&self) {
        println!("    {} [{}]: {}",
            self.label,
            if self.is_open { "열림" } else { "잠김" },
            self.animal.make_sound());
    }
}

// ── T: Sound + fmt::Display 이중 바운드 ──────────────────────────────────
// 동물 자체를 {} 로 출력할 때는 T: Display도 필요
impl<T: Sound + fmt::Display> Cage<T> {
    pub fn full_info(&self) {
        println!("    {} | 동물: {} | 소리: {}",
            self.label,
            self.animal,          // T: Display 덕분에 {} 가능
            self.animal.make_sound());
    }
}

pub fn run() {
    println!("\n─── 패턴3: impl<T> Cage<T> (제네릭 + 단형화) ───");

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    let nagini = Snake::new("Nagini", 8, true);
    let kaa    = Snake::new("Kaa", 5, false);

    // T에 무관한 메서드 — 어떤 타입이든 동작
    println!("\n  [T 무관 메서드]");
    let mut cage_lion  = Cage::new(simba, 1).with_label("사자 우리");
    let     cage_duck  = Cage::new(donald, 2).with_label("오리 연못");
    let mut cage_venom = Cage::new(nagini, 3).with_label("독사 우리 ⚠");
    let     cage_harm  = Cage::new(kaa, 4).with_label("무독 뱀 우리");

    cage_lion.open();
    cage_lion.close();
    println!("  label: {}", cage_lion.label());
    println!("  is_open: {}", cage_lion.is_open());

    // T: Sound 바운드 메서드
    println!("\n  [T: Sound 바운드 메서드]");
    println!("  {}", cage_lion.animal_sound());
    println!("  {}", cage_duck.animal_sound());
    println!("  {}", cage_venom.animal_sound());
    println!("  {}", cage_harm.animal_sound());

    // get_animal() — &T 반환 후 T의 고유 메서드 호출
    println!("\n  [get_animal() → T 고유 메서드]");
    println!("  Lion name: {}", cage_lion.get_animal().name());
    println!("  Duck feathers: {}", cage_duck.get_animal().feathers());
    println!("  Snake venomous: {}", cage_venom.get_animal().is_venomous());
    println!("  Snake length: {}cm", cage_harm.get_animal().length_cm());

    // Display (패턴4)
    println!("\n  [Display — T: Sound 조건부]");
    println!("  {}", cage_lion);
    println!("  {}", cage_duck);
    println!("  {}", cage_venom);

    // Describe
    println!("\n  [Describable]");
    cage_lion.open();
    cage_lion.describe();
    cage_venom.open();
    cage_venom.describe();

    // 이중 바운드 T: Sound + Display
    println!("\n  [full_info — T: Sound + Display]");
    cage_lion.full_info();
    cage_duck.full_info();
    cage_venom.full_info();
}
