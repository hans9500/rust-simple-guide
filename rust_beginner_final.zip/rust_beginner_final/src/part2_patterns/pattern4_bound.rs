// 패턴4는 pattern3_generic.rs 에 통합되어 있다.
// (impl<T: Sound> Display for Cage<T> 가 거기서 구현됨)
// 이 파일은 패턴4를 별도 실행 예제로 보여준다.

use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern3_generic::{Cage, Describable};

pub fn run() {
    println!("\n─── 패턴4: impl<T:Sound> Trait for Cage<T> (조건부) ───");

    // ─── 패턴4 핵심 ───────────────────────────────────────────────────────
    //
    //  문법:  impl<T: Sound> fmt::Display for Cage<T>
    //          ↑ T 선언   ↑ 조건        ↑ trait    ↑ 대상
    //
    //  "T가 Sound를 구현하면, Cage<T>는 자동으로 Display를 가진다."
    //  컴파일러가 Cage<Lion>, Cage<Duck>, Cage<Snake> 각각에 대해
    //  Display 구현을 생성한다 (단형화).
    //
    //  만약 Sound를 구현하지 않은 타입을 Cage에 넣으면:
    //    let cage = Cage::new(42u32, 1);
    //    println!("{}", cage);  // ← 컴파일 에러: Display not impl for Cage<u32>
    //                           //   (u32는 Sound 미구현)

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    let nagini = Snake::new("Nagini", 8, true);
    let kaa    = Snake::new("Kaa", 5, false);

    let mut cage1 = Cage::new(simba,  1).with_label("사자 우리");
    let     cage2 = Cage::new(donald, 2).with_label("오리 연못");
    let mut cage3 = Cage::new(nagini, 3).with_label("독사 우리");
    let     cage4 = Cage::new(kaa,    4).with_label("무독 뱀 우리");

    // Display — T: Sound 조건 충족 → 자동 구현
    println!("\n  [Display (T: Sound)]");
    println!("  {}", cage1);
    println!("  {}", cage2);
    println!("  {}", cage3);
    println!("  {}", cage4);

    // Describable trait
    println!("\n  [Describable (T: Sound)]");
    cage1.open();
    cage1.describe();
    cage2.describe();
    cage3.open();
    cage3.describe();
    cage4.describe();
}
