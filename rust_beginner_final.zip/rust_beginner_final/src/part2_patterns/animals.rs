// ┌───────────────────────────────────────────────────────────────────────┐
// │  공통 struct 선언 — Lion, Duck, Snake                                  │
// │                                                                       │
// │  use 경로 예시:                                                         │
// │    use crate::part2_patterns::animals::Lion;   절대 경로               │
// │    use super::animals::Lion;                   상대 경로               │
// │                                                                       │
// │  #[derive(Debug, Clone)]                                               │
// │    Debug  — {:?} / {:#?} 출력 자동 구현                                │
// │    Clone  — .clone() 자동 구현 (모든 필드가 Clone이어야 함)              │
// │                                                                       │
// │  String 필드가 있으면 Copy 불가:                                        │
// │    String은 힙을 소유하므로 비트 복사 시 double free 위험.               │
// │    Copy: Clone (Copy는 Clone의 서브트레이트).                           │
// │    Copy를 derive하려면 모든 필드가 Copy여야 한다.                        │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;

// ── Lion ─────────────────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct Lion {
    pub name:    String,
    pub age:     u32,
    pub hungry:  bool,
}

// ── Duck ─────────────────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct Duck {
    pub name:     String,
    pub age:      u32,
    pub feathers: u32,
}

// ── Snake ────────────────────────────────────────────────────────────────
//
//  Snake는 Lion/Duck과 달리 is_venomous 필드가 있다.
//  make_sound()가 is_venomous에 따라 분기되고,
//  Feed<Mouse>를 구현해 패턴5에서 세 번째 타입 예시로 활용된다.
#[derive(Debug, Clone)]
pub struct Snake {
    pub name:        String,
    pub age:         u32,
    pub is_venomous: bool,
    pub length_cm:   u32,   // Snake 고유 필드
}

// ─── 패턴1: impl Struct — 고유 메서드 ────────────────────────────────────

impl Lion {
    // 연관 상수 — Lion::MAX_AGE 로 접근. 인스턴스 없이 사용 가능.
    pub const MAX_AGE: u32 = 25;
    pub const SPECIES: &'static str = "Panthera leo";

    // 연관 함수(생성자)
    pub fn new(name: &str, age: u32) -> Self {
        Lion { name: name.to_string(), age, hungry: true }
    }

    // 빌더 패턴 — mut self 받아 수정 후 self 반환 → 체이닝
    pub fn with_age(mut self, age: u32) -> Self { self.age = age; self }
    pub fn with_hungry(mut self, hungry: bool) -> Self { self.hungry = hungry; self }

    // &self — 공유 빌림. 읽기만. 생략 규칙 3: fn name<'a>(&'a self) -> &'a str
    pub fn name(&self) -> &str      { &self.name }
    pub fn age(&self) -> u32        { self.age }
    pub fn is_hungry(&self) -> bool { self.hungry }
    pub fn is_senior(&self) -> bool { self.age > Self::MAX_AGE / 2 }

    pub fn status(&self) -> String {
        format!("{} ({}살, {}) — {}",
            self.name, self.age, Self::SPECIES,
            if self.hungry { "배고픔" } else { "배부름" })
    }

    // &mut self — 배타 빌림. let mut 필요.
    pub fn feed(&mut self) {
        if self.hungry {
            println!("    [Lion] {} 에게 먹이를 줬다.", self.name);
            self.hungry = false;
        } else {
            println!("    [Lion] {} 는 이미 배부르다.", self.name);
        }
    }
    pub fn birthday(&mut self) {
        self.age += 1;
        println!("    [Lion] {} 생일! 이제 {}살.", self.name, self.age);
    }
    pub fn set_hungry(&mut self, v: bool) { self.hungry = v; }

    // self — 소유권 소비. 호출 후 변수 무효.
    pub fn retire(self) -> String {
        format!("{} 은(는) 은퇴하여 자연으로 돌아갔다.", self.name)
    }

    // 복수 Lion을 받아 가장 나이 많은 것을 찾는 연관 함수
    pub fn eldest(lions: &[Lion]) -> Option<&Lion> {
        lions.iter().max_by_key(|l| l.age)
    }
}

impl Duck {
    pub const SPECIES: &'static str = "Anas platyrhynchos";

    pub fn new(name: &str, age: u32) -> Self {
        Duck { name: name.to_string(), age, feathers: 1000 }
    }
    pub fn with_feathers(mut self, f: u32) -> Self { self.feathers = f; self }

    pub fn name(&self) -> &str     { &self.name }
    pub fn age(&self) -> u32       { self.age }
    pub fn feathers(&self) -> u32  { self.feathers }
    pub fn is_molting(&self) -> bool { self.feathers < 500 }

    pub fn status(&self) -> String {
        format!("{} ({}살, {}) — 깃털 {}개{}",
            self.name, self.age, Self::SPECIES,
            self.feathers,
            if self.is_molting() { " [털갈이 중]" } else { "" })
    }

    pub fn lose_feathers(&mut self, count: u32) {
        self.feathers = self.feathers.saturating_sub(count);
        println!("    [Duck] {} 깃털 {}개 빠짐. 남은: {}",
            self.name, count, self.feathers);
    }
    pub fn regrow_feathers(&mut self) {
        self.feathers = 1000;
        println!("    [Duck] {} 깃털 재생 완료.", self.name);
    }
}

impl Snake {
    pub const SPECIES_VENOMOUS: &'static str = "Naja naja";
    pub const SPECIES_HARMLESS: &'static str = "Elaphe obsoleta";

    pub fn new(name: &str, age: u32, is_venomous: bool) -> Self {
        Snake {
            name: name.to_string(),
            age,
            is_venomous,
            length_cm: if is_venomous { 150 } else { 100 },
        }
    }
    pub fn with_length(mut self, cm: u32) -> Self { self.length_cm = cm; self }

    pub fn name(&self) -> &str           { &self.name }
    pub fn age(&self) -> u32             { self.age }
    pub fn is_venomous(&self) -> bool    { self.is_venomous }
    pub fn length_cm(&self) -> u32       { self.length_cm }
    pub fn species(&self) -> &'static str {
        if self.is_venomous { Self::SPECIES_VENOMOUS }
        else                { Self::SPECIES_HARMLESS }
    }

    pub fn status(&self) -> String {
        format!("{} ({}살, {}cm, {}) — {}",
            self.name, self.age, self.length_cm, self.species(),
            if self.is_venomous { "독사 ⚠" } else { "무독성" })
    }

    pub fn warn(&self) {
        if self.is_venomous {
            println!("    [Snake] ⚠ {} 주의! 독사입니다. 길이: {}cm",
                self.name, self.length_cm);
        } else {
            println!("    [Snake] {} 는 무독성입니다. 길이: {}cm",
                self.name, self.length_cm);
        }
    }
    pub fn shed_skin(&mut self) {
        self.length_cm += 5;
        println!("    [Snake] {} 탈피 완료. 길이: {}cm",
            self.name, self.length_cm);
    }
}

// ── fmt::Display 구현 ─────────────────────────────────────────────────────
// Zoo<T: Sound + Display> 에서 T를 {} 로 출력할 때 필요.
// 패턴4(조건부 trait)와 연쇄:
//   Lion: Sound + Display  →  Cage<Lion>: Display  →  Zoo<Lion>: Display

impl fmt::Display for Lion {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "Lion({}, {}살, {})",
            self.name, self.age,
            if self.hungry { "배고픔" } else { "배부름" })
    }
}

impl fmt::Display for Duck {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "Duck({}, {}살, 깃털{}개)", self.name, self.age, self.feathers)
    }
}

impl fmt::Display for Snake {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "Snake({}, {}살, {})",
            self.name, self.age,
            if self.is_venomous { "독사" } else { "무독성" })
    }
}
