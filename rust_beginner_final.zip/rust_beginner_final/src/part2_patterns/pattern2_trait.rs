// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴2: impl Trait for Struct — trait 구현                             │
// │                                                                       │
// │  trait은 "이런 기능이 있어야 한다"는 약속(계약)이다.                     │
// │  필수 메서드: 구현 안 하면 컴파일 에러.                                  │
// │  기본 메서드: 구현 안 하면 기본 버전 사용. 오버라이드 가능.               │
// └───────────────────────────────────────────────────────────────────────┘

// ─── fat pointer 메모리 레이아웃 (64비트 기준) ────────────────────────────
//
//  일반 참조 &Lion (8바이트):
//  스택
//  ┌──────────────────┐
//  │  data_ptr (8B) ──┼──▶ Lion { name_ptr, name_len, name_cap, age, hungry }
//  └──────────────────┘
//
//  &dyn Sound (fat pointer, 16바이트):
//  스택
//  ┌──────────────────┐
//  │  data_ptr  (8B)──┼──▶ Lion { name_ptr, name_len, name_cap, age, hungry }
//  ├──────────────────┤
//  │  vtable_ptr(8B)──┼──▶ ┌─────────────────────────────────────────────┐
//  └──────────────────┘    │  LION_SOUND_VTABLE  (컴파일러 생성 static)  │
//                          ├─────────────────────────────────────────────┤
//                          │  size        = size_of::<Lion>()            │
//                          │  align       = align_of::<Lion>()           │
//                          │  drop_fn   ──┼──▶ drop_in_place::<Lion>    │
//                          │  make_sound──┼──▶ Lion::make_sound (fn ptr)│
//                          │  loud_sound──┼──▶ Lion::loud_sound (fn ptr)│
//                          └─────────────────────────────────────────────┘
//
//  Box<dyn Sound> (스택 16바이트, 데이터는 힙):
//  스택
//  ┌──────────────────┐
//  │  data_ptr  (8B)──┼──▶ 힙: Lion 데이터  ← Box가 소유, drop 시 해제
//  ├──────────────────┤
//  │  vtable_ptr(8B)──┼──▶ static LION_SOUND_VTABLE (위와 동일)
//  └──────────────────┘
//  라이프타임 제약 없음 — 힙에 있으므로 원본 스택 변수 불필요
//
//  Box<&dyn Sound> (스택 8바이트, 힙에 fat pointer):
//  스택
//  ┌──────────────────┐
//  │  heap_ptr  (8B)──┼──▶ 힙 (16바이트): { data_ptr, vtable_ptr }
//  └──────────────────┘    data_ptr이 가리키는 실제 데이터는 소유 안 함
//  라이프타임 제약 여전히 있음 — 거의 사용하지 않음
//
// ─── 세 가지 비교 요약 ───────────────────────────────────────────────────
//
//  ┌──────────────────┬──────────────────┬──────────────────────────────┐
//  │                  │  &dyn Sound      │  Box<dyn Sound>              │
//  ├──────────────────┼──────────────────┼──────────────────────────────┤
//  │ 포인터 크기       │ 16B (fat ptr)   │ 16B (fat ptr)                │
//  │ 데이터 위치       │ 스택/힙 (소유×) │ 힙 (소유 ○)                  │
//  │ 라이프타임 제약   │ 있음            │ 없음 ('static 불필요)         │
//  │ 소유권            │ 빌림            │ 소유 (drop 시 해제)           │
//  │ Vec에 여러 타입   │ Vec<&dyn> OK    │ Vec<Box<dyn>> OK             │
//  └──────────────────┴──────────────────┴──────────────────────────────┘
//
// ─── &dyn vs &impl vs impl(값) ────────────────────────────────────────────
//
//  ┌────────────────┬──────────────────┬──────────────────────────────┐
//  │                │  &dyn Sound      │  &impl / impl Sound          │
//  ├────────────────┼──────────────────┼──────────────────────────────┤
//  │ 디스패치       │ 런타임 (vtable)  │ 컴파일 타임 (단형화)           │
//  │ 포인터 크기    │ 16B fat ptr      │ 8B (&impl) / 타입크기(값)     │
//  │ 인라인 최적화  │ 불가             │ 가능                           │
//  │ 여러 타입 혼합 │ Vec<&dyn> OK     │ 불가 (타입 고정)               │
//  │ object safety  │ 필요             │ 불필요                         │
//  └────────────────┴──────────────────┴──────────────────────────────┘

use crate::part2_patterns::animals::{Lion, Duck, Snake};

pub trait Sound {
    fn make_sound(&self) -> String;         // 필수 구현

    fn loud_sound(&self) {                  // 기본 구현 — 오버라이드 가능
        println!("    {}!!!", self.make_sound().to_uppercase());
    }

    fn describe_sound(&self) {              // 기본 구현 — make_sound 활용
        println!("    소리: \"{}\"", self.make_sound());
    }
}

impl Sound for Lion {
    fn make_sound(&self) -> String {
        format!("{}: 으르렁~", self.name)
    }
    // loud_sound: 기본 구현 그대로
    // describe_sound: 기본 구현 그대로
}

impl Sound for Duck {
    fn make_sound(&self) -> String {
        format!("{}: 꽥꽥!", self.name)
    }
    fn loud_sound(&self) {          // 오버라이드 — 오리는 크게 안 운다
        println!("    (조용히) {}", self.make_sound());
    }
}

impl Sound for Snake {
    fn make_sound(&self) -> String {
        // is_venomous에 따라 분기 — Snake 고유 필드 활용
        if self.is_venomous {
            format!("{}: 쉬이익!!! (독 경고)", self.name)
        } else {
            format!("{}: 스스스...", self.name)
        }
    }
    fn loud_sound(&self) {          // 뱀도 오버라이드
        if self.is_venomous {
            println!("    ⚠ 위험! {}", self.make_sound().to_uppercase());
        } else {
            println!("    (스르륵) {}", self.make_sound());
        }
    }
}

// ── &dyn Sound — 런타임, fat pointer ────────────────────────────────────
pub fn hold_concert_dyn(animals: &[&dyn Sound]) {
    println!("    === 합창 (&dyn Sound, fat pointer) ===");
    for a in animals { a.loud_sound(); }
}

// ── &impl Sound — 컴파일 타임, 단형화 ────────────────────────────────────
// fn f(a: &impl Sound)  ≡  fn f<T: Sound>(a: &T)  (문법적 설탕)
pub fn solo_ref_impl(label: &str, animal: &impl Sound) {
    print!("    {}: ", label);
    animal.describe_sound();
}

// ── impl Sound (값) — 소유권 이동, 함수 끝에서 drop ──────────────────────
pub fn solo_val_impl(animal: impl Sound) {
    println!("    [값으로 받음, 함수 끝에서 drop]");
    animal.loud_sound();
}

// ── Box<dyn Sound> — 힙 소유, 여러 타입 혼합, 라이프타임 제약 없음 ────────
pub fn zoo_concert(animals: &[Box<dyn Sound>]) {
    println!("    === 동물원 공연 (Box<dyn Sound>) ===");
    for a in animals { a.describe_sound(); }
}

pub fn run() {
    println!("\n─── 패턴2: impl Trait for Struct + dyn/impl 디스패치 ───");

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    let nagini = Snake::new("Nagini", 8, true);
    let kaa    = Snake::new("Kaa", 5, false);

    // 각 타입의 make_sound
    println!("\n  [make_sound — 타입별]");
    println!("  {}", simba.make_sound());
    println!("  {}", donald.make_sound());
    println!("  {}", nagini.make_sound());
    println!("  {}", kaa.make_sound());

    // loud_sound — Lion: 기본, Duck/Snake: 오버라이드
    println!("\n  [loud_sound — 기본 vs 오버라이드]");
    simba.loud_sound();    // 기본: 대문자 !!!
    donald.loud_sound();   // 오버라이드: 조용히
    nagini.loud_sound();   // 오버라이드: ⚠ 위험
    kaa.loud_sound();      // 오버라이드: 스르륵

    // &dyn Sound — Vec에 여러 타입 혼합
    println!("\n  [&dyn Sound — 여러 타입 혼합]");
    let animals: Vec<&dyn Sound> = vec![&simba, &donald, &nagini, &kaa];
    hold_concert_dyn(&animals);

    // &impl Sound — 단형화
    println!("\n  [&impl Sound — 단형화]");
    solo_ref_impl("Lion", &simba);
    solo_ref_impl("Duck", &donald);
    solo_ref_impl("Snake(독)", &nagini);
    solo_ref_impl("Snake(무독)", &kaa);

    // impl Sound (값) — 소유권 이동
    println!("\n  [impl Sound (값) — 소유권 이동]");
    solo_val_impl(Lion::new("복사본 사자", 1));

    // Box<dyn Sound> — 힙 소유, 라이프타임 제약 없음
    println!("\n  [Box<dyn Sound> — 힙 소유]");
    let boxed: Vec<Box<dyn Sound>> = vec![
        Box::new(Lion::new("Scar", 9)),
        Box::new(Duck::new("Daffy", 4)),
        Box::new(Snake::new("Cobra", 6, true)),
        Box::new(Snake::new("Garter", 3, false)),
    ];
    zoo_concert(&boxed);
}
