// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴9: -> impl Trait  (반환 위치 impl Trait)                          │
// │                                                                       │
// │  공식 문서: Rust Book Ch.10.2, Rust Reference "impl Trait type"        │
// │                                                                       │
// │  두 가지 사용 위치:                                                     │
// │    인자 위치: fn f(x: impl Trait)      → fn f<T: Trait>(x: T) 와 동일  │
// │    반환 위치: fn f() -> impl Trait     → 구체 타입을 숨김               │
// │                                                                       │
// │  반환 위치 impl Trait가 필요한 이유:                                     │
// │    클로저: 타입 이름이 없어서 Box<dyn Fn> 없이 반환 가능                 │
// │    Iterator 체이닝: Map<Filter<...>> 같은 긴 타입을 숨길 수 있음         │
// │    구현 세부사항 은닉: 라이브러리 API에서 내부 타입 노출 방지             │
// │                                                                       │
// │  제약:                                                                 │
// │    반환 타입이 하나로 고정 — 분기에 따라 다른 타입 반환 불가             │
// │    (그럴 때는 Box<dyn Trait> 사용)                                      │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use crate::part2_patterns::animals::{Lion, Duck};
use crate::part2_patterns::pattern2_trait::Sound;

// ── 인자 위치 impl Trait ──────────────────────────────────────────────────
// fn f(animal: impl Sound) 는 fn f<T: Sound>(animal: T) 와 완전히 동일
// 차이: impl Trait는 타입 파라미터 이름이 없어서 더 간결
fn describe(animal: impl Sound + fmt::Display) -> String {
    format!("{} → {}", animal, animal.make_sound())
}

// ── 반환 위치 impl Trait: 클로저 반환 ────────────────────────────────────
// 클로저는 이름이 없는 타입 → Box<dyn Fn> 없이 반환하려면 impl Fn 사용
fn make_sound_checker(min_len: usize) -> impl Fn(&str) -> bool {
    // move: min_len 캡처
    move |sound| sound.len() >= min_len
}

fn make_greeter(zoo_name: &str) -> impl Fn(&str) -> String + '_ {
    move |animal| format!("{} 에 오신 {} 환영합니다!", zoo_name, animal)
}

// ── 반환 위치 impl Trait: Iterator 반환 ──────────────────────────────────
// Map<Filter<...>> 같은 복잡한 타입을 impl Iterator로 숨김
fn adult_animals<'a>(animals: &'a [(&'a str, u32)]) -> Vec<&'a str> {
    animals.iter()
        .filter(|(_, age)| *age >= 5)
        .map(|(name, _)| *name)
        .collect()
}

fn doubled_ages(animals: &[(&str, u32)]) -> Vec<u32> {
    animals.iter().map(|(_, age)| age * 2).collect()
}

// ── 반환 위치 impl Trait: 구현 은닉 ──────────────────────────────────────
struct ZooDisplay {
    items: Vec<String>,
}

impl fmt::Display for ZooDisplay {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "[{}]", self.items.join(", "))
    }
}

// 반환 타입이 ZooDisplay인지 사용자는 몰라도 됨
fn create_zoo_display(names: &[&str]) -> impl fmt::Display {
    ZooDisplay {
        items: names.iter().map(|s| s.to_string()).collect(),
    }
}

// ── 제약: 분기에 따라 다른 타입은 불가 ───────────────────────────────────
// fn animal_sound(is_lion: bool) -> impl Sound {
//     if is_lion { Lion::new("A", 1) }  // Lion 타입
//     else       { Duck::new("B", 1) }  // Duck 타입 → 에러! 타입이 달라
// }
//
// 해결: Box<dyn Sound>
fn animal_sound_dyn(is_lion: bool) -> Box<dyn Sound> {
    if is_lion { Box::new(Lion::new("Simba", 5)) }
    else       { Box::new(Duck::new("Donald", 3)) }
}

pub fn run() {
    println!("\n  [패턴9: -> impl Trait 반환]");

    // 인자 위치
    println!("\n  ── 인자 위치 impl Trait ──");
    let lion = Lion::new("Simba", 5);
    let duck = Duck::new("Donald", 3);
    println!("  {}", describe(lion));
    println!("  {}", describe(duck));

    // 반환: 클로저
    println!("\n  ── 반환: 클로저 (impl Fn) ──");
    let check_long  = make_sound_checker(4);
    let check_short = make_sound_checker(2);
    let sounds = ["으르렁", "꽥", "쉭쉭쉭"];
    for s in &sounds {
        println!("  '{}' 길이 4↑: {}, 길이 2↑: {}",
            s, check_long(s), check_short(s));
    }

    let greet = make_greeter("서울 동물원");
    println!("  {}", greet("사자"));
    println!("  {}", greet("오리"));

    // 반환: Iterator
    println!("\n  ── 반환: Iterator (impl Iterator) ──");
    let animals = vec![("Simba",5u32),("Donald",3),("Nagini",8),("Dumbo",10)];
    let adults: Vec<&str> = adult_animals(&animals);
    println!("  5살 이상: {:?}", adults);
    let doubled: Vec<u32> = doubled_ages(&animals);
    println!("  나이 2배: {:?}", doubled);

    // 반환: 구현 은닉
    println!("\n  ── 반환: 구현 은닉 (impl Display) ──");
    let display = create_zoo_display(&["사자","오리","뱀"]);
    println!("  {}", display);

    // impl vs Box<dyn>
    println!("\n  ── impl Trait vs Box<dyn Trait> ──");
    let s1 = animal_sound_dyn(true);
    let s2 = animal_sound_dyn(false);
    println!("  Box<dyn>: {}, {}", s1.make_sound(), s2.make_sound());

    println!("\n  ── 패턴9 정리 ──");
    println!("  인자: fn f(x: impl T)    → 단형화, 컴파일 타임, 성능 최고");
    println!("  반환: fn f() -> impl T   → 타입 은닉, 클로저/Iterator 반환");
    println!("  제약: 반환 타입 하나로 고정 → 분기 다른 타입은 Box<dyn T>");
}
