// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴5: trait Feed<F> — trait 자체가 제네릭                             │
// │                                                                       │
// │  패턴2와의 결정적 차이:                                                  │
// │    패턴2: 하나의 타입에 하나의 구현만 가능                               │
// │    패턴5: F가 다르면 동일 타입에 별도 구현 가능                          │
// │                                                                       │
// │  Lion: Feed<Meat> + Feed<Fish>    둘 다 OK                             │
// │  Duck: Feed<Grain>                하나만                               │
// │  Snake: Feed<Mouse> + Feed<Frog>  둘 다 OK (새로 추가)                 │
// └───────────────────────────────────────────────────────────────────────┘
use crate::part2_patterns::animals::{Lion, Duck, Snake};

// 먹이 타입들
#[derive(Debug)] pub struct Meat  { pub weight_kg: f64 }
#[derive(Debug)] pub struct Fish  { pub count: u32 }
#[derive(Debug)] pub struct Grain { pub grams: u32 }
#[derive(Debug)] pub struct Mouse { pub count: u32 }   // Snake 전용
#[derive(Debug)] pub struct Frog  { pub count: u32 }   // Snake 전용

pub trait Feed<F> {
    fn eat(&mut self, food: F);
    fn can_eat() -> &'static str where Self: Sized { "알 수 없는 먹이" }
}

// Lion: Feed<Meat>
impl Feed<Meat> for Lion {
    fn eat(&mut self, food: Meat) {
        println!("    [Lion] {} 고기 {}kg 섭취. (배고픔: {} → false)",
            self.name, food.weight_kg, self.hungry);
        self.hungry = false;
    }
    fn can_eat() -> &'static str { "고기 (Meat)" }
}

// Lion: Feed<Fish> — 같은 Lion에 두 번째 Feed 구현
impl Feed<Fish> for Lion {
    fn eat(&mut self, food: Fish) {
        println!("    [Lion] {} 생선 {}마리 섭취.",
            self.name, food.count);
        self.hungry = false;
    }
    fn can_eat() -> &'static str { "생선 (Fish)" }
}

// Duck: Feed<Grain>
impl Feed<Grain> for Duck {
    fn eat(&mut self, food: Grain) {
        println!("    [Duck] {} 곡물 {}g 섭취.",
            self.name, food.grams);
    }
    fn can_eat() -> &'static str { "곡물 (Grain)" }
}

// Snake: Feed<Mouse> — Snake 첫 번째 먹이
impl Feed<Mouse> for Snake {
    fn eat(&mut self, food: Mouse) {
        println!("    [Snake] {} 쥐 {}마리 섭취. (독: {})",
            self.name, food.count, self.is_venomous);
    }
    fn can_eat() -> &'static str { "쥐 (Mouse)" }
}

// Snake: Feed<Frog> — Snake 두 번째 먹이
impl Feed<Frog> for Snake {
    fn eat(&mut self, food: Frog) {
        println!("    [Snake] {} 개구리 {}마리 섭취.",
            self.name, food.count);
    }
    fn can_eat() -> &'static str { "개구리 (Frog)" }
}

pub fn run() {
    println!("\n─── 패턴5: trait Feed<F> (제네릭 trait) ───");

    println!("\n  [Lion: Feed<Meat> + Feed<Fish> 둘 다]");
    let mut simba = Lion::new("Simba", 5);
    println!("  Lion can eat Meat: {}", <Lion as Feed<Meat>>::can_eat());
    println!("  Lion can eat Fish: {}", <Lion as Feed<Fish>>::can_eat());
    simba.eat(Meat { weight_kg: 5.0 });
    simba.eat(Fish { count: 3 });
    // simba.eat(Grain { grams: 100 }); // 컴파일 에러: Feed<Grain> not impl for Lion

    println!("\n  [Duck: Feed<Grain>만]");
    let mut donald = Duck::new("Donald", 3);
    println!("  Duck can eat Grain: {}", <Duck as Feed<Grain>>::can_eat());
    donald.eat(Grain { grams: 200 });

    println!("\n  [Snake: Feed<Mouse> + Feed<Frog> 둘 다]");
    let mut nagini = Snake::new("Nagini", 8, true);
    let mut kaa    = Snake::new("Kaa", 5, false);
    println!("  Snake can eat Mouse: {}", <Snake as Feed<Mouse>>::can_eat());
    println!("  Snake can eat Frog:  {}", <Snake as Feed<Frog>>::can_eat());
    nagini.eat(Mouse { count: 2 });
    nagini.eat(Frog  { count: 1 });
    kaa.eat(Mouse { count: 1 });
    kaa.eat(Frog  { count: 3 });

    println!("\n  [패턴5 핵심: F가 다르면 같은 타입에 여러 구현]");
    println!("  Lion: Feed<Meat>, Feed<Fish> — 2개의 eat() 구현");
    println!("  Duck: Feed<Grain>            — 1개의 eat() 구현");
    println!("  Snake: Feed<Mouse>, Feed<Frog> — 2개의 eat() 구현");
}
