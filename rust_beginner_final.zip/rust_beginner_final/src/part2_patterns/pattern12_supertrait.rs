// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴12: 수퍼트레이트(Supertrait)                                      │
// │                                                                       │
// │  공식 문서: Rust Reference "Supertraits"                               │
// │                                                                       │
// │  trait A: B { }                                                       │
// │    → A를 구현하려면 B도 반드시 구현해야 한다                             │
// │    → A 구현체는 B의 메서드도 사용 가능                                   │
// │    → B를 A의 수퍼트레이트(supertrait)라고 부름                          │
// │                                                                       │
// │  표준 라이브러리 예:                                                    │
// │    trait Eq: PartialEq          → Eq 구현 시 PartialEq 필요            │
// │    trait Ord: Eq + PartialOrd   → Ord 구현 시 Eq+PartialOrd 필요       │
// │    trait Copy: Clone            → Copy 구현 시 Clone 필요              │
// │    trait Error: Debug + Display → Error 구현 시 Debug+Display 필요     │
// └───────────────────────────────────────────────────────────────────────┘

use std::fmt;
use crate::part2_patterns::pattern2_trait::Sound;

// ── 기본 수퍼트레이트 ─────────────────────────────────────────────────────
// Named: 이름이 있다
// Display: 출력 가능하다 (std 수퍼트레이트)
pub trait Named: fmt::Display {
    fn name(&self) -> &str;

    // 수퍼트레이트 메서드(Display) 사용 가능
    fn greeting(&self) -> String {
        format!("안녕, 나는 {} 이야!", self)  // self: Display 보장
    }
}

// ── 복수 수퍼트레이트 ─────────────────────────────────────────────────────
// ZooAnimal: Named + Sound 둘 다 구현해야
pub trait ZooAnimal: Named + Sound {
    fn introduce(&self) -> String {
        // Named, Sound 메서드 모두 사용 가능
        format!("{} 이(가) 말합니다: {}",
            self.name(),         // Named
            self.make_sound()    // Sound
        )
    }
}

// ── 구현 ──────────────────────────────────────────────────────────────────
#[derive(Debug)]
struct Lion {
    name:    String,
    species: String,
}

impl Lion {
    fn new(name: &str) -> Self {
        Lion { name: name.to_string(), species: "사자".to_string() }
    }
}

// Display 구현 (Named의 수퍼트레이트)
impl fmt::Display for Lion {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{} ({})", self.name, self.species)
    }
}

// Named 구현 — Display 이미 구현했으므로 OK
impl Named for Lion {
    fn name(&self) -> &str { &self.name }
}

// Sound 구현
impl Sound for Lion {
    fn make_sound(&self) -> String { "으르렁".to_string() }
}

// ZooAnimal 구현 — Named + Sound 이미 구현했으므로 OK
impl ZooAnimal for Lion {}

// ── Named 없이 ZooAnimal 직접 구현 시도 시 에러 ──────────────────────────
// struct Cat;
// impl ZooAnimal for Cat { }
// → 에러: trait Named not satisfied
// → 에러: trait Sound not satisfied

// ── 수퍼트레이트 체인 ─────────────────────────────────────────────────────
// A: B: C  → A 구현 시 B와 C 모두 필요
trait Describable: Named {
    fn describe(&self) -> String;
}

trait FullDescribable: Describable + Sound {
    fn full_report(&self) -> String {
        format!("{} | 소리: {}", self.describe(), self.make_sound())
    }
}

impl Describable for Lion {
    fn describe(&self) -> String {
        format!("{} — {}", self.name(), self.species)
    }
}

impl FullDescribable for Lion {}

// ── 함수에서 수퍼트레이트 활용 ───────────────────────────────────────────
// ZooAnimal bound 하나로 Named + Sound 모두 보장
fn present_animal(animal: &dyn ZooAnimal) {
    println!("    {}", animal.introduce());
    println!("    인사: {}", animal.greeting());
}

pub fn run() {
    println!("\n  [패턴12: 수퍼트레이트(Supertrait)]");

    let lion = Lion::new("Simba");

    // Named 메서드 + 기본 구현
    println!("\n  ── Named 수퍼트레이트 ──");
    println!("  name(): {}", lion.name());
    println!("  greeting(): {}", lion.greeting()); // Named 기본 구현

    // ZooAnimal — Named + Sound 합성
    println!("\n  ── ZooAnimal (Named + Sound) ──");
    println!("  introduce(): {}", lion.introduce());

    // dyn 수퍼트레이트
    println!("\n  ── dyn ZooAnimal ──");
    present_animal(&lion);

    // 체인
    println!("\n  ── Describable + FullDescribable 체인 ──");
    println!("  describe(): {}", lion.describe());
    println!("  full_report(): {}", lion.full_report());

    // 표준 라이브러리 예
    println!("\n  ── 표준 라이브러리 수퍼트레이트 예 ──");
    println!("  trait Eq: PartialEq    → ==, != 보장");
    println!("  trait Ord: Eq+PartialOrd → 완전 정렬 보장");
    println!("  trait Copy: Clone      → 복사 시 Clone도 가능 보장");
    println!("  trait Error: Debug+Display → 에러 출력 보장");

    println!("\n  ── 패턴12 정리 ──");
    println!("  trait A: B            → A 구현 시 B 필수");
    println!("  trait A: B + C        → A 구현 시 B와 C 필수");
    println!("  A 구현체에서 B 메서드 자유롭게 사용 가능");
    println!("  fn f(x: &dyn A)       → x에서 B 메서드도 호출 가능");
}
