// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 2.  impl 패턴 1~7                                                ║
// ║                                                                       ║
// ║  패턴1  impl Struct              고유 메서드                            ║
// ║  패턴2  impl Trait for Struct    trait 구현 + dyn                      ║
// ║  패턴3  impl<T> Struct<T>        제네릭 고유 메서드, 단형화              ║
// ║  패턴4  impl<T:B> Trait for S<T> 조건부 trait 구현                     ║
// ║  패턴5  trait Trait<F>           제네릭 trait                          ║
// ║  패턴6  trait Trait{type Out}    연관 타입                              ║
// ║  패턴7  impl<T:B> Trait for T    블랭킷 구현                           ║
// ╚═══════════════════════════════════════════════════════════════════════╝

// ── pub mod: 이 모듈들을 외부에서도 접근 가능하게 공개 ────────────────────
pub mod animals;              // 공통 struct (Lion, Duck, Snake)
pub mod pattern1_impl;        // 패턴1: impl Struct
pub mod pattern2_trait;       // 패턴2: impl Trait for Struct
pub mod pattern3_generic;     // 패턴3: impl<T> Struct<T>
pub mod pattern4_bound;       // 패턴4: impl<T:B> Trait for Struct<T>
pub mod pattern5_generic_trait; // 패턴5: trait Feed<F>
pub mod pattern6_assoc_type;  // 패턴6: 연관 타입
pub mod pattern7_blanket;     // 패턴7: 블랭킷 구현
pub mod zoo;                  // Zoo<T> 통합

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 2: impl 패턴 1~7");
    println!("══════════════════════════════════════════════════════════");
    pattern1_impl::run();
    pattern2_trait::run();
    pattern3_generic::run();
    pattern4_bound::run();
    pattern5_generic_trait::run();
    pattern6_assoc_type::run();
    pattern7_blanket::run();
    zoo::run();
    patterns_advanced::run();
    builder_pattern::run();
    pattern8_impl_display::run();
    pattern9_return_impl::run();
    pattern10_type_alias::run();
    pattern11_where::run();
    pattern12_supertrait::run();
    pattern_generic_deep::run();
}
pub mod patterns_advanced;
pub mod builder_pattern;
pub mod pattern8_impl_display;
pub mod pattern9_return_impl;
pub mod pattern10_type_alias;
pub mod pattern11_where;
pub mod pattern12_supertrait;
pub mod pattern_generic_deep;
