// ┌─────────────────────────────────────────────────────────────────────┐
// │  소유권 관점의 mut 패턴 완전 정리                                     │
// │                                                                     │
// │  세 가지 패턴:                                                       │
// │    A. value: &mut T   → 가변 참조로 받음. 원본 수정 가능             │
// │    B. mut value: T    → 값을 받아 로컬에서만 수정                    │
// │    C. &mut value: &mut T → 패턴 매칭으로 자동 역참조 (A와 동일)      │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  패턴 A: value: &mut T                                              │
// │                                                                     │
// │  fn add_one(value: &mut i32) { *value += 1; }                      │
// │                                                                     │
// │  메모리 구조:                                                        │
// │  호출자: [x: 5] ◀──&mut── [value: ptr] :add_one 스택               │
// │                                                                     │
// │  호출: add_one(&mut x)  →  x = 6  (원본 변경)                      │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  패턴 B: mut value: T  (Copy 타입 — i32, f64 등)                   │
// │                                                                     │
// │  fn add_one(mut value: i32) { value += 1; }                        │
// │                                                                     │
// │  메모리 구조:                                                        │
// │  호출자: [x: 5] ──복사──▶ [value: 5] :add_one 스택                 │
// │                                                                     │
// │  호출: add_one(x)  →  x 여전히 5  (원본 불변)                       │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  패턴 B: mut value: T  (String — 소유권 이동)                       │
// │                                                                     │
// │  fn greet(mut s: String) { s.push('!'); }                          │
// │                                                                     │
// │  메모리 구조:                                                        │
// │  호출자: [name: 무효] ──move──▶ [s: 소유] :greet 스택              │
// │                                                                     │
// │  호출: greet(name)  →  name 무효(moved). 원본 사용 불가             │
// │  → 원본도 수정하려면 &mut String 사용                                │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  선택 기준 요약                                                      │
// │                                                                     │
// │  원본을 수정해야 함        →  value: &mut T   (패턴 A)              │
// │  읽기만 / 복사본 수정      →  mut value: T    (패턴 B, Copy)        │
// │  소유권 이동 + 로컬 수정   →  mut value: T    (패턴 B, non-Copy)    │
// └─────────────────────────────────────────────────────────────────────┘

pub fn run() {
    println!("\n  [소유권 관점의 mut 패턴]");
    demo_pattern_a();
    demo_pattern_b_copy();
    demo_pattern_b_move();
    demo_pattern_c();
    demo_struct();
}

fn demo_pattern_a() {
    println!("\n  ── 패턴 A: value: &mut T ──");

    fn add_one(value: &mut i32) {
        *value += 1;
    }
    let mut x = 5;
    add_one(&mut x);
    println!("  add_one(&mut x): x = {} (원본 변경)", x);

    fn append(s: &mut String) {
        s.push_str(" 사자");
    }
    let mut name = String::from("Simba");
    append(&mut name);
    println!("  append(&mut name): {}", name);

    fn scale(v: &mut Vec<i32>, factor: i32) {
        for x in v.iter_mut() { *x *= factor; }
    }
    let mut nums = vec![1, 2, 3];
    scale(&mut nums, 10);
    println!("  scale(&mut nums, 10): {:?}", nums);
}

fn demo_pattern_b_copy() {
    println!("\n  ── 패턴 B: mut value: T (Copy 타입) ──");

    fn add_one(mut value: i32) -> i32 {
        value += 1;
        value
    }
    let x = 5;
    let result = add_one(x);
    println!("  x={}, add_one(x)={} (x 불변)", x, result);

    fn celsius_to_f(mut c: f64) -> f64 {
        c = c * 9.0 / 5.0 + 32.0;
        c
    }
    let temp = 100.0f64;
    println!("  {}°C = {}°F (temp 불변)", temp, celsius_to_f(temp));
}

fn demo_pattern_b_move() {
    println!("\n  ── 패턴 B: mut value: T (소유권 이동) ──");

    fn process(mut s: String) -> String {
        s.push_str("!");
        s.to_uppercase()
    }
    let name = String::from("simba");
    let result = process(name);
    // name 은 moved — 사용 불가
    println!("  process(name): {}", result);

    // 원본도 수정하려면 &mut
    fn process_ref(s: &mut String) {
        s.push_str("!");
        *s = s.to_uppercase();
    }
    let mut name2 = String::from("simba");
    process_ref(&mut name2);
    println!("  process_ref(&mut name2): {}", name2);
}

fn demo_pattern_c() {
    println!("\n  ── 패턴 C: &mut value: &mut T (A와 동일) ──");

    // &mut value 패턴 매칭 — value 가 i32 처럼 직접 사용됨
    fn add_one_c(value: &mut i32) {
        *value += 1;  // &mut value 패턴과 동일 동작
    }
    let mut x = 10;
    add_one_c(&mut x);
    println!("  add_one_c(&mut x): x = {}", x);
    println!("  → 패턴A(value: &mut i32 + *value)와 동일 동작");
}

fn demo_struct() {
    println!("\n  ── 구조체에서의 mut 패턴 ──");

    #[derive(Debug)]
    struct Animal { name: String, age: u32 }

    // &mut self — 메서드에서 원본 수정
    impl Animal {
        fn birthday(&mut self) {
            self.age += 1;
        }
        fn rename(&mut self, new_name: &str) {
            self.name = new_name.to_string();
        }
    }

    let mut lion = Animal { name: "Simba".to_string(), age: 4 };
    lion.birthday();
    lion.rename("Mufasa");
    println!("  생일+이름변경: {:?}", lion);

    // 함수로 넘길 때
    fn grow(animal: &mut Animal) {
        animal.age += 2;
    }
    grow(&mut lion);
    println!("  grow 후: age = {}", lion.age);
}
