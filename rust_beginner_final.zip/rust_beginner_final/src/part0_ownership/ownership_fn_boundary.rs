// ┌──────────────────────────────────────────────────────────────────
// │ Part 0-4: 함수 경계에서의 소유권
// │
// │ 함수 호출 시 세 가지 선택:
// │   1. 소유권 이동 (T)      — 함수가 값을 완전히 소비
// │   2. 불변 빌림 (&T)       — 읽기만, 여러 곳에서 동시 가능
// │   3. 가변 빌림 (&mut T)   — 읽기+쓰기, 단 하나만
// │
// │ 반환값:
// │   - 새로 만든 값 → 소유권을 호출자에게
// │   - 입력의 일부 → 라이프타임 연결
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [Part 0-4: 함수 경계 소유권]");
    demo_move_into_fn();
    demo_borrow_into_fn();
    demo_mut_borrow_into_fn();
    demo_return_ownership();
    demo_practical_patterns();
}

// ── 1. 소유권 이동 (T) ───────────────────────────────────────────
fn retire_animal(name: String) -> String {
    // name 소유권 획득 → 함수 내에서 자유롭게 사용
    format!("{} 은(는) 은퇴했습니다.", name)
    // name 여기서 drop (메시지로 변환 후)
}

fn demo_move_into_fn() {
    println!("\n  ── 1. 소유권 이동 (T) ──");

    let name = String::from("Simba");
    let msg  = retire_animal(name);  // name 소유권 이동
    // println!("{}", name);  // 에러: use of moved value
    println!("  {}", msg);

    // Clone으로 원본 유지
    let name2 = String::from("Donald");
    let msg2  = retire_animal(name2.clone());  // clone → 원본 유지
    println!("  {}", msg2);
    println!("  원본 유효: {}", name2);  // clone이므로 여전히 유효
}

// ── 2. 불변 빌림 (&T) ──────────────────────────────────────────
fn describe_animal(name: &str, age: u32) -> String {
    // name 빌림 — 소유권 없음, 읽기만
    format!("{} ({}살)", name, age)
}

fn print_all_animals(animals: &[(String, u32)]) {
    // slice 빌림 — 원본 소비하지 않음
    for (name, age) in animals {
        println!("    - {}", describe_animal(name, *age));
    }
}

fn demo_borrow_into_fn() {
    println!("\n  ── 2. 불변 빌림 (&T) ──");

    let lion  = String::from("Simba");
    let duck  = String::from("Donald");
    let snake = String::from("Nagini");

    // 빌림 — 여러 번, 여러 곳에서 동시 가능
    println!("  {}", describe_animal(&lion, 5));
    println!("  {}", describe_animal(&duck, 3));
    println!("  {}", describe_animal(&snake, 8));

    // 원본 모두 유효
    println!("  원본 유효: {}, {}, {}", lion, duck, snake);

    let animals = vec![
        (String::from("Simba"),  5u32),
        (String::from("Donald"), 3),
        (String::from("Nagini"), 8),
    ];
    println!("  전체 목록:");
    print_all_animals(&animals);  // 슬라이스 빌림
    println!("  목록 원본 유효: {} 마리", animals.len());
}

// ── 3. 가변 빌림 (&mut T) ────────────────────────────────────────
fn add_animal(zoo: &mut Vec<String>, name: &str) {
    zoo.push(name.to_string());
    println!("    {} 추가됨 (총 {}마리)", name, zoo.len());
}

fn rename_first(zoo: &mut Vec<String>, new_name: &str) {
    if let Some(first) = zoo.first_mut() {
        *first = new_name.to_string();
    }
}

fn demo_mut_borrow_into_fn() {
    println!("\n  ── 3. 가변 빌림 (&mut T) ──");

    let mut zoo = vec![String::from("Simba")];
    println!("  초기: {:?}", zoo);

    // 가변 빌림 — 한 번에 하나만
    add_animal(&mut zoo, "Donald");
    add_animal(&mut zoo, "Nagini");

    rename_first(&mut zoo, "Mufasa");
    println!("  첫 번째 이름 변경 후: {:?}", zoo);

    // zoo 여전히 유효 (빌림 해제됨)
    println!("  최종: {:?}", zoo);
}

// ── 4. 반환값과 소유권 ────────────────────────────────────────────
fn create_animal(name: &str, species: &str) -> String {
    // 새로 만든 값 → 소유권을 호출자에게
    format!("[{}] {}", species, name)
}

// 입력 일부를 반환 — 라이프타임 연결
fn longest_name<'a>(a: &'a str, b: &'a str) -> &'a str {
    if a.len() >= b.len() { a } else { b }
}

// 소유권 받아서 다시 반환
fn uppercase_name(mut name: String) -> String {
    name.make_ascii_uppercase();
    name  // 소유권 반환
}

fn demo_return_ownership() {
    println!("\n  ── 4. 반환값과 소유권 ──");

    // 새 값 생성 — 소유권 획득
    let tag = create_animal("Simba", "사자");
    println!("  create: {}", tag);

    // 라이프타임 연결
    let name1 = String::from("Simba");
    let name2 = String::from("Donald");
    let longest = longest_name(&name1, &name2);
    println!("  longest: {}", longest);

    // 소유권 이동 후 반환
    let name = String::from("simba");
    let upper = uppercase_name(name);  // name 이동
    // println!("{}", name);  // 에러: moved
    println!("  uppercase: {}", upper);
}

// ── 5. 실전 패턴 ──────────────────────────────────────────────────
struct Zoo {
    name:    String,
    animals: Vec<String>,
}

impl Zoo {
    fn new(name: &str) -> Self {
        Zoo { name: name.to_string(), animals: Vec::new() }
    }

    // &self — 읽기
    fn count(&self) -> usize {
        self.animals.len()
    }

    // &self — 읽기, 참조 반환
    fn name(&self) -> &str {
        &self.name
    }

    // &mut self — 수정
    fn add(&mut self, animal: &str) {
        self.animals.push(animal.to_string());
    }

    // self — 소비, 변환
    fn into_report(self) -> String {
        format!("{}: {} 마리 ({:?})", self.name, self.animals.len(), self.animals)
    }
}

fn demo_practical_patterns() {
    println!("\n  ── 5. 실전 패턴 (Zoo 구조체) ──");

    let mut zoo = Zoo::new("서울 동물원");

    zoo.add("사자");
    zoo.add("오리");
    zoo.add("뱀");

    // &self 메서드 — 여러 번 호출 가능
    println!("  동물원: {}", zoo.name());
    println!("  동물 수: {}", zoo.count());

    // self 메서드 — zoo 소비
    let report = zoo.into_report();
    // zoo.count();  // 에러: zoo moved
    println!("  보고서: {}", report);

    // 요약: 함수 시그니처 선택 가이드
    println!("\n  ── 함수 시그니처 선택 ──");
    println!("  fn f(s: String)      읽기+쓰기+소유 필요 (변환/소멸)");
    println!("  fn f(s: &String)     → &str 로 대체 권장");
    println!("  fn f(s: &str)        읽기 전용, 가장 유연");
    println!("  fn f(s: &mut String) 수정 필요");
}
