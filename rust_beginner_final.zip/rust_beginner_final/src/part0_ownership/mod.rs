// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 0.  소유권(Ownership) & 빌림(Borrowing)                          ║
// ║                                                                       ║
// ║  Rust의 모든 것은 소유권 위에 세워진다.                                  ║
// ║  impl의 self / &self / &mut self 가 왜 존재하는지,                      ║
// ║  라이프타임이 왜 필요한지 — 모두 소유권에서 출발한다.                     ║
// ╚═══════════════════════════════════════════════════════════════════════╝

// ┌───────────────────────────────────────────────────────────────────────┐
// │  mod.rs 의 역할                                                        │
// │                                                                       │
// │  mod.rs 는 디렉토리 모듈의 "진입점"이다.                                │
// │  src/part0_ownership/ 디렉토리가 하나의 모듈이 되려면                    │
// │  반드시 mod.rs(또는 부모에서 같은 이름의 .rs)가 있어야 한다.              │
// │                                                                       │
// │  핵심 규칙:                                                            │
// │    파일이 존재해도 mod 선언이 없으면 컴파일러가 완전히 무시한다.           │
// │    src/part0_ownership/foo.rs 가 있어도                                │
// │    mod foo; 가 없으면 foo.rs 는 없는 것과 같다.                         │
// │                                                                       │
// │  pub mod vs mod:                                                      │
// │    pub mod ownership;  → 외부(main.rs 등)에서 접근 가능                │
// │    mod secret;         → 이 mod.rs 안에서만 접근 가능                  │
// │                                                                       │
// │  파일 기반 모듈 선언 두 가지:                                            │
// │    mod name;           → src/현재디렉토리/name.rs 를 모듈로 등록         │
// │    mod name { ... }    → 인라인 모듈 (파일 없이 코드 직접 작성)           │
// └───────────────────────────────────────────────────────────────────────┘

// ── 하위 모듈 선언 ────────────────────────────────────────────────────────
//
//  아래 선언들이 하는 일:
//  1. src/part0_ownership/ownership.rs 파일을 모듈 트리에 등록
//  2. pub → 크레이트 외부(main.rs 포함)에서 접근 허용
//
//  만약 pub mod 대신 mod 만 쓰면:
//    mod ownership;   // ownership.rs 는 등록되지만
//                     // 외부에서 part0_ownership::ownership 에 접근 불가
//
//  만약 선언 자체를 없애면:
//    // ownership.rs 파일이 있어도 컴파일러는 완전히 무시
//    // use crate::part0_ownership::ownership::... → 컴파일 에러

pub mod ownership;           // src/part0_ownership/ownership.rs
pub mod borrowing;           // src/part0_ownership/borrowing.rs
pub mod self_forms;          // src/part0_ownership/self_forms.rs
pub mod ownership_advanced;  // src/part0_ownership/ownership_advanced.rs
pub mod ownership_fn_boundary;
pub mod ownership_mut_patterns;

// ── pub use: re-export (재내보내기) ──────────────────────────────────────
//
//  pub use ownership::run as run_ownership;
//
//  하는 일:
//  1. ownership::run 함수를 이 모듈(part0_ownership) 수준으로 끌어올림
//  2. 외부에서 part0_ownership::run_ownership() 으로 직접 호출 가능
//  3. as 로 이름 변경 — 충돌 방지 (각 모듈에 run() 이 있으므로)
//
//  pub use 없이 직접 호출하는 두 방법 비교:
//    run_ownership();          ← pub use 로 별칭 만든 경우 (현재 방식)
//    ownership::run();         ← 모듈 경로로 직접 호출
//  결과는 동일, 스타일 차이

pub use ownership::run as run_ownership;
pub use borrowing::run as run_borrowing;
pub use self_forms::run as run_self_forms;

// ── Part 0 전체 실행 ──────────────────────────────────────────────────────
pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 0: 소유권(Ownership) & 빌림(Borrowing)");
    println!("══════════════════════════════════════════════════════════");

    // pub use 별칭으로 호출 — ownership::run() 과 동일
    run_ownership();
    run_borrowing();
    run_self_forms();

    // 모듈 경로로 직접 호출 — 나중에 추가된 파트들
    ownership_advanced::run();
    ownership_fn_boundary::run();
    ownership_mut_patterns::run();
}

// run_advanced()는 현재 미사용 — run()이 이미 모두 호출함
// 남겨두는 이유: 외부에서 심화 파트만 따로 실행할 때를 위해
pub fn run_advanced() {
    ownership_advanced::run();
    ownership_fn_boundary::run();
}
