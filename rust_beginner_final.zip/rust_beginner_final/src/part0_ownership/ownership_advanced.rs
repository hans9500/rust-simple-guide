// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 0 심화.  소유권 고급 패턴과 컴파일 에러 해부                       │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 심화 1: 부분 이동(partial move) ─────────────────────────────────────
//
//  struct의 필드 하나를 move하면 struct 전체가 아닌
//  "이동된 필드만" 무효가 된다.
//  컴파일러는 필드 단위로 소유권을 추적한다.
//
//  struct Animal { name: String, age: u32 }
//  let a = Animal { name: "Simba".into(), age: 5 };
//  let n = a.name;         // name 필드만 move
//  println!("{}", a.age);  // OK — age는 Copy(u32), 아직 유효
//  println!("{}", a.name); // 에러: a.name은 moved
//  println!("{:?}", a);    // 에러: a 전체를 출력하려면 모든 필드가 유효해야 함
//
//  ── 도식 ──────────────────────────────────────────────────────────────
//
//  이동 전:                    이동 후:
//  a.name  → "Simba" (힙)     n     → "Simba" (힙)  ← n이 소유
//  a.age   = 5       (스택)   a.age = 5       (스택) ← 여전히 유효
//                             a.name = (무효)         ← 이동됨
//
//  a 전체는 "부분적으로 이동된(partially moved)" 상태
//  → struct 전체를 쓰는 연산(println!("{:?}", a), drop(a)) 불가
//  → 개별 유효 필드(a.age)는 접근 가능

#[derive(Debug)]
struct Animal {
    name: String,
    age:  u32,
}

fn demo_partial_move() {
    println!("\n  [심화1: 부분 이동(partial move)]");

    let a = Animal { name: "Simba".to_string(), age: 5 };

    // name 필드만 move
    let moved_name = a.name;            // String은 non-Copy → move
    println!("  moved_name: {}", moved_name);
    println!("  a.age 여전히 유효: {}", a.age); // u32는 Copy → 여전히 OK
    // println!("{:?}", a);             // ← 컴파일 에러: a.name moved
    // println!("{}", a.name);          // ← 컴파일 에러: use of moved value

    // 해결책 1: clone으로 원본 유지
    let b = Animal { name: "Nala".to_string(), age: 4 };
    let cloned_name = b.name.clone();   // clone → move 아님
    println!("  b.name 여전히 유효: {}", b.name);
    println!("  cloned_name: {}", cloned_name);

    // 해결책 2: 참조로 빌림
    let c = Animal { name: "Mufasa".to_string(), age: 10 };
    let ref_name = &c.name;             // &str 빌림 → move 아님
    println!("  ref_name: {}", ref_name);
    println!("  c.name 여전히 유효: {}", c.name);
}

// ─── 심화 2: Copy와 Clone의 정확한 관계 ──────────────────────────────────
//
//  공식 정의:
//    pub trait Copy: Clone {}
//    Copy는 Clone의 서브트레이트다.
//    따라서 Copy를 구현하려면 Clone도 반드시 구현해야 한다.
//
//  Copy의 의미:
//    "이 타입은 비트 복사(memcpy)만으로 완전한 복사본이 된다."
//    스택에만 있는 값 (포인터 없음) → 비트복사 = 진짜 복사
//
//  Copy를 구현할 수 없는 경우:
//
//  1. Drop을 구현한 타입
//     Drop이 있다는 것 = 해제 시 특별한 로직이 필요하다는 뜻
//     비트복사 → 두 인스턴스가 같은 힙 주소를 가리킴 → double free
//     컴파일 에러: "the trait `Copy` cannot be implemented for this type;
//                  the type has a destructor"
//
//  2. String, Vec<T>, Box<T> 등 힙 소유 타입
//     힙 포인터를 비트복사하면 두 포인터가 같은 힙을 가리킴 → double free
//
//  Copy 구현 시 clone()은 비트복사와 동일:
//    #[derive(Copy, Clone)]
//    struct Point { x: f64, y: f64 }
//    // Point::clone(&p) == *(&p as *const Point)  (비트복사)

#[derive(Debug, Copy, Clone)]       // Copy + Clone 동시 derive
struct Point { x: f64, y: f64 }

// Drop 구현 시 Copy 불가 — 주석으로만 보여줌
// #[derive(Copy, Clone)]           // ← 컴파일 에러!
// struct ResourceHandle {
//     id: u32,
// }
// impl Drop for ResourceHandle {   // Drop이 있으면 Copy 불가
//     fn drop(&mut self) { println!("해제: {}", self.id); }
// }
// 에러: the trait `Copy` cannot be implemented for this type;
//       the type has a destructor

fn demo_copy_clone() {
    println!("\n  [심화2: Copy와 Clone의 관계]");

    let p1 = Point { x: 1.0, y: 2.0 };
    let p2 = p1;            // Copy: 비트복사, p1도 유효
    let p3 = p1.clone();    // Clone: Copy 타입이므로 clone = 비트복사

    println!("  p1={:?}, p2={:?}, p3={:?}", p1, p2, p3);
    println!("  p1.x={}, p1.y={}", p1.x, p1.y); // x, y 필드 직접 접근
    // p1이 여전히 유효 — Copy 덕분

    // Copy 타입과 non-Copy 타입의 함수 인자 차이
    fn takes_point(p: Point) { println!("  takes_point: {:?}", p); }
    fn takes_string(s: String) { println!("  takes_string: {}", s); }

    takes_point(p1);            // 비트복사 → p1 여전히 유효
    takes_point(p1);            // 한 번 더 OK

    let s = "Simba".to_string();
    takes_string(s);            // move → s 무효
    // takes_string(s);         // ← 컴파일 에러: use of moved value
}

// ─── 심화 3: 루프 안의 이동 실수 ─────────────────────────────────────────
//
//  루프 안에서 non-Copy 타입을 move하면 두 번째 반복에서 에러:
//
//  let animals = vec![...];
//  for animal in &animals {       // &animal: &Lion → move 없음 (OK)
//      consume(animal);
//  }
//
//  for animal in animals {        // animal: Lion → move 발생
//      consume(animal);           // 첫 번복: OK
//      consume(animal);           // ← 에러: animal moved in prev line
//  }
//
//  소유권 이동 컬렉션 순회 세 가지 패턴:
//
//  for x in &collection     → x: &T    (공유 빌림, 원본 유지)
//  for x in &mut collection → x: &mut T (배타 빌림, 수정 가능)
//  for x in collection      → x: T     (소유권 이동, 원본 소비)

fn demo_loop_move() {
    println!("\n  [심화3: 루프 안의 이동 패턴]");

    let names = vec![
        "Simba".to_string(),
        "Nala".to_string(),
        "Mufasa".to_string(),
    ];

    // 1. &collection — 빌림, 원본 유지
    for name in &names {            // name: &String
        print!("  &iter: {} | ", name);
    }
    println!();
    println!("  원본 유지: {:?}", names); // names 여전히 유효

    // 2. &mut collection — 가변 빌림
    let mut ages = vec![5u32, 4, 10];
    for age in &mut ages {          // age: &mut u32
        *age += 1;                  // 역참조로 수정
    }
    println!("  나이 +1: {:?}", ages);

    // 3. collection 소유권 이동 — 원본 소비
    let to_consume = vec![
        "Scar".to_string(),
        "Sarabi".to_string(),
    ];
    for name in to_consume {        // name: String (move)
        println!("  consumed: {}", name);
    }
    // println!("{:?}", to_consume); // ← 컴파일 에러: value moved into iterator

    // 4. 루프 안에서 같은 값 두 번 move 시도
    let items = vec!["A".to_string(), "B".to_string()];
    for item in &items {
        let _r1 = item;             // &String 빌림 → OK
        let _r2 = item;             // 또 빌림 → OK (Copy가 아닌 참조라도 빌림은 여러 번 가능)
    }

    // 5. 해결책: clone()
    let originals = vec!["X".to_string(), "Y".to_string()];
    let clones: Vec<String> = originals.iter().map(|s| s.clone()).collect();
    println!("  originals: {:?}", originals);
    println!("  clones:    {:?}", clones);
}

// ─── 심화 4: 함수 인자로 이동 후 재사용 실수 패턴 ────────────────────────
//
//  가장 흔한 실수:
//
//  fn process(lion: Lion) { ... }  // lion을 소비
//
//  let simba = Lion::new("Simba", 5);
//  process(simba);                 // simba → process로 move
//  println!("{}", simba.name());   // ← 에러: simba moved
//
//  컴파일러 메시지:
//    error[E0382]: borrow of moved value: `simba`
//    note: `simba` is moved here (process 호출 줄)
//    note: consider changing `process` to borrow `lion` instead
//
//  해결 방법 비교:
//  ┌──────────────────────┬───────────────────────────────────────┐
//  │ 방법                 │ 언제 쓰는가                           │
//  ├──────────────────────┼───────────────────────────────────────┤
//  │ fn f(x: &T)         │ 읽기만 필요 — 가장 권장               │
//  │ fn f(x: &mut T)     │ 수정 필요, 원본 유지                   │
//  │ fn f(x: T)          │ 함수가 소유권 필요 (변환, 저장 등)     │
//  │ fn f(x: T) -> T     │ 소유권 받고 반환 (Builder 패턴)        │
//  │ fn f(x: Arc<T>)     │ 여러 곳에서 공유                       │
//  └──────────────────────┴───────────────────────────────────────┘

use crate::part2_patterns::animals::Lion;

fn read_lion(lion: &Lion) -> String {           // 빌림
    lion.name().to_string()
}
fn consume_lion(lion: Lion) -> String {         // 소유권 소비
    lion.retire()
}
fn transform_lion(lion: Lion) -> Lion {         // 소유권 받고 반환 (Builder)
    lion.with_hungry(false)
}

fn demo_move_reuse() {
    println!("\n  [심화4: 함수 인자 이동 실수 패턴]");

    let simba = Lion::new("Simba", 5);

    // read_lion은 &T → simba 유지
    println!("  read: {}", read_lion(&simba));
    println!("  read: {}", read_lion(&simba));  // 두 번 가능

    // transform_lion: 소유권 받고 반환
    let simba2 = transform_lion(simba);         // simba → 함수로 move
    // println!("{}", simba.name());            // ← 에러: simba moved
    println!("  변환 후: {}", simba2.status());

    // consume_lion: 소유권 소비, 반환 없음
    let msg = consume_lion(simba2);
    println!("  소비: {}", msg);
    // println!("{}", simba2.name());           // ← 에러: simba2 moved
}

pub fn run() {
    println!("\n══════ Part 0 심화: 소유권 고급 패턴 ══════");
    demo_partial_move();
    demo_copy_clone();
    demo_loop_move();
    demo_move_reuse();
}
