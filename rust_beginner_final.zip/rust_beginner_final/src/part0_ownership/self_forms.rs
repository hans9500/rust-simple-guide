// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 0-3.  함수와 소유권 — self / &self / &mut self 의 근원             │
// │                                                                       │
// │  impl 블록의 세 가지 self 형태는 소유권 규칙의 직접적인 반영이다.          │
// │  "메서드에 self를 어떻게 줄 것인가" = "소유권을 어떻게 다룰 것인가"       │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 도식: 세 가지 self ──────────────────────────────────────────────────
//
//  fn describe(&self)        → fn describe(self: &SimpleAnimal)
//  ┌─────────────────────────────────────────────────────────────┐
//  │ 호출:    animal.describe()                                   │
//  │ 내부:    describe(&animal)   → 공유 빌림                     │
//  │ 결과:    animal은 호출 후에도 유효                             │
//  │ 용도:    값을 읽기만 할 때 (가장 흔함)                         │
//  └─────────────────────────────────────────────────────────────┘
//
//  fn grow_up(&mut self)     → fn grow_up(self: &mut SimpleAnimal)
//  ┌─────────────────────────────────────────────────────────────┐
//  │ 호출:    animal.grow_up()  (let mut animal 필요)             │
//  │ 내부:    grow_up(&mut animal) → 배타 빌림                    │
//  │ 결과:    animal은 호출 후에도 유효 (수정된 상태로)             │
//  │ 용도:    내부 상태를 변경할 때                                 │
//  └─────────────────────────────────────────────────────────────┘
//
//  fn into_name(self)        → fn into_name(self: SimpleAnimal)
//  ┌─────────────────────────────────────────────────────────────┐
//  │ 호출:    animal.into_name()                                  │
//  │ 내부:    into_name(animal) → 소유권 이동(move)               │
//  │ 결과:    animal은 호출 후 무효 → 사용하면 컴파일 에러          │
//  │ 용도:    값을 소비하거나 변환할 때 (Builder, retire 등)        │
//  └─────────────────────────────────────────────────────────────┘
//
// ─── &self 반환값의 라이프타임 생략 ──────────────────────────────────────
//
//  fn name(&self) -> &str
//  실제로는: fn name<'a>(&'a self) -> &'a str
//
//  생략 규칙 3번: 메서드에 &self 또는 &mut self 가 있으면
//                출력 라이프타임 = self의 라이프타임 (자동 추론)
//
//  즉, name()이 반환하는 &str은 self(SimpleAnimal)가 살아있는 동안만 유효.
//  self가 drop되면 반환된 &str도 무효가 된다.
//  컴파일러가 이를 추적해 dangling reference를 방지한다.

pub struct SimpleAnimal {
    pub name: String,
    pub age:  u32,
}

impl SimpleAnimal {
    pub fn new(name: &str, age: u32) -> Self {
        SimpleAnimal { name: name.to_string(), age }
    }

    // &self — 공유 빌림. 읽기만. 호출 후 변수 유효.
    // 실제 시그니처: fn describe<'a>(&'a self) -> String
    // 반환 String은 소유된 값이므로 라이프타임 무관
    pub fn describe(&self) -> String {
        format!("{} ({}살)", self.name, self.age)
    }

    // &self — 반환값이 self에서 빌린 참조일 때
    // 실제 시그니처: fn name<'a>(&'a self) -> &'a str
    // 반환된 &str은 self가 살아있는 동안만 유효
    pub fn name(&self) -> &str {
        &self.name      // self.name(String)에서 &str 빌림
    }

    // &mut self — 배타 빌림. 수정 가능. let mut 필요.
    pub fn grow_up(&mut self) {
        self.age += 1;
    }

    // self — 소유권 소비. 호출 후 변수 무효.
    // self.name (String)의 소유권을 꺼내 반환
    // 함수 끝에서 self의 나머지 필드(age: u32)는 drop됨
    pub fn into_name(self) -> String {
        self.name
    }
}

pub fn run() {
    println!("\n─── Part 0-3: self / &self / &mut self ───");

    // &self — 읽기, 호출 후 유효
    let animal = SimpleAnimal::new("Simba", 4);
    println!("  &self: {}", animal.describe());
    println!("  &self: {}", animal.describe()); // 여러 번 호출 가능

    // &str 반환 — self가 살아있는 동안 유효
    let name_ref: &str = animal.name();         // animal에서 빌림
    println!("  name_ref: {}", name_ref);       // animal이 살아있으므로 OK
    // animal이 drop되면 name_ref도 무효 — 컴파일러가 추적

    // &mut self — 수정, 호출 후 유효
    let mut animal2 = SimpleAnimal::new("Donald", 2);
    animal2.grow_up();
    println!("  &mut self 후: {}", animal2.describe());

    // self — 소비, 호출 후 무효
    let animal3 = SimpleAnimal::new("Nagini", 8);
    let name = animal3.into_name();             // animal3 소유권 소비
    println!("  self 소비 후 name: {}", name);
    // println!("{}", animal3.describe());     // ← 컴파일 에러: moved
}
