// ┌──────────────────────────────────────────────────────────────────
// │ Part 15-1: 파일 읽기 기초
// │ 공식 문서: std::fs::read_to_string, std::fs::File
// └──────────────────────────────────────────────────────────────────

use std::fs;
use std::io::{self, Read};


// ┌─────────────────────────────────────────────────────────────────────┐
// │  Rust 파일 I/O 계층 구조                                             │
// │                                                                     │
// │  std::io::Read  (trait)                                             │
// │    └── File::open()  ──read_to_string()──▶ String                  │
// │    └── BufReader      ──lines()──▶ Iterator<String>                │
// │                                                                     │
// │  std::fs 편의 함수:                                                  │
// │    fs::read_to_string(path)  → String  (소형 파일)                  │
// │    fs::read(path)            → Vec<u8> (바이너리)                   │
// │    fs::write(path, data)     → ()      (간단한 쓰기)                │
// │                                                                     │
// │  ? 연산자로 에러 전파:                                               │
// │    fn read() -> io::Result<String> {                                │
// │        fs::read_to_string("file.txt")?   ← 에러 시 즉시 반환        │
// │    }                                                                │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [15-1: 파일 읽기 기초]");
    demo_read_to_string();
    demo_file_open();
    demo_file_metadata();
}

fn demo_read_to_string() {
    println!("\n  ── fs::read_to_string ──");

    // 임시 파일 생성 후 읽기
    let path = "/tmp/zoo_animals.txt";
    let content = "Simba,사자,5,190.5\nDonald,오리,3,2.5\nNagini,뱀,8,15.0\n";
    fs::write(path, content).expect("파일 쓰기 실패");

    // 가장 간단한 읽기 — 전체를 String으로
    match fs::read_to_string(path) {
        Ok(text) => {
            println!("  파일 내용:");
            for line in text.lines() {
                println!("    {}", line);
            }
            println!("  총 {} 줄", text.lines().count());
        }
        Err(e) => println!("  읽기 실패: {}", e),
    }

    // 존재하지 않는 파일
    let result = fs::read_to_string("/tmp/없는파일.txt");
    println!("  없는 파일: {}", result.unwrap_err());

    // ? 연산자 활용 패턴
    fn read_zoo(path: &str) -> io::Result<Vec<(String, u32)>> {
        let text = fs::read_to_string(path)?;
        let animals = text.lines()
            .filter_map(|line| {
                let parts: Vec<&str> = line.split(',').collect();
                if parts.len() >= 3 {
                    let name = parts[0].to_string();
                    let age: u32 = parts[2].parse().ok()?;
                    Some((name, age))
                } else {
                    None
                }
            })
            .collect();
        Ok(animals)
    }

    match read_zoo(path) {
        Ok(animals) => println!("  파싱: {:?}", animals),
        Err(e)      => println!("  에러: {}", e),
    }
}

fn demo_file_open() {
    println!("\n  ── File::open + Read ──");

    use std::fs::File;
    let path = "/tmp/zoo_animals.txt";

    // File::open → Read trait → read_to_string
    let mut file = File::open(path).expect("파일 열기 실패");
    let mut content = String::new();
    file.read_to_string(&mut content).expect("읽기 실패");
    println!("  File::open 읽기: {} bytes", content.len());

    // 바이트로 읽기
    let bytes = fs::read(path).expect("바이트 읽기 실패");
    println!("  bytes: {} bytes", bytes.len());
    println!("  첫 10바이트: {:?}", &bytes[..10]);
}

fn demo_file_metadata() {
    println!("\n  ── 파일 메타데이터 ──");

    let path = "/tmp/zoo_animals.txt";
    let meta = fs::metadata(path).expect("메타데이터 실패");

    println!("  크기: {} bytes", meta.len());
    println!("  파일인가: {}", meta.is_file());
    println!("  디렉토리인가: {}", meta.is_dir());
    println!("  읽기전용: {}", meta.permissions().readonly());

    // 경로 존재 여부
    println!("  존재 여부: {}", std::path::Path::new(path).exists());
    println!("  미존재: {}", std::path::Path::new("/없음").exists());
}
