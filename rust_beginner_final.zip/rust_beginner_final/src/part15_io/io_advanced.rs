// ┌──────────────────────────────────────────────────────────────────
// │ Part 15-4: 디렉토리 / Path / 실전 패턴
// └──────────────────────────────────────────────────────────────────

use std::fs;
use std::path::{Path, PathBuf};
use std::io;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  Path / PathBuf 관계                                                 │
// │                                                                     │
// │  Path    : &str 처럼 빌림 (불변, 크기 고정)                          │
// │  PathBuf : String 처럼 소유 (가변, 크기 변경 가능)                   │
// │                                                                     │
// │  Path::new("/tmp/zoo")                                              │
// │    ├── .exists()    → bool                                          │
// │    ├── .is_file()   → bool                                          │
// │    ├── .parent()    → Option<&Path>  ("/tmp")                       │
// │    ├── .file_name() → Option<&OsStr> ("zoo")                       │
// │    └── .join("a.txt") → PathBuf     ("/tmp/zoo/a.txt")             │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [15-4: 디렉토리 / Path / 실전 패턴]");
    demo_path();
    demo_directory();
    demo_practical();
}

fn demo_path() {
    println!("\n  ── Path / PathBuf ──");

    // Path: 빌림(&str처럼), PathBuf: 소유(String처럼)
    let path = Path::new("/tmp/zoo/animals.csv");
    println!("  파일명: {:?}", path.file_name());
    println!("  확장자: {:?}", path.extension());
    println!("  부모:   {:?}", path.parent());
    println!("  줄기:   {:?}", path.file_stem());

    // PathBuf: 경로 조합
    let mut buf = PathBuf::from("/tmp");
    buf.push("zoo");
    buf.push("report.txt");
    println!("  조합된 경로: {:?}", buf);

    // join으로 조합
    let base = Path::new("/tmp/zoo");
    let full = base.join("data").join("animals.csv");
    println!("  join 경로: {:?}", full);

    // 경로 문자열 변환
    let path_str = full.to_str().unwrap_or("변환 불가");
    println!("  to_str: {}", path_str);
}

fn demo_directory() {
    println!("\n  ── 디렉토리 조작 ──");

    let dir = "/tmp/zoo_dir";

    // 디렉토리 생성
    fs::create_dir_all(dir).unwrap();
    println!("  디렉토리 생성: {}", dir);

    // 파일 몇 개 생성
    for name in &["lions.txt", "ducks.txt", "snakes.txt"] {
        fs::write(format!("{}/{}", dir, name),
            format!("{} 데이터\n", name)).unwrap();
    }

    // 디렉토리 순회
    println!("  디렉토리 내용:");
    let mut entries: Vec<_> = fs::read_dir(dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .collect();
    entries.sort_by_key(|e| e.file_name());
    for entry in &entries {
        let meta = entry.metadata().unwrap();
        println!("    {:?} ({} bytes)", entry.file_name(), meta.len());
    }

    // 정리
    fs::remove_dir_all(dir).unwrap();
    println!("  디렉토리 삭제 완료");
}

fn demo_practical() {
    println!("\n  ── 실전: CSV 처리 함수 ──");

    // 파일 존재 확인 후 읽기
    fn read_or_default(path: &str, default: &str) -> String {
        if Path::new(path).exists() {
            fs::read_to_string(path).unwrap_or_else(|_| default.to_string())
        } else {
            default.to_string()
        }
    }

    let data = read_or_default("/tmp/zoo_bulk.csv", "파일 없음");
    println!("  파일 읽기: {} 줄", data.lines().count());

    // io::Result를 반환하는 함수 체인
    fn process_zoo_file(input: &str, output: &str) -> io::Result<usize> {
        let content = fs::read_to_string(input)?;
        let mut count = 0;
        let mut result = String::new();
        for line in content.lines().skip(1) {  // 헤더 스킵
            let parts: Vec<&str> = line.split(',').collect();
            if parts.len() >= 3 {
                if let Ok(age) = parts[2].parse::<u32>() {
                    if age >= 5 {
                        result.push_str(&format!("{},{}\n", parts[0], age));
                        count += 1;
                    }
                }
            }
        }
        fs::write(output, result)?;
        Ok(count)
    }

    match process_zoo_file("/tmp/zoo_bulk.csv", "/tmp/zoo_adults.txt") {
        Ok(n)  => println!("  성체 {} 마리 → /tmp/zoo_adults.txt", n),
        Err(e) => println!("  처리 실패: {}", e),
    }

    println!("\n  ── 정리 ──");
    println!("  fs::read_to_string  → 소형 파일 전체 읽기");
    println!("  BufReader::lines()  → 대형 파일 줄 단위 읽기");
    println!("  fs::write           → 간단한 전체 쓰기");
    println!("  BufWriter           → 대량 쓰기 성능");
    println!("  OpenOptions::append → 기존 파일에 추가");
    println!("  Path/PathBuf        → 경로 조합 및 분석");
}
