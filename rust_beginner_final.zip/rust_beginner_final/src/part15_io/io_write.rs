// ┌──────────────────────────────────────────────────────────────────
// │ Part 15-3: 파일 쓰기
// │ 공식 문서: std::fs::write, std::fs::OpenOptions, BufWriter
// └──────────────────────────────────────────────────────────────────

use std::fs::{self, File, OpenOptions};
use std::io::{self, BufWriter, Write};


// ┌─────────────────────────────────────────────────────────────────────┐
// │  쓰기 방식 비교                                                      │
// │                                                                     │
// │  fs::write(path, data)     → 전체 덮어씀 (간단)                     │
// │                                                                     │
// │  OpenOptions::new()                                                 │
// │    .write(true).create(true).truncate(true) → 새로 만들기           │
// │    .append(true)                            → 기존에 추가            │
// │                                                                     │
// │  BufWriter:                                                         │
// │    write() → [내부 버퍼: ████░░░]                                   │
// │    write() → [내부 버퍼: ████████]                                  │
// │    flush() → 한 번에 디스크에 기록  (시스템 콜 최소화)               │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [15-3: 파일 쓰기]");
    demo_simple_write();
    demo_open_options();
    demo_buf_writer();
    demo_writeln_macro();
}

fn demo_simple_write() {
    println!("\n  ── fs::write (가장 간단) ──");

    // 전체 내용을 한 번에 씀 — 파일 없으면 생성, 있으면 덮어씀
    let path = "/tmp/zoo_output.txt";
    fs::write(path, "Simba,사자,5\nDonald,오리,3\n").expect("쓰기 실패");
    println!("  쓰기 완료: {} bytes", fs::metadata(path).unwrap().len());

    // 다시 write → 덮어씀
    fs::write(path, "새 내용").unwrap();
    println!("  덮어쓰기 후: {:?}", fs::read_to_string(path).unwrap());
}

fn demo_open_options() {
    println!("\n  ── OpenOptions: 세밀한 제어 ──");

    let path = "/tmp/zoo_log.txt";

    // 새로 만들기
    {
        let mut file = OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)  // 기존 내용 삭제
            .open(path)
            .expect("파일 생성 실패");
        writeln!(file, "=== 동물원 로그 ===").unwrap();
    }

    // 추가(append) 모드
    for animal in &["Simba 입장", "Donald 퇴장", "Nagini 입장"] {
        let mut file = OpenOptions::new()
            .append(true)
            .open(path)
            .expect("파일 열기 실패");
        writeln!(file, "{}", animal).unwrap();
    }

    println!("  로그 파일:");
    for line in fs::read_to_string(path).unwrap().lines() {
        println!("    {}", line);
    }
}

fn demo_buf_writer() {
    println!("\n  ── BufWriter: 대량 쓰기 성능 ──");

    let path = "/tmp/zoo_bulk.csv";
    let file = File::create(path).expect("파일 생성 실패");
    let mut writer = BufWriter::new(file);

    // BufWriter: 내부 버퍼에 모았다가 한 번에 flush
    writeln!(writer, "name,species,age,weight").unwrap();
    let animals = [
        ("Simba",   "사자",   5u32,  190.5f64),
        ("Donald",  "오리",   3,     2.5),
        ("Nagini",  "뱀",     8,     15.0),
        ("Dumbo",   "코끼리", 10,    4000.0),
        ("Giraffe", "기린",   6,     800.0),
    ];
    for (name, species, age, weight) in &animals {
        writeln!(writer, "{},{},{},{}", name, species, age, weight).unwrap();
    }
    // BufWriter drop 시 자동 flush — 명시적으로도 가능
    writer.flush().expect("flush 실패");

    let content = fs::read_to_string(path).unwrap();
    println!("  CSV 줄 수: {}", content.lines().count());
    println!("  헤더: {}", content.lines().next().unwrap());
}

fn demo_writeln_macro() {
    println!("\n  ── write!/writeln! 매크로 ──");

    // write!/writeln!은 println!과 같은 포맷, File/BufWriter에 사용
    let mut output: Vec<u8> = Vec::new();  // io::Write 구현체로 Vec 사용

    writeln!(output, "동물원 보고서").unwrap();
    writeln!(output, "{:-<20}", "").unwrap();
    writeln!(output, "{:<10} {:>5}", "이름", "나이").unwrap();
    writeln!(output, "{:<10} {:>5}", "Simba", 5).unwrap();
    writeln!(output, "{:<10} {:>5}", "Donald", 3).unwrap();

    let report = String::from_utf8(output).unwrap();
    for line in report.lines() {
        println!("  {}", line);
    }

    // io::stdout()에도 동일하게
    let stdout = io::stdout();
    let mut handle = stdout.lock();
    writeln!(handle, "  stdout에 직접 쓰기").unwrap();
}
