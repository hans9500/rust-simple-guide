// ┌──────────────────────────────────────────────────────────────────
// │ Part 15-2: BufReader / 줄 단위 읽기
// │
// │ 공식 문서: std::io::BufReader
// │
// │ 왜 BufReader?
// │   파일 읽기를 줄마다 시스템 콜하면 느림
// │   BufReader: 내부 버퍼에 미리 읽어두고 청크 단위로 처리
// │   → 시스템 콜 횟수 감소 → 큰 파일 처리 시 속도 향상
// └──────────────────────────────────────────────────────────────────

use std::fs::{self, File};
use std::io::{self, BufRead, BufReader};


// ┌─────────────────────────────────────────────────────────────────────┐
// │  BufReader 버퍼 구조                                                 │
// │                                                                     │
// │  File ──▶ BufReader ──▶ 애플리케이션                                │
// │                                                                     │
// │  시스템 콜 없이:  [버퍼: ████████████████████ ]                      │
// │  한 줄 읽기:      [버퍼: ████░░░░░░░░░░░░░░░░ ] → 첫 줄          │
// │  한 줄 읽기:      [버퍼: ████████░░░░░░░░░░░░ ] → 둘째 줄        │
// │                                                                     │
// │  vs 버퍼 없이:                                                       │
// │    줄마다 → 시스템 콜 → 느림                                         │
// │  BufReader:                                                         │
// │    한 번에 큰 덩어리 읽기 → 줄 단위 반환 → 빠름                       │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [15-2: BufReader 줄 단위 읽기]");
    setup_test_file();
    demo_buf_reader();
    demo_lines_iterator();
    demo_stdin_like();
}

fn setup_test_file() {
    let content = "# 동물원 데이터\nSimba,사자,5,190.5\nDonald,오리,3,2.5\n# 주석\nNagini,뱀,8,15.0\nDumbo,코끼리,10,4000.0\n";
    fs::write("/tmp/zoo_data.csv", content).unwrap();
}

fn demo_buf_reader() {
    println!("\n  ── BufReader 기본 ──");

    let file = File::open("/tmp/zoo_data.csv").expect("파일 열기 실패");
    let reader = BufReader::new(file);

    // lines(): 줄 단위 이터레이터 반환 — Result<String, io::Error>
    let mut count = 0;
    for line in reader.lines() {
        let line = line.expect("줄 읽기 실패");
        if !line.starts_with('#') && !line.is_empty() {
            println!("  데이터: {}", line);
            count += 1;
        }
    }
    println!("  데이터 줄 수: {}", count);
}

fn demo_lines_iterator() {
    println!("\n  ── lines() 이터레이터 활용 ──");

    let file = File::open("/tmp/zoo_data.csv").unwrap();
    let reader = BufReader::new(file);

    // 주석 제외하고 파싱
    let animals: Vec<(String, String, u32)> = reader.lines()
        .filter_map(|l| l.ok())
        .filter(|l| !l.starts_with('#') && !l.is_empty())
        .filter_map(|line| {
            let parts: Vec<&str> = line.split(',').collect();
            if parts.len() >= 3 {
                let name    = parts[0].to_string();
                let species = parts[1].to_string();
                let age: u32 = parts[2].parse().ok()?;
                Some((name, species, age))
            } else {
                None
            }
        })
        .collect();

    println!("  파싱된 동물:");
    for (name, species, age) in &animals {
        println!("    {} ({}) {}살", name, species, age);
    }

    // 통계
    if !animals.is_empty() {
        let avg_age = animals.iter().map(|(_, _, a)| *a as f64).sum::<f64>()
            / animals.len() as f64;
        println!("  평균 나이: {:.1}살", avg_age);

        let oldest = animals.iter().max_by_key(|(_, _, a)| a);
        println!("  최고령: {:?}", oldest.map(|(n, _, a)| format!("{} {}살", n, a)));
    }
}

fn demo_stdin_like() {
    println!("\n  ── BufRead trait: 파일과 stdin 동일 인터페이스 ──");

    // BufRead를 받는 함수 — File에도 stdin에도 동작
    fn count_animals<R: BufRead>(reader: R) -> io::Result<usize> {
        Ok(reader.lines()
            .filter_map(|l| l.ok())
            .filter(|l| !l.starts_with('#') && !l.is_empty())
            .count())
    }

    let file = File::open("/tmp/zoo_data.csv").unwrap();
    let reader = BufReader::new(file);
    println!("  파일에서 동물 수: {}", count_animals(reader).unwrap());

    // 문자열을 BufRead처럼 사용
    let data = b"Simba,lion,5\nDonald,duck,3\n";
    let cursor = io::Cursor::new(data);
    println!("  메모리에서 동물 수: {}", count_animals(cursor).unwrap());
}
