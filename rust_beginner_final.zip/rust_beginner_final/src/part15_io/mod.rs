// ┌──────────────────────────────────────────────────────────────────
// │ Part 15: 파일 입출력 (File I/O)
// │ 공식 문서: Rust Book Ch.12, std::fs, std::io
// └──────────────────────────────────────────────────────────────────
pub mod io_basic;
pub mod io_bufread;
pub mod io_write;
pub mod io_advanced;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 15: 파일 입출력 (File I/O)");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    io_basic::run();
    io_bufread::run();
    io_write::run();
    io_advanced::run();
}
