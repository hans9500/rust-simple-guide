// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 7-3.  if let / while let / let else                             │
// │                                                                       │
// │  if let:    하나의 패턴만 처리, 나머지는 무시. match의 간결한 형태.      │
// │  while let: 패턴이 일치하는 동안 반복.                                  │
// │  let else:  패턴이 실패하면 else 블록 실행 (발산해야 함).               │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::{Lion, Snake};
use crate::part6_enum::enum6_result::ZooError;

fn find_snake<'a>(snakes: &'a [Snake], name: &str) -> Option<&'a Snake> {
    snakes.iter().find(|s| s.name() == name)
}

fn get_snake_validated(name: &str, age: u32) -> Result<Snake, ZooError> {
    if name.chars().count() < 2 {
        return Err(ZooError::NameTooShort { name: name.to_string() });
    }
    if age > 30 {
        return Err(ZooError::AgeOutOfRange {
            name: name.to_string(), age, max: 30
        });
    }
    Ok(Snake::new(name, age, age > 5))
}

pub fn run() {
    println!("\n─── Part 7-3: if let / while let / let else ───");

    // ── if let ──────────────────────────────────────────────────────────
    //
    //  if let PATTERN = EXPR { ... } else { ... }
    //  match EXPR { PATTERN => { ... }, _ => { ... } } 와 동일하지만 간결
    println!("\n  [if let]");
    let snakes = vec![
        Snake::new("Nagini", 8, true),
        Snake::new("Kaa", 5, false),
    ];

    // Option
    if let Some(s) = find_snake(&snakes, "Nagini") {
        println!("  Nagini 발견: {}", s.status());
    }

    // if let + else
    if let Some(s) = find_snake(&snakes, "Ghost") {
        println!("  Ghost: {}", s.name());
    } else {
        println!("  Ghost 없음");
    }

    // if let 체이닝
    if let Some(s) = find_snake(&snakes, "Kaa") {
        if let false = s.is_venomous() {
            println!("  Kaa는 무독성 — 안전");
        }
    }

    // Result if let
    if let Ok(snake) = get_snake_validated("Cobra", 6) {
        println!("  검증 성공: {}", snake.status());
    }
    if let Err(e) = get_snake_validated("X", 5) {
        println!("  검증 실패: {}", e);
    }

    // ── while let ────────────────────────────────────────────────────────
    //
    //  while let PATTERN = EXPR { ... }
    //  PATTERN이 일치하지 않으면 루프 종료
    println!("\n  [while let]");
    let mut action_queue: Vec<Option<String>> = vec![
        Some("우리 열기".to_string()),
        Some("먹이 주기".to_string()),
        None,                              // None → 루프 종료
        Some("이 줄은 실행 안 됨".to_string()),
    ];
    action_queue.reverse();
    while let Some(Some(action)) = action_queue.pop().map(|x| x.map(|v| v)) {
        println!("  실행: {}", action);
    }

    // Option<T> 스택
    let mut stack = vec![1u32, 2, 3, 4, 5];
    let mut sum = 0;
    while let Some(top) = stack.pop() {
        sum += top;
    }
    println!("  합계: {}", sum);

    // ── let else (Rust 1.65+) ────────────────────────────────────────────
    //
    //  let PATTERN = EXPR else { /* 발산 코드 */ };
    //
    //  패턴이 실패하면 else 블록을 실행한다.
    //  else 블록은 반드시 발산(diverge)해야 한다:
    //    return, break, continue, panic!, loop {} 등
    //
    //  기존 방식:
    //  let name = if let Some(s) = find_snake(&snakes, "Nagini") {
    //      s.name()
    //  } else {
    //      return;
    //  };
    //
    //  let else 방식 (더 명확):
    //  let Some(s) = find_snake(&snakes, "Nagini") else { return; };
    println!("\n  [let else]");
    process_snake_report(&snakes);
    process_snake_report(&[]);

    // ── matches! 매크로 ───────────────────────────────────────────────────
    //
    //  matches!(expr, PATTERN)  →  bool
    //  matches!(expr, PATTERN if GUARD)
    //  이것은 단순 bool 검사가 필요할 때 match/if let 대신 쓴다.
    println!("\n  [matches! 매크로]");
    let lions = vec![
        Lion::new("Young", 2),
        Lion::new("Adult", 8),
        Lion::new("Elder", 14),
    ];
    let seniors: Vec<&Lion> = lions.iter()
        .filter(|l| matches!(l.age(), age if age > 10))
        .collect();
    for l in &seniors {
        println!("  시니어: {} ({}살)", l.name(), l.age());
    }
}

fn process_snake_report(snakes: &[Snake]) {
    // let else — 패턴 실패 시 return으로 발산
    let Some(first) = snakes.first() else {
        println!("  [report] 뱀이 없음, 리포트 중단");
        return;
    };
    println!("  [report] 첫 번째 뱀: {}", first.status());
}
