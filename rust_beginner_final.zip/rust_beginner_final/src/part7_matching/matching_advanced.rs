// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 7 심화.  패턴 매칭 고급 — 실수 패턴과 정확한 이유                 │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::{Lion, Snake};

// ─── 심화 1: irrefutable vs refutable 패턴 ────────────────────────────────
//
//  irrefutable(반박 불가) 패턴: 항상 매칭 성공
//    let x = 5;            → x는 irrefutable (어떤 값이든 x에 바인딩)
//    let (a, b) = (1, 2);  → 튜플 분해, irrefutable
//
//  refutable(반박 가능) 패턴: 매칭 실패 가능
//    Some(x)   → None이면 실패
//    Ok(x)     → Err이면 실패
//    1..=5     → 범위 밖이면 실패
//
//  중요한 규칙:
//    let PATTERN = expr;   → irrefutable 패턴만 허용
//    if let PATTERN = expr → refutable 패턴 허용
//    while let PATTERN     → refutable 패턴 허용
//    match arms            → refutable 패턴 허용
//
//  실수: let Some(x) = opt;  → 에러!
//  let Some(x) = Some(5);
//  // 에러: refutable pattern in local binding: `None` not covered
//  // note: `let` bindings require an "irrefutable pattern", like a `struct`
//  //        or an `enum` with only one variant
//  // help: you might want to use `if let` to ignore the variant that isn't matched
//
//  해결:
//    if let Some(x) = opt { ... }        → 안전
//    let Some(x) = opt else { return; }  → let else (Rust 1.65+)
//    let x = opt.unwrap();               → panic 위험

fn demo_refutable_irrefutable() {
    println!("\n  [심화1: irrefutable vs refutable 패턴]");

    // irrefutable — let 가능
    let (a, b, c) = (1, 2, 3);
    println!("  튜플 분해: {}, {}, {}", a, b, c);

    let lion = Lion::new("Simba", 5);
    let Lion { name: lion_name, age: lion_age, .. } = lion; // struct 분해 — irrefutable
    println!("  struct 분해: {}, {}살", lion_name, lion_age);

    // refutable — if let 필요
    let opt: Option<i32> = Some(42);
    // let Some(x) = opt;  // ← 에러: refutable pattern in local binding

    if let Some(x) = opt {
        println!("  if let Some: {}", x);
    }

    // let else — Rust 1.65+
    let Some(y) = opt else { panic!("None"); };
    println!("  let else: {}", y);

    // match는 refutable OK (모든 경우 처리)
    let result = match opt {
        Some(v) => format!("있음: {}", v),
        None    => "없음".to_string(),
    };
    println!("  match: {}", result);
}

// ─── 심화 2: match 변수 shadowing 실수 ───────────────────────────────────
//
//  match arm에서 외부 변수 이름을 쓰면 새 변수가 생긴다!
//
//  let x = 5;
//  match some_value {
//      x => println!("x={}", x),  // ← 이 x는 some_value를 바인딩!
//                                  //    외부 x(=5)가 아님!
//  }
//
//  외부 변수와 매칭하려면:
//    1. 상수(UPPER_CASE) 사용 → 값으로 매칭
//    2. 가드(guard) 사용 → if 조건으로 비교
//    3. 중괄호 경로 사용 → Enum::Variant
//
//  올바른 방법:
//  const TARGET: i32 = 5;
//  match some_value {
//      TARGET => println!("5입니다"),  // 상수 → 값 매칭
//      other  => println!("다른 값: {}", other),
//  }
//
//  또는 가드:
//  let target = 5;
//  match some_value {
//      x if x == target => println!("target"),
//      other            => println!("다른 값: {}", other),
//  }

fn demo_variable_shadowing() {
    println!("\n  [심화2: match 변수 shadowing 실수]");

    let target = 5i32;

    // 실수: 외부 변수를 값 매칭에 사용하려 했지만 shadowing 발생
    let value = 10;
    match value {
        n if n == target => println!("  target({})과 같음: {}", target, n),  // 가드로 비교
        other            => println!("  다른 값: {} (target={})", other, target),
    }

    // 상수는 값 매칭에 사용 가능
    const SPECIAL: i32 = 42;
    let values = [1, 42, 100];
    for v in &values {
        match v {
            &SPECIAL => println!("  특별한 값: {}", v),
            other    => println!("  일반 값: {}", other),
        }
    }

    // 열거형 variant는 경로로 명시
    #[derive(Debug)]
    enum Kind { Lion, Duck, Snake }

    // 세 variant 모두 순회하며 exhaustive match 확인
    for kind in [Kind::Lion, Kind::Duck, Kind::Snake] {
        match kind {
            Kind::Lion  => println!("  사자"),
            Kind::Duck  => println!("  오리"),
            Kind::Snake => println!("  뱀"),
        }
    }
}

// ─── 심화 3: @ 바인딩과 OR 패턴의 우선순위 ───────────────────────────────
//
//  공식 Book (ch19):
//  "The at operator @ lets us create a variable that holds a value
//   at the same time we're testing that value for a pattern match."
//
//  @ 바인딩과 | (OR 패턴)의 우선순위:
//
//  match x {
//      n @ 1 | 2 => println!("{}", n),   // 주의! n은 1에만 바인딩
//  }
//  // 이것은 (n @ 1) | 2 와 같다
//  // → x가 1이면 n=1, x가 2이면 n 바인딩 없음 → 에러!
//  // 에러: variable `n` is not bound in all patterns
//
//  올바른 방법:
//  match x {
//      n @ (1 | 2) => println!("{}", n),  // 괄호로 OR 묶기 → n이 1 또는 2
//  }

fn demo_at_binding_precedence() {
    println!("\n  [심화3: @ 바인딩 우선순위]");

    let numbers = vec![1u32, 2, 3, 5, 10, 15];

    for &n in &numbers {
        let desc = match n {
            // n @ (1 | 2 | 3) — 괄호로 OR 묶기
            x @ (1 | 2 | 3) => format!("소수 범위: {}", x),
            x @ 4..=9       => format!("중간 범위: {}", x),
            x               => format!("큰 수: {}", x),
        };
        println!("  {}: {}", n, desc);
    }

    // @ 바인딩 + 가드
    let snakes = vec![
        Snake::new("Short",  2, false).with_length(80),
        Snake::new("Medium", 4, false).with_length(130),
        Snake::new("Long",   6, true).with_length(210),
    ];

    for snake in &snakes {
        let desc = match snake.length_cm() {
            len @ 0..=100   if !snake.is_venomous() =>
                format!("소형 무독 ({}cm)", len),
            len @ 101..=200 =>
                format!("중형 ({}cm)", len),
            len             =>
                format!("대형 ({}cm, 독:{})", len, snake.is_venomous()),
        };
        println!("  {}: {}", snake.name(), desc);
    }
}

// ─── 심화 4: let else — 에러 처리 관용구 ────────────────────────────────
//
//  Rust 1.65에서 도입된 let else.
//  기존에 if let + 조기 반환이 필요할 때 indent가 깊어지는 문제 해결.
//
//  기존 방식 (indent 깊어짐):
//  fn process(opt: Option<String>) {
//      if let Some(name) = opt {
//          if name.len() > 2 {
//              if let Ok(n) = name.parse::<u32>() {
//                  println!("{}", n);
//              }
//          }
//      }
//  }
//
//  let else 방식 (flat):
//  fn process(opt: Option<String>) {
//      let Some(name) = opt         else { return; };
//      let true = name.len() > 2    else { return; };
//      let Ok(n) = name.parse::<u32>() else { return; };
//      println!("{}", n);
//  }
//
//  let else의 else 블록은 반드시 발산(diverge)해야 함:
//    return, break, continue, panic!, loop {} 등

fn process_lion_data(name: Option<&str>, age_str: Option<&str>) -> Option<Lion> {
    // let else — 중첩 없이 조기 반환
    let Some(name) = name else {
        println!("    이름 없음 — 처리 중단");
        return None;
    };

    let Some(age_str) = age_str else {
        println!("    나이 문자열 없음 — 처리 중단");
        return None;
    };

    let Ok(age) = age_str.parse::<u32>() else {
        println!("    나이 파싱 실패('{}') — 처리 중단", age_str);
        return None;
    };

    // 여기까지 오면 name, age_str, age 모두 유효
    Some(Lion::new(name, age))
}

fn demo_let_else() {
    println!("\n  [심화4: let else — 평탄한 에러 처리]");

    let cases = vec![
        (Some("Simba"), Some("5")),
        (None,          Some("4")),
        (Some("Nala"),  Some("abc")),
        (Some("Scar"),  Some("9")),
    ];

    for (name, age) in &cases {
        match process_lion_data(*name, *age) {
            Some(lion) => println!("  ✅ {}", lion.status()),
            None       => println!("  ❌ 처리 실패"),
        }
    }
}

// ─── 심화 5: match 가드의 범위 실수 ──────────────────────────────────────
//
//  가드는 패턴이 아닌 조건식 — 패턴 매칭 후에 평가된다.
//
//  match x {
//      y if some_condition => ... // some_condition이 false면 다음 arm으로
//  }
//
//  OR 패턴과 가드:
//  match x {
//      1 | 2 if guard => ...  // 가드는 1과 2 모두에 적용됨
//  }
//  // (1 | 2) if guard 와 같음
//  // 1 | (2 if guard) 가 아님!
//
//  컴파일러는 가드를 통해 exhaustiveness를 확인하지 않는다:
//  match x {
//      n if n > 0 => "양수",  // n <= 0인 경우 처리 안 함
//      // ← 에러: non-exhaustive patterns: `i32::MIN..=0i32` not covered
//      _ => "그 외",
//  }

fn demo_guard_scope() {
    println!("\n  [심화5: match 가드 범위]");

    let lions = vec![
        Lion::new("A", 2),
        Lion::new("B", 5),
        Lion::new("C", 8),
        Lion::new("D", 14),
    ];

    for lion in &lions {
        // OR 패턴 + 가드: 가드가 OR 전체에 적용
        let category = match lion.age() {
            // 2 또는 5살이면서 배고픈 경우
            2 | 5 if lion.is_hungry() => "배고픈 특별 나이",
            2 | 5                     => "특별 나이 (배부름)",
            a if a < 8               => "청년",
            a if a <= Lion::MAX_AGE  => "노년",
            _                        => "초과",
        };
        println!("  {} ({}살): {}", lion.name(), lion.age(), category);
    }
}

pub fn run() {
    println!("\n══════ Part 7 심화: 패턴 매칭 고급 ══════");
    demo_refutable_irrefutable();
    demo_variable_shadowing();
    demo_at_binding_precedence();
    demo_let_else();
    demo_guard_scope();
}
