// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 7-1.  match 기본, exhaustiveness, 가드(guard)                   │
// │                                                                       │
// │  match는 표현식(expression)이다 — 값을 반환한다.                        │
// │  모든 가능한 경우를 처리해야 한다(exhaustive).                          │
// │  컴파일러가 누락된 패턴을 에러로 잡는다.                                │
// └───────────────────────────────────────────────────────────────────────┘

// ─── match 구조 도식 ─────────────────────────────────────────────────────
//
//  match SCRUTINEE {
//      PATTERN1 => EXPRESSION1,
//      PATTERN2 if GUARD => EXPRESSION2,   // 가드 조건
//      PATTERN3 | PATTERN4 => EXPRESSION3, // 여러 패턴 OR
//      _        => EXPRESSION4,            // 와일드카드 (나머지 모두)
//  }
//
//  SCRUTINEE: 매칭할 값
//  PATTERN:   값의 구조를 기술하는 패턴
//  GUARD:     패턴이 일치한 후 추가로 검사하는 조건식
//  _:         어떤 값이든 일치, 값을 무시
//  ..:        구조체/튜플의 나머지 필드 무시

use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part6_enum::enum6_basic::AnimalKind;

pub fn run() {
    println!("\n─── Part 7-1: match 기본 ───");

    // ── 리터럴 매칭 ───────────────────────────────────────────────────────
    println!("\n  [리터럴 매칭]");
    let age: u32 = 7;
    let category = match age {
        0       => "신생아",
        1..=2   => "아기",
        3..=5   => "유년기",
        6..=12  => "청소년",
        13..=20 => "성년",
        _       => "노년",       // _ : 나머지 모든 경우
    };
    println!("  나이 {}: {}", age, category);

    // ── match는 표현식 — 값 반환 ─────────────────────────────────────────
    println!("\n  [match는 표현식 — 값 반환]");
    let kind = AnimalKind::Snake;
    let emoji = match kind {
        AnimalKind::Lion  => "🦁",
        AnimalKind::Duck  => "🦆",
        AnimalKind::Snake => "🐍",
    };
    println!("  {:?} 이모지: {}", kind, emoji);
    // exhaustive: AnimalKind에 새 variant를 추가하면 컴파일 에러 발생

    // ── 가드(guard) — if 조건 추가 ──────────────────────────────────────
    println!("\n  [가드 (match guard)]");
    let animals = vec![
        Lion::new("Simba", 5),
        Lion::new("Mufasa", 14),
        Lion::new("Nala", 4),
        Lion::new("Scar", 9),
    ];
    for lion in &animals {
        let status = match lion.age() {
            age if age < 3              => "아기 사자",
            age if age <= Lion::MAX_AGE / 2 => "성인 사자",
            age if age <= Lion::MAX_AGE => "시니어 사자",
            _                          => "초과 나이",
        };
        println!("  {} ({}살): {}", lion.name(), lion.age(), status);
    }

    // ── | (OR 패턴) ─────────────────────────────────────────────────────
    println!("\n  [| OR 패턴]");
    let snakes = vec![
        Snake::new("Nagini", 8, true),
        Snake::new("Kaa", 5, false),
        Snake::new("Cobra", 6, true),
    ];
    for snake in &snakes {
        let action = match (snake.is_venomous(), snake.length_cm()) {
            (true,  len) if len > 180 => "최고 위험",
            (true,  _)                => "위험",
            (false, len) if len > 150 => "대형 무독",
            (false, _)                => "안전",
        };
        println!("  {} (독:{}, {}cm): {}",
            snake.name(), snake.is_venomous(), snake.length_cm(), action);
    }

    // ── tuple 매칭 ──────────────────────────────────────────────────────
    println!("\n  [tuple 매칭]");
    let pairs = vec![
        (true,  true),
        (true,  false),
        (false, true),
        (false, false),
    ];
    for (a, b) in &pairs {
        let desc = match (a, b) {
            (true,  true)  => "둘 다 참",
            (true,  false) => "첫 번째만",
            (false, true)  => "두 번째만",
            (false, false) => "둘 다 거짓",
        };
        println!("  ({}, {}): {}", a, b, desc);
    }

    // ── _ 와 .. ─────────────────────────────────────────────────────────
    println!("\n  [_ 와 나머지 무시]");
    let duck = Duck::new("Donald", 3).with_feathers(450);
    // 필요한 필드만 추출, 나머지는 .. 로 무시
    let Duck { name, feathers, .. } = duck;
    println!("  Duck name={}, feathers={}", name, feathers);
}
