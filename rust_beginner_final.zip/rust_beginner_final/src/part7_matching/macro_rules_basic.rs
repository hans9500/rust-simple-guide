// ┌──────────────────────────────────────────────────────────────────
// │ Part 7 보강: macro_rules! 기초
// │
// │ 공식 문서: Rust Book Ch.19.6, Rust Reference "Macros by Example"
// │
// │ macro_rules!: 선언적 매크로 (Declarative Macro)
// │   패턴 매칭으로 코드를 생성 — 컴파일 타임에 확장됨
// │
// │ 왜 필요한가?
// │   - 반복되는 코드를 줄임
// │   - 가변 인자 지원 (fn은 불가)
// │   - vec![], println!, assert! 등이 모두 macro_rules!
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [Part 7 보강: macro_rules! 기초]");
    demo_basic_macro();
    demo_repetition();
    demo_practical_macros();
}

// ── 기본 매크로 ───────────────────────────────────────────────────
// say_hello!() → println!("안녕!") 으로 확장
macro_rules! say_hello {
    () => {
        println!("  안녕, 동물원!");
    };
    ($name:expr) => {
        println!("  안녕, {}!", $name);
    };
}

// 여러 패턴 매칭
macro_rules! animal_info {
    // 이름만
    ($name:expr) => {
        println!("  동물: {}", $name);
    };
    // 이름 + 나이
    ($name:expr, $age:expr) => {
        println!("  동물: {} ({}살)", $name, $age);
    };
    // 이름 + 나이 + 종
    ($name:expr, $age:expr, $species:expr) => {
        println!("  동물: {} ({}살, {})", $name, $age, $species);
    };
}

fn demo_basic_macro() {
    println!("\n  ── 기본 macro_rules! ──");

    say_hello!();
    say_hello!("Simba");

    animal_info!("Donald");
    animal_info!("Simba", 5);
    animal_info!("Nagini", 8, "뱀");
}

// ── 반복(repetition) ─────────────────────────────────────────────
// $(...),* → 0개 이상 반복
// $(...),+ → 1개 이상 반복
// $(...);* → ; 구분 반복

// vec!와 유사한 zoo_vec! 매크로
macro_rules! zoo_vec {
    // 빈 벡터
    () => { Vec::new() };
    // 하나 이상의 요소
    ($($item:expr),+ $(,)?) => {
        {
            let mut v = Vec::new();
            $(v.push($item);)+
            v
        }
    };
}

// 여러 동물을 한 번에 출력
macro_rules! print_animals {
    ($($name:expr => $sound:expr),+ $(,)?) => {
        $(
            println!("  {}: {}", $name, $sound);
        )+
    };
}

// HashMap 리터럴처럼 사용
macro_rules! zoo_map {
    ($($key:expr => $val:expr),+ $(,)?) => {
        {
            let mut map = std::collections::HashMap::new();
            $(map.insert($key, $val);)+
            map
        }
    };
}

fn demo_repetition() {
    println!("\n  ── 반복($(...)*) ──");

    let animals = zoo_vec!["사자", "오리", "뱀"];
    println!("  zoo_vec!: {:?}", animals);

    let empty: Vec<&str> = zoo_vec![];
    println!("  빈 zoo_vec!: {:?}", empty);

    print_animals!(
        "사자" => "으르렁",
        "오리" => "꽥꽥",
        "뱀"   => "쉭쉭",
    );

    let map = zoo_map!(
        "사자" => 190.5f64,
        "오리" => 2.5,
        "뱀"   => 15.0,
    );
    let mut sorted: Vec<_> = map.iter().collect();
    sorted.sort_by_key(|(k, _)| *k);
    println!("  zoo_map!: {:?}", sorted);
}

// ── 실전 매크로 ───────────────────────────────────────────────────
// 간단한 assert 래퍼
macro_rules! check {
    ($cond:expr) => {
        if $cond {
            println!("  ✅ 통과: {}", stringify!($cond));
        } else {
            println!("  ❌ 실패: {}", stringify!($cond));
        }
    };
    ($cond:expr, $msg:expr) => {
        if $cond {
            println!("  ✅ {}", $msg);
        } else {
            println!("  ❌ {}", $msg);
        }
    };
}

// 구조체 Display 자동 구현
macro_rules! impl_display {
    ($type:ty, $fmt:literal $(, $field:ident)*) => {
        impl std::fmt::Display for $type {
            fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
                write!(f, $fmt $(, self.$field)*)
            }
        }
    };
}

struct Animal {
    name:    String,
    species: String,
    age:     u32,
}

// impl Display for Animal { ... } 을 매크로로 한 줄에
impl_display!(Animal, "{} ({}) {}살", name, species, age);

fn demo_practical_macros() {
    println!("\n  ── 실전 매크로 ──");

    let ages = vec![5u32, 3, 8, 10];
    check!(ages.len() == 4);
    check!(ages.iter().sum::<u32>() == 26);
    check!(ages[0] == 5, "첫 번째 나이 확인");
    check!(ages.iter().all(|&a| a > 0), "모두 양수");

    let lion = Animal {
        name:    "Simba".to_string(),
        species: "사자".to_string(),
        age:     5,
    };
    println!("  impl_display! 결과: {}", lion);

    println!("\n  ── 매크로 vs 함수 ──");
    println!("  매크로: 가변 인자, 타입 가변, 코드 생성 가능");
    println!("  함수:   타입 안전, 디버깅 쉬움, 권장");
    println!("  매크로가 필요한 경우:");
    println!("    1. 가변 인자 (println!, vec!)");
    println!("    2. 다른 타입에 같은 패턴 반복 구현");
    println!("    3. DSL (도메인 특화 언어)");
}
