// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 7.  패턴 매칭(Pattern Matching) 완전 가이드                      ║
// ║                                                                       ║
// ║  공식 레퍼런스: "Matches in Rust are exhaustive: We must exhaust      ║
// ║  every last possibility in order for the code to be valid."           ║
// ║                                                                       ║
// ║  match7_basic   — match 기본, exhaustiveness, 가드                    ║
// ║  match7_binding — 구조체 분해, @ 바인딩, ..                            ║
// ║  match7_if_let  — if let, while let, let else                         ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod match7_basic;
pub mod match7_binding;
pub mod match7_if_let;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 7: 패턴 매칭(Pattern Matching)");
    println!("══════════════════════════════════════════════════════════");
    match7_basic::run();
    match7_binding::run();
    match7_if_let::run();
    matching_advanced::run();
    match7_advanced_patterns::run();
    macro_rules_basic::run();
}
pub mod matching_advanced;
pub mod match7_advanced_patterns;
pub mod macro_rules_basic;
