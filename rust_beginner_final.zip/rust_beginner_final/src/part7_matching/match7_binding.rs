// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 7-2.  구조 분해, @ 바인딩, ref 패턴                              │
// │                                                                       │
// │  @ 바인딩: 값을 검사하면서 동시에 변수에 바인딩.                         │
// │  공식 Book: "The at operator @ lets us create a variable that holds   │
// │  a value at the same time we're testing that value for a match."      │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part6_enum::enum6_basic::ZooEvent;
use crate::part6_enum::enum6_basic::AnimalKind;

pub fn run() {
    println!("\n─── Part 7-2: 구조 분해 & @ 바인딩 ───");

    // ── struct 분해 ──────────────────────────────────────────────────────
    println!("\n  [struct 분해]");
    let lion = Lion::new("Simba", 5);
    // struct의 필드를 변수로 꺼낸다
    let Lion { name, age, hungry } = lion.clone();
    println!("  name={}, age={}, hungry={}", name, age, hungry);

    // 일부 필드만, 나머지는 ..
    let Lion { name: lion_name, .. } = lion;
    println!("  lion_name={}", lion_name);

    // ── enum variant 분해 ────────────────────────────────────────────────
    println!("\n  [enum variant 분해]");
    let events = vec![
        ZooEvent::AnimalArrived { name: "Simba".into(), kind: AnimalKind::Lion, age: 5 },
        ZooEvent::AnimalFed { name: "Donald".into(), food: "곡물".into(), amount: 0.2 },
        ZooEvent::CageOpened(3),
        ZooEvent::EmergencyAlert,
    ];
    for event in &events {
        match event {
            ZooEvent::AnimalArrived { name, kind, age } =>
                println!("  도착: {} ({:?}, {}살)", name, kind, age),
            ZooEvent::AnimalFed { name, food, amount } =>
                println!("  급식: {} — {} {}kg", name, food, amount),
            ZooEvent::CageOpened(n) | ZooEvent::CageClosed(n) =>
                println!("  우리 #{} 상태 변경", n),
            ZooEvent::EmergencyAlert =>
                println!("  ⚠ 긴급!"),
            _ => println!("  기타 이벤트"),
        }
    }

    // ── @ 바인딩 ─────────────────────────────────────────────────────────
    //
    //  match msg {
    //      Message::Hello { id: id @ 3..=7 } => println!("범위 내 id: {}", id)
    //      //                  ↑ 바인딩이름 @ 범위패턴
    //  }
    //  "3..=7 범위인지 검사하면서, 동시에 그 값을 id에 바인딩"
    println!("\n  [@ 바인딩]");
    let snakes = vec![
        Snake::new("Short", 2, false).with_length(80),
        Snake::new("Medium", 4, false).with_length(130),
        Snake::new("Long", 6, true).with_length(200),
    ];
    for snake in &snakes {
        let desc = match snake.length_cm() {
            len @ 0..=100   => format!("소형 ({}cm)", len),
            len @ 101..=150 => format!("중형 ({}cm)", len),
            len             => format!("대형 ({}cm)", len),
        };
        println!("  {}: {}", snake.name(), desc);
    }

    // @ 바인딩 + 가드
    println!("\n  [@ 바인딩 + 가드]");
    let lions = vec![
        Lion::new("Young", 2),
        Lion::new("Adult", 8),
        Lion::new("Elder", 14),
    ];
    for lion in &lions {
        let desc = match lion.age() {
            age @ 0..=5 if lion.is_hungry() =>
                format!("배고픈 새끼 ({}살)", age),
            age @ 0..=5 =>
                format!("배부른 새끼 ({}살)", age),
            age @ 6..=12 =>
                format!("성인 ({}살)", age),
            age =>
                format!("노년 ({}살)", age),
        };
        println!("  {}: {}", lion.name(), desc);
    }

    // ── 중첩 패턴 ────────────────────────────────────────────────────────
    println!("\n  [중첩 패턴]");
    let ducks = vec![
        (Duck::new("Donald", 3).with_feathers(800), true),   // (오리, 건강함?)
        (Duck::new("Daffy",  4).with_feathers(200), false),
    ];
    for (duck, healthy) in &ducks {
        match (duck, healthy) {
            (d, true)  if d.is_molting() =>
                println!("  {}: 털갈이 중이지만 건강", d.name()),
            (d, true) =>
                println!("  {}: 건강 ({} 깃털)", d.name(), d.feathers()),
            (d, false) =>
                println!("  {}: 아픔 주의", d.name()),
        }
    }
}
