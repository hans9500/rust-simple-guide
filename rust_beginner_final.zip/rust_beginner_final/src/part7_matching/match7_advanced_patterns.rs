// ┌──────────────────────────────────────────────────────────────────
// │ Part 7 보강: 패턴 매칭 심화
// │
// │ - 중첩 구조 분해
// │ - 복합 가드 (if 조건)
// │ - 다중 패턴 (|)
// │ - 구조체 패턴 분해
// │ - let-else (Rust 1.65+)
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [Part 7 보강: 패턴 매칭 심화]");
    demo_nested_destructure();
    demo_complex_guards();
    demo_struct_patterns();
    demo_let_else();
    demo_matches_macro();
}

// ── 중첩 구조 분해 ────────────────────────────────────────────────
#[derive(Debug)]
enum Habitat {
    Indoor { floor: u8, section: String },
    Outdoor { area_m2: f64 },
}

#[derive(Debug)]
struct Animal {
    name:    String,
    age:     u32,
    habitat: Habitat,
    tags:    Vec<String>,
}

fn demo_nested_destructure() {
    println!("\n  ── 중첩 구조 분해 ──");

    let animals = vec![
        Animal {
            name:    "Simba".to_string(),
            age:     5,
            habitat: Habitat::Indoor { floor: 2, section: "아프리카관".to_string() },
            tags:    vec!["육식".to_string(), "대형".to_string()],
        },
        Animal {
            name:    "Donald".to_string(),
            age:     3,
            habitat: Habitat::Outdoor { area_m2: 500.0 },
            tags:    vec!["조류".to_string()],
        },
    ];

    for animal in &animals {
        // tags 출력
        println!("  태그: {:?}", animal.tags);
        // 중첩 enum + 구조체 동시 분해
        match &animal.habitat {
            Habitat::Indoor { floor, section } => {
                println!("  {} → 실내 {}층 {} (나이: {})", animal.name, floor, section, animal.age);
            }
            Habitat::Outdoor { area_m2 } => {
                println!("  {} → 실외 {}m² (나이: {})", animal.name, area_m2, animal.age);
            }
        }
    }

    // 튜플 중첩 분해
    let data = vec![
        (("Simba", 5), ("사자", 190.0f64)),
        (("Donald", 3), ("오리", 2.5)),
    ];
    for ((name, age), (species, weight)) in &data {
        println!("  {} {} {}살 {}kg", name, species, age, weight);
    }

    // ..으로 나머지 무시
    if let Animal { name, habitat: Habitat::Indoor { section, .. }, .. } = &animals[0] {
        println!("  {} 는 {} 에 있음", name, section);
    }
}

// ── 복합 가드 ─────────────────────────────────────────────────────
fn demo_complex_guards() {
    println!("\n  ── 복합 가드 ──");

    let animals: Vec<(&str, u32, f64)> = vec![
        ("사자", 5,  190.0),
        ("오리", 3,  2.5),
        ("코끼리", 10, 4000.0),
        ("뱀", 8, 15.0),
        ("기린", 6, 800.0),
    ];

    for (species, age, weight) in &animals {
        // 패턴 + if 가드 조합
        let category = match (species, age, weight) {
            (s, a, w) if *a >= 5 && *w >= 100.0 => {
                format!("대형 성체 ({}, {}살, {}kg)", s, a, w)
            }
            (s, a, _) if *a >= 5 => {
                format!("소형 성체 ({}, {}살)", s, a)
            }
            (s, _, _) => {
                format!("새끼 ({})", s)
            }
        };
        println!("  {}", category);
    }

    // 다중 패턴 |
    let sounds = vec!["으르렁", "꽥꽥", "쉭쉭", "뿡", "모름"];
    for sound in &sounds {
        let animal = match *sound {
            "으르렁" | "포효" => "사자/호랑이",
            "꽥꽥" | "꿱꿱"  => "오리/거위",
            "쉭쉭" | "쒸이"  => "뱀",
            _                => "알 수 없음",
        };
        println!("  '{}' → {}", sound, animal);
    }
}

// ── 구조체 패턴 ───────────────────────────────────────────────────
#[derive(Debug)]
struct Point { x: f64, y: f64 }

#[derive(Debug)]
enum Message {
    Move    { x: i32, y: i32 },
    Feed    (String),
    Health  { animal: String, score: u8 },
    Quit,
}

fn demo_struct_patterns() {
    println!("\n  ── 구조체 & enum 패턴 ──");

    let messages = vec![
        Message::Move { x: 10, y: -5 },
        Message::Feed("Simba".to_string()),
        Message::Health { animal: "Donald".to_string(), score: 85 },
        Message::Quit,
    ];

    for msg in &messages {
        match msg {
            Message::Move { x, y } =>
                println!("  이동: ({}, {})", x, y),
            Message::Feed(name) =>
                println!("  먹이: {}", name),
            Message::Health { animal, score } if *score >= 80 =>
                println!("  {} 건강 양호: {}점", animal, score),
            Message::Health { animal, score } =>
                println!("  {} 건강 주의: {}점", animal, score),
            Message::Quit =>
                println!("  종료"),
        }
    }

    // 구조체 필드 분해 + 이름 변경
    let p = Point { x: 3.0, y: -4.0 };
    let Point { x: px, y: py } = p;
    println!("  Point: ({}, {})", px, py);

    // 범위 패턴
    let ages = [1u32, 3, 5, 8, 12, 20];
    for age in &ages {
        let stage = match age {
            0..=2   => "영아",
            3..=5   => "유아",
            6..=11  => "아동",
            12..=17 => "청소년",
            _       => "성인",
        };
        println!("  {}살 → {}", age, stage);
    }
}

// ── let-else (Rust 1.65+) ─────────────────────────────────────────
fn get_lion_age(data: &str) -> Option<u32> {
    // let-else: 패턴 실패 시 else 블록 (diverge 필수)
    let parts: Vec<&str> = data.split(',').collect();

    // 패턴 실패 시 즉시 return — if let의 반전
    let Some(&name_part) = parts.first() else {
        return None;
    };

    if name_part != "사자" {
        return None;
    }

    let Some(&age_str) = parts.get(1) else {
        return None;
    };

    age_str.parse().ok()
}

fn demo_let_else() {
    println!("\n  ── let-else (Rust 1.65+) ──");

    let inputs = ["사자,5", "오리,3", "사자", "뱀,abc"];
    for input in &inputs {
        match get_lion_age(input) {
            Some(age) => println!("  '{}' → 사자 나이: {}살", input, age),
            None      => println!("  '{}' → 사자 아님 또는 파싱 실패", input),
        }
    }

    // let-else 직접 예시
    let value = Some(42u32);
    let Some(n) = value else {
        println!("  None 이면 여기로 (diverge: return/break/panic)");
        return;
    };
    println!("  let-else 통과: n={}", n);
}

// ── matches! 매크로 ───────────────────────────────────────────────
fn demo_matches_macro() {
    println!("\n  ── matches! 매크로 ──");

    let animals: Vec<(&str, u32)> = vec![
        ("사자", 5), ("오리", 3), ("뱀", 8), ("코끼리", 10),
    ];

    // matches!: bool 반환 — if let 의 간결 버전
    let has_old = animals.iter().any(|(_, age)| matches!(age, 6..=20));
    println!("  6~20살 있음: {}", has_old);

    let lion_count = animals.iter()
        .filter(|(s, _)| matches!(*s, "사자" | "호랑이"))
        .count();
    println!("  고양이과: {}마리", lion_count);

    // Option/enum 빠른 체크
    let opt: Option<u32> = Some(5);
    println!("  Some인가: {}", matches!(opt, Some(_)));
    println!("  Some(5)인가: {}", matches!(opt, Some(5)));
    println!("  Some(6..=10)인가: {}", matches!(opt, Some(6..=10)));
}
