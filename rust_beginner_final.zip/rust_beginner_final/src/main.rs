// ╔═══════════════════════════════════════════════════════════════════════╗
// ║          동물원으로 배우는 Rust impl 완전 가이드                         ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod part0_ownership;
pub mod part1_lifetime;
pub mod part2_patterns;
pub mod part3_std_traits;
pub mod part4_dispatch;
pub mod part5_advanced;
pub mod part6_enum;
pub mod part7_matching;
pub mod part8_expr_stmt;
pub mod part9_smart_ptr;
pub mod part10_closure;
pub mod part11_iterator;
pub mod part12_string;
pub mod part13_error;
pub mod part14_module;
pub mod part15_io;
pub mod part16_concurrency;
pub mod part17_thread_async;
pub mod part18_zoo_app;
pub mod appendix;

fn main() {
    let part = std::env::var("RUN_PART").unwrap_or_else(|_| "all".to_string());

    println!("\n╔══════════════════════════════════════════════════════════╗");
    println!("║     동물원으로 배우는 Rust impl 완전 가이드               ║");
    println!("╚══════════════════════════════════════════════════════════╝");
    println!("  실행 모드: {}", if part == "all" { "전체".to_string() } else { format!("Part {}", part) });

    match part.as_str() {
        "0"   => part0_ownership::run(),
        "1"   => part1_lifetime::run(),
        "2"   => part2_patterns::run(),
        "3"   => part3_std_traits::run(),
        "4"   => part4_dispatch::run(),
        "5"   => part5_advanced::run(),
        "6"   => part6_enum::run(),
        "7"   => part7_matching::run(),
        "8"   => part8_expr_stmt::run(),
        "9"   => part9_smart_ptr::run(),
        "10"  => part10_closure::run(),
        "11"  => part11_iterator::run(),
        "12"  => part12_string::run(),
        "13"  => part13_error::run(),
        "14"  => part14_module::run(),
        "15"  => part15_io::run(),
        "16"  => part16_concurrency::run(),
        "17"  => part17_thread_async::run(),
        "18"  => part18_zoo_app::run(),
        "app" => appendix::run(),
        _     => run_all(),
    }

    println!("\n╔══════════════════════════════════════════════════════════╗");
    println!("║  완료: 실행 성공                                         ║");
    println!("╚══════════════════════════════════════════════════════════╝\n");
}

fn run_all() {
    part0_ownership::run();
    part1_lifetime::run();
    part2_patterns::run();
    part3_std_traits::run();
    part4_dispatch::run();
    part5_advanced::run();
    part6_enum::run();
    part7_matching::run();
    part8_expr_stmt::run();
    part9_smart_ptr::run();
    part10_closure::run();
    part11_iterator::run();
    part12_string::run();
    part13_error::run();
    part14_module::run();
    part15_io::run();
    part16_concurrency::run();
    part17_thread_async::run();
    part18_zoo_app::run();
    appendix::run();
}
