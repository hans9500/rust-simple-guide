// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-5: 다형성 — Box<dyn Trait> + 라이프타임                     │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    trait 정의     — 공통 인터페이스                                   │
// │    Box<dyn Trait> — 서로 다른 타입을 하나의 Vec에                    │
// │    'a 라이프타임  — 참조를 구조체에 담을 때                           │
// │    dyn Trait      — 동적 디스패치                                    │
// │    impl Trait     — 정적 디스패치                                    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Box<dyn ZooAnimal> 필요한 이유                                      │
// │                                                                     │
// │  Vec<Lion>   → 사자만 가능                                          │
// │  Vec<Duck>   → 오리만 가능                                          │
// │                                                                     │
// │  Vec<Box<dyn ZooAnimal>>                                            │
// │    → 사자, 오리, 뱀 모두 한 Vec에 ✅                                │
// │    → 각 원소가 힙에 할당 (크기가 다르므로)                           │
// │    → vtable로 메서드 동적 호출                                       │
// │                                                                     │
// │  라이프타임 'a 필요한 이유:                                           │
// │  struct AnimalRef<'a> { inner: &'a dyn ZooAnimal }                  │
// │    → &dyn ZooAnimal 를 구조체에 담으려면                             │
// │    → 참조가 구조체보다 오래 살아야 함을 명시                          │
// └─────────────────────────────────────────────────────────────────────┘

use std::fmt;

// ── 공통 트레이트 정의 ────────────────────────────────────────────────
pub trait ZooAnimal: fmt::Display {
    fn sound(&self) -> &str;
    fn species_name(&self) -> &str;
    fn age(&self) -> u32;
    fn describe(&self) -> String {
        format!("{} ({}살): {}", self, self.age(), self.sound())
    }
}

// ── 구체 타입들 ───────────────────────────────────────────────────────
pub struct SimpleLion  { pub name: String, pub age: u32 }
pub struct SimpleDuck  { pub name: String, pub age: u32 }
pub struct SimpleSnake { pub name: String, pub age: u32 }

impl fmt::Display for SimpleLion {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "사자 {}", self.name)
    }
}
impl fmt::Display for SimpleDuck {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "오리 {}", self.name)
    }
}
impl fmt::Display for SimpleSnake {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "뱀 {}", self.name)
    }
}

impl ZooAnimal for SimpleLion {
    fn sound(&self) -> &str { "으르렁" }
    fn species_name(&self) -> &str { "사자" }
    fn age(&self) -> u32 { self.age }
}
impl ZooAnimal for SimpleDuck {
    fn sound(&self) -> &str { "꽥꽥" }
    fn species_name(&self) -> &str { "오리" }
    fn age(&self) -> u32 { self.age }
}
impl ZooAnimal for SimpleSnake {
    fn sound(&self) -> &str { "쉬이익" }
    fn species_name(&self) -> &str { "뱀" }
    fn age(&self) -> u32 { self.age }
}

// ── 혼합 전시관 — Box<dyn ZooAnimal> ─────────────────────────────────
pub struct MixedExhibit {
    pub name:    String,
    animals: Vec<Box<dyn ZooAnimal>>,
}

impl MixedExhibit {
    pub fn new(name: &str) -> Self {
        MixedExhibit { name: name.to_string(), animals: Vec::new() }
    }

    // 제네릭으로 추가 — T가 ZooAnimal이면 Box<dyn ZooAnimal>로 변환
    pub fn add<T: ZooAnimal + 'static>(&mut self, animal: T) {
        self.animals.push(Box::new(animal));
    }

    // dyn Trait 순회
    pub fn show_all(&self) {
        println!("  [{}] {}종:", self.name, self.animals.len());
        for animal in &self.animals {
            println!("    {}", animal.describe());
        }
    }

    // 클로저로 필터 — &dyn ZooAnimal
    pub fn find_by_species<'a>(&'a self, species: &str) -> Vec<&'a dyn ZooAnimal> {
        self.animals.iter()
            .filter(|a| a.species_name() == species)
            .map(|a| a.as_ref())
            .collect()
    }

    // 가장 나이 많은 동물
    pub fn oldest(&self) -> Option<&dyn ZooAnimal> {
        self.animals.iter()
            .max_by_key(|a| a.age())
            .map(|a| a.as_ref())
    }
}

// ── 라이프타임 'a — 참조를 구조체에 담기 ─────────────────────────────
pub struct AnimalRef<'a> {
    pub animal: &'a dyn ZooAnimal,
    pub note:   String,
}

impl<'a> AnimalRef<'a> {
    pub fn new(animal: &'a dyn ZooAnimal, note: &str) -> Self {
        AnimalRef { animal, note: note.to_string() }
    }

    pub fn print(&self) {
        println!("  참조: {} [{}]", self.animal, self.note);
    }
}

// ── 데모 ──────────────────────────────────────────────────────────────
pub fn demo() {
    println!("\n  ── Box<dyn Trait> + 라이프타임 ──");

    let mut exhibit = MixedExhibit::new("자연 생태관");

    // 서로 다른 타입을 하나의 Vec에 — Box<dyn ZooAnimal>
    exhibit.add(SimpleLion  { name: "Simba".to_string(),  age: 5 });
    exhibit.add(SimpleDuck  { name: "Donald".to_string(), age: 3 });
    exhibit.add(SimpleSnake { name: "Nagini".to_string(), age: 7 });
    exhibit.add(SimpleLion  { name: "Mufasa".to_string(), age: 10 });

    exhibit.show_all();

    // 종으로 필터
    let lions = exhibit.find_by_species("사자");
    println!("  사자만: {}마리", lions.len());
    for l in &lions { println!("    {}", l); }

    // 가장 나이 많은
    if let Some(oldest) = exhibit.oldest() {
        println!("  최연장자: {}", oldest.describe());
    }

    // 라이프타임 'a — 전시관의 동물을 참조로 담기
    // AnimalRef는 exhibit보다 오래 살면 안 됨 → 컴파일러가 보장
    {
        let refs: Vec<AnimalRef> = exhibit.animals.iter()
            .map(|a| AnimalRef::new(a.as_ref(), "관찰 중"))
            .collect();
        println!("  동물 참조 목록:");
        for r in &refs { r.print(); }
    } // refs drop — exhibit는 계속 유효

    println!("  → exhibit 여전히 유효: {}종", exhibit.animals.len());
}
