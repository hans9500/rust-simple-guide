// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-6: 동시성 — 방문자 통계                                     │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    Arc<T>          — 스레드 간 공유 소유권                            │
// │    Mutex<T>        — 상호 배제 잠금                                  │
// │    Arc<Mutex<T>>   — 스레드 간 공유 가변 데이터                       │
// │    thread::spawn   — 스레드 생성                                     │
// │    join()          — 스레드 완료 대기                                 │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Arc<Mutex<T>> 패턴                                                  │
// │                                                                     │
// │  Arc: 여러 스레드가 같은 데이터를 소유                                │
// │       Clone → 참조 카운트 증가 (원자적)                              │
// │                                                                     │
// │  Mutex: 한 번에 하나의 스레드만 접근                                  │
// │         lock() → MutexGuard (drop 시 자동 해제)                     │
// │                                                                     │
// │  스레드1 ──Arc::clone──▶ ┌──────────────────┐                      │
// │  스레드2 ──Arc::clone──▶ │ Arc<Mutex<Data>> │                      │
// │  스레드3 ──Arc::clone──▶ └──────────────────┘                      │
// │            lock() 한 번에 하나만                                     │
// └─────────────────────────────────────────────────────────────────────┘

use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

// 방문자 통계 데이터
struct VisitorStats {
    total:      u32,
    by_section: Vec<(String, u32)>,
}

impl VisitorStats {
    fn new() -> Self {
        VisitorStats {
            total: 0,
            by_section: vec![
                ("사자관".to_string(),   0),
                ("조류관".to_string(),   0),
                ("파충류관".to_string(), 0),
                ("코끼리관".to_string(), 0),
                ("펭귄관".to_string(),   0),
            ],
        }
    }

    fn enter(&mut self, section_idx: usize, count: u32) {
        self.total += count;
        if section_idx < self.by_section.len() {
            self.by_section[section_idx].1 += count;
        }
    }

    fn print_report(&self) {
        println!("  총 방문자: {}명", self.total);
        for (name, count) in &self.by_section {
            println!("    {}: {}명", name, count);
        }
    }
}

// ── 데모 ──────────────────────────────────────────────────────────────
pub fn demo() {
    println!("\n  ── Arc<Mutex<T>> — 스레드 간 방문자 통계 ──");

    // 공유 데이터 생성
    let stats = Arc::new(Mutex::new(VisitorStats::new()));
    let mut handles = vec![];

    // 5개 구역에서 동시 입장 시뮬레이션
    for section_idx in 0..5 {
        let stats_clone = Arc::clone(&stats);

        let h = thread::spawn(move || {
            // 각 구역 3회 입장 이벤트
            for _ in 0..3 {
                let visitors = (section_idx as u32 + 1) * 10;
                {
                    let mut s = stats_clone.lock().unwrap();
                    s.enter(section_idx, visitors);
                } // MutexGuard drop → 잠금 해제
                thread::sleep(Duration::from_millis(5));
            }
        });
        handles.push(h);
    }

    // 모든 스레드 완료 대기
    for h in handles {
        h.join().unwrap();
    }

    // 결과 출력
    let s = stats.lock().unwrap();
    s.print_report();
    drop(s); // 명시적 해제

    // 클로저로 통계 처리 — 스레드 + 클로저 조합
    println!("\n  ── 클로저를 스레드에 전달 ──");

    let results = Arc::new(Mutex::new(vec![]));
    let mut handles = vec![];

    let operations: Vec<Box<dyn Fn() -> String + Send>> = vec![
        Box::new(|| format!("구역A 청소 완료")),
        Box::new(|| format!("구역B 먹이 배분 완료")),
        Box::new(|| format!("구역C 의료 점검 완료")),
    ];

    for op in operations {
        let results_clone = Arc::clone(&results);
        let h = thread::spawn(move || {
            let result = op();
            results_clone.lock().unwrap().push(result);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }

    let mut final_results = results.lock().unwrap();
    final_results.sort(); // 순서 보장
    println!("  완료된 작업:");
    for r in final_results.iter() {
        println!("    {}", r);
    }
}
