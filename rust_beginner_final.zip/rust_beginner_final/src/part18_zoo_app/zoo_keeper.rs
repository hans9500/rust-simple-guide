// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-3: 사육사-동물 관계 — Rc / RefCell                         │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    Rc<T>         — 여러 소유자 (단일 스레드)                          │
// │    RefCell<T>    — 런타임 가변 빌림 (interior mutability)            │
// │    Rc<RefCell<T>>— 공유 + 가변 조합                                  │
// │    borrow()      — 불변 참조 Ref<T>                                  │
// │    borrow_mut()  — 가변 참조 RefMut<T>                               │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  왜 Rc<RefCell<Animal>>이 필요한가?                                  │
// │                                                                     │
// │  문제: 여러 사육사가 같은 동물을 담당                                 │
// │    사육사A ──▶ 사자(Simba)  ◀── 사육사B                             │
// │                                                                     │
// │  Rc만 사용: 여러 소유자 가능, 그러나 수정 불가                        │
// │  RefCell만 사용: 수정 가능, 그러나 소유자 하나                        │
// │  Rc<RefCell<T>>: 여러 소유자 + 수정 가능 ✅                          │
// │                                                                     │
// │  borrow_mut() 규칙 (런타임 검사):                                    │
// │    가변 빌림은 한 번에 하나만                                         │
// │    위반 시 컴파일 에러 아닌 런타임 panic!                             │
// └─────────────────────────────────────────────────────────────────────┘

use std::rc::Rc;
use std::cell::RefCell;
use crate::part18_zoo_app::zoo_types::{Animal, AnimalStatus, Species};

// Rc<RefCell<Animal>> 타입 별칭 — 자주 쓰므로
type SharedAnimal = Rc<RefCell<Animal>>;

pub struct Keeper {
    pub name:    String,
    pub animals: Vec<SharedAnimal>,
}

impl Keeper {
    pub fn new(name: &str) -> Self {
        Keeper {
            name:    name.to_string(),
            animals: Vec::new(),
        }
    }

    // 동물 배정 — Rc::clone으로 소유권 공유
    pub fn assign(&mut self, animal: SharedAnimal) {
        println!("  {} → {} 배정", self.name, animal.borrow().name);
        self.animals.push(Rc::clone(&animal));
    }

    // 담당 동물 전체 먹이 주기 — borrow_mut()으로 상태 변경
    pub fn feed_all(&self) {
        println!("  {} 먹이 시작:", self.name);
        for shared in &self.animals {
            let mut animal = shared.borrow_mut(); // RefMut<Animal>
            animal.status = AnimalStatus::Eating;
            println!("    {} → {}", animal.name, animal.status);
        } // RefMut drop → 빌림 해제
    }

    // 재우기
    pub fn sleep_all(&self) {
        for shared in &self.animals {
            shared.borrow_mut().status = AnimalStatus::Sleeping;
        }
    }

    // 담당 동물 리포트 — borrow()로 읽기
    pub fn report(&self) -> String {
        self.animals.iter()
            .map(|a| {
                let a = a.borrow(); // Ref<Animal>
                format!("{} ({})", a.name, a.status)
            })
            .collect::<Vec<_>>()
            .join(", ")
    }

    pub fn animal_count(&self) -> usize {
        self.animals.len()
    }
}

// ── 데모 ──────────────────────────────────────────────────────────────
pub fn demo() {
    println!("\n  ── Rc<RefCell<T>> — 공유 소유권 + 가변 ──");

    // 동물 생성 — Rc<RefCell<>>로 감쌈
    let simba  = Rc::new(RefCell::new(Animal::new(1, "Simba",  Species::Lion,    5)));
    let donald = Rc::new(RefCell::new(Animal::new(2, "Donald", Species::Duck,    3)));
    let nagini = Rc::new(RefCell::new(Animal::new(3, "Nagini", Species::Snake,   7)));

    // 사육사 생성
    let mut keeper_a = Keeper::new("김사육사");
    let mut keeper_b = Keeper::new("이사육사");

    // 사자는 두 사육사 공동 담당
    keeper_a.assign(Rc::clone(&simba));
    keeper_a.assign(Rc::clone(&donald));
    keeper_b.assign(Rc::clone(&simba));   // simba를 두 사육사가 공유
    keeper_b.assign(Rc::clone(&nagini));

    println!("  {} 담당: {}마리", keeper_a.name, keeper_a.animal_count());
    println!("  {} 담당: {}마리", keeper_b.name, keeper_b.animal_count());
    println!("  simba Rc 참조 수: {}", Rc::strong_count(&simba));

    // 먹이 주기 — 각 사육사가 독립적으로 상태 변경
    keeper_a.feed_all();
    keeper_b.sleep_all();

    // 리포트
    println!("  {}의 담당: {}", keeper_a.name, keeper_a.report());
    println!("  {}의 담당: {}", keeper_b.name, keeper_b.report());

    // simba 상태 확인 — 마지막 변경이 반영됨
    println!("  simba 현재 상태: {}", simba.borrow().status);

    // 직접 수정도 가능
    simba.borrow_mut().status = AnimalStatus::Healthy;
    println!("  simba 회복: {}", simba.borrow());
}
