// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-4: 파일 저장/불러오기                                        │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    BufWriter      — 버퍼링 파일 쓰기                                 │
// │    BufReader      — 버퍼링 파일 읽기                                 │
// │    ? 연산자       — 에러 전파 (From 자동 변환)                        │
// │    writeln!       — 파일에 줄 쓰기                                   │
// │    lines()        — 줄 단위 Iterator                                 │
// │    parse::<T>()   — 문자열 → 숫자 변환                               │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  CSV 형식                                                           │
// │                                                                     │
// │  id,name,species,age,status                                         │
// │  1,Simba,Lion,5,Healthy                                             │
// │  2,Donald,Duck,3,Eating                                             │
// │                                                                     │
// │  ? 연산자 흐름:                                                      │
// │  File::open()  → io::Error                                          │
// │      ↓ ?                                                            │
// │  From<io::Error> for ZooError 자동 호출                             │
// │      ↓                                                              │
// │  ZooError::IoError(e) 로 변환 후 반환                               │
// └─────────────────────────────────────────────────────────────────────┘

use std::fs::File;
use std::io::{BufWriter, BufRead, BufReader, Write};
use crate::part18_zoo_app::zoo_types::{Animal, AnimalStatus, Species, ZooError, ZooResult};
use crate::part18_zoo_app::zoo_registry::ZooRegistry;

const CSV_HEADER: &str = "id,name,species,age,status";

// ── 저장 ──────────────────────────────────────────────────────────────
pub fn save(path: &str, registry: &ZooRegistry) -> ZooResult<usize> {
    let file   = File::create(path)?;          // io::Error → ? → ZooError
    let mut w  = BufWriter::new(file);

    writeln!(w, "{}", CSV_HEADER)?;

    let mut count = 0;
    for animal in registry.all_sorted_by_age() {
        writeln!(w, "{},{},{},{},{}",
            animal.id,
            animal.name,
            animal.species.to_csv_str(),
            animal.age,
            animal.status.to_csv_str(),
        )?;
        count += 1;
    }
    w.flush()?;
    Ok(count)
}

// ── 불러오기 ──────────────────────────────────────────────────────────
pub fn load(path: &str) -> ZooResult<ZooRegistry> {
    let file   = File::open(path)?;            // ? 로 에러 전파
    let reader = BufReader::new(file);
    let mut registry = ZooRegistry::new();

    for (i, line) in reader.lines().enumerate() {
        let line = line?;                       // io::Error → ZooError
        if i == 0 { continue; }                // 헤더 건너뜀
        if line.trim().is_empty() { continue; }

        let animal = parse_csv_line(&line)?;
        registry.load_animal(animal);
    }
    Ok(registry)
}

// ── CSV 한 줄 파싱 ────────────────────────────────────────────────────
fn parse_csv_line(line: &str) -> ZooResult<Animal> {
    let parts: Vec<&str> = line.split(',').collect();
    if parts.len() < 5 {
        return Err(ZooError::ParseError(
            format!("CSV 형식 오류: {}", line)
        ));
    }

    let id  = parts[0].trim().parse::<u32>()
        .map_err(|_| ZooError::ParseError(format!("ID 파싱 실패: {}", parts[0])))?;
    let name    = parts[1].trim().to_string();
    let species = Species::try_from(parts[2].trim())?;
    let age     = parts[3].trim().parse::<u32>()
        .map_err(|_| ZooError::ParseError(format!("나이 파싱 실패: {}", parts[3])))?;
    let status  = AnimalStatus::from_csv_str(parts[4].trim())?;

    Ok(Animal { id, name, species, age, status })
}

// ── CSV 변환 트레이트 확장 ─────────────────────────────────────────────
trait ToCsvStr {
    fn to_csv_str(&self) -> &str;
}

impl ToCsvStr for Species {
    fn to_csv_str(&self) -> &str {
        match self {
            Species::Lion     => "Lion",
            Species::Duck     => "Duck",
            Species::Snake    => "Snake",
            Species::Elephant => "Elephant",
            Species::Penguin  => "Penguin",
        }
    }
}

impl ToCsvStr for AnimalStatus {
    fn to_csv_str(&self) -> &str {
        match self {
            AnimalStatus::Healthy  => "Healthy",
            AnimalStatus::Sick     => "Sick",
            AnimalStatus::Eating   => "Eating",
            AnimalStatus::Sleeping => "Sleeping",
        }
    }
}

impl AnimalStatus {
    fn from_csv_str(s: &str) -> ZooResult<Self> {
        match s {
            "Healthy"  => Ok(AnimalStatus::Healthy),
            "Sick"     => Ok(AnimalStatus::Sick),
            "Eating"   => Ok(AnimalStatus::Eating),
            "Sleeping" => Ok(AnimalStatus::Sleeping),
            other      => Err(ZooError::ParseError(
                format!("알 수 없는 상태: {}", other)
            )),
        }
    }
}

// ── 데모 ──────────────────────────────────────────────────────────────
pub fn demo(registry: &ZooRegistry) {
    println!("\n  ── 파일 저장/불러오기 ──");

    let path = "/tmp/zoo18_data.csv";

    // 저장
    match save(path, registry) {
        Ok(n)  => println!("  저장 완료: {} → {}마리", path, n),
        Err(e) => println!("  저장 실패: {}", e),
    }

    // 불러오기
    match load(path) {
        Ok(loaded) => {
            println!("  불러오기 완료: {}마리", loaded.count());
            println!("  불러온 동물:");
            loaded.print_all();
        }
        Err(e) => println!("  불러오기 실패: {}", e),
    }

    // 파일 정리
    let _ = std::fs::remove_file(path);
    println!("  임시 파일 삭제 완료");
}
