// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-2: 동물 등록소 — CRUD + 검색                               │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    HashMap<K,V>     — 키-값 저장소                                   │
// │    Option<T>        — 값이 있을 수도 없을 수도                        │
// │    &T / &mut T      — 불변/가변 참조                                 │
// │    제네릭 클로저     — fn search<F: Fn(&Animal)->bool>               │
// │    Iterator 체이닝  — filter/map/sort_by/collect                    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  ZooRegistry 구조                                                   │
// │                                                                     │
// │  ZooRegistry                                                        │
// │    ├── animals: HashMap<u32, Animal>                                │
// │    └── next_id: u32                                                 │
// │                                                                     │
// │  add()       → &mut self, 새 Animal 등록                            │
// │  get()       → &self, Option<&Animal>                               │
// │  get_mut()   → &mut self, Option<&mut Animal>                       │
// │  remove()    → &mut self, Option<Animal>                            │
// │  search()    → 클로저로 조건 전달, Vec<&Animal>                     │
// │  all_sorted()→ 나이순 정렬, Vec<&Animal>                            │
// └─────────────────────────────────────────────────────────────────────┘

use std::collections::HashMap;
use crate::part18_zoo_app::zoo_types::{Animal, AnimalStatus, Species, ZooError, ZooResult};

pub struct ZooRegistry {
    animals: HashMap<u32, Animal>,
    next_id: u32,
}

impl ZooRegistry {
    pub fn new() -> Self {
        ZooRegistry {
            animals: HashMap::new(),
            next_id: 1,
        }
    }

    // ── 등록 ─────────────────────────────────────────────────────────
    pub fn add(&mut self, name: &str, species: Species, age: u32) -> ZooResult<u32> {
        let id = self.next_id;
        self.next_id += 1;
        let animal = Animal::new(id, name, species, age);
        self.animals.insert(id, animal);
        Ok(id)
    }

    // ── 조회 — Option<&Animal> ────────────────────────────────────────
    pub fn get(&self, id: u32) -> Option<&Animal> {
        self.animals.get(&id)
    }

    // ── 가변 조회 — Option<&mut Animal> ──────────────────────────────
    pub fn get_mut(&mut self, id: u32) -> Option<&mut Animal> {
        self.animals.get_mut(&id)
    }

    // ── 삭제 — Option<Animal> (소유권 반환) ──────────────────────────
    pub fn remove(&mut self, id: u32) -> ZooResult<Animal> {
        self.animals.remove(&id)
            .ok_or(ZooError::NotFound(id))
    }

    // ── 상태 변경 ─────────────────────────────────────────────────────
    pub fn set_status(&mut self, id: u32, status: AnimalStatus) -> ZooResult<()> {
        let animal = self.get_mut(id)
            .ok_or(ZooError::NotFound(id))?;
        animal.status = status;
        Ok(())
    }

    // ── 제네릭 클로저 검색 ────────────────────────────────────────────
    // F: Fn(&Animal) -> bool — 어떤 조건이든 클로저로 전달
    pub fn search<F>(&self, predicate: F) -> Vec<&Animal>
    where
        F: Fn(&Animal) -> bool,
    {
        self.animals.values()
            .filter(|a| predicate(a))
            .collect()
    }

    // ── 종(Species)으로 필터 ──────────────────────────────────────────
    pub fn by_species(&self, species: &Species) -> Vec<&Animal> {
        self.search(|a| &a.species == species)
    }

    // ── 성체만 ────────────────────────────────────────────────────────
    pub fn adults_only(&self) -> Vec<&Animal> {
        self.search(|a| a.is_adult())
    }

    // ── 나이순 정렬 ───────────────────────────────────────────────────
    pub fn all_sorted_by_age(&self) -> Vec<&Animal> {
        let mut list: Vec<&Animal> = self.animals.values().collect();
        list.sort_by(|a, b| a.age.cmp(&b.age));
        list
    }

    // ── 이름으로 검색 ─────────────────────────────────────────────────
    pub fn find_by_name(&self, name: &str) -> Option<&Animal> {
        self.animals.values()
            .find(|a| a.name.eq_ignore_ascii_case(name))
    }

    // ── 통계: 종별 마릿수 ─────────────────────────────────────────────
    pub fn species_count(&self) -> HashMap<String, usize> {
        let mut map: HashMap<String, usize> = HashMap::new();
        for animal in self.animals.values() {
            *map.entry(animal.species.to_string()).or_insert(0) += 1;
        }
        map
    }

    // 파일에서 불러올 때 사용 (id 보존)
    pub fn load_animal(&mut self, animal: Animal) {
        if animal.id >= self.next_id {
            self.next_id = animal.id + 1;
        }
        self.animals.insert(animal.id, animal);
    }

    pub fn count(&self) -> usize {
        self.animals.len()
    }

    pub fn is_empty(&self) -> bool {
        self.animals.is_empty()
    }

    // ── 전체 출력 ─────────────────────────────────────────────────────
    pub fn print_all(&self) {
        if self.animals.is_empty() {
            println!("  (등록된 동물 없음)");
            return;
        }
        for animal in self.all_sorted_by_age() {
            println!("  {}", animal);
        }
    }
}

// ── 데모 ──────────────────────────────────────────────────────────────
pub fn demo(registry: &mut ZooRegistry) {
    println!("\n  ── CRUD + 검색 ──");

    // 등록
    let id1 = registry.add("Simba",   Species::Lion,     5).unwrap();
    let id2 = registry.add("Donald",  Species::Duck,     3).unwrap();
    let id3 = registry.add("Nagini",  Species::Snake,    7).unwrap();
    let id4 = registry.add("Dumbo",   Species::Elephant, 12).unwrap();
    let id5 = registry.add("Pingu",   Species::Penguin,  2).unwrap();
    println!("  등록 완료: {}마리", registry.count());

    // 조회 — Option 처리
    match registry.get(id1) {
        Some(a) => println!("  조회: {}", a),
        None    => println!("  없음"),
    }

    // 가변 조회 — 상태 변경
    registry.set_status(id2, AnimalStatus::Eating).unwrap();
    println!("  상태 변경: {}", registry.get(id2).unwrap());

    // 제네릭 클로저 검색
    let young = registry.search(|a| a.age < 4);
    println!("  4살 미만: {}마리", young.len());

    // 종별 필터
    let lions = registry.by_species(&Species::Lion);
    println!("  사자: {}마리", lions.len());

    // 성체만
    let adults = registry.adults_only();
    println!("  성체: {}마리", adults.len());

    // 나이순 정렬
    println!("  나이순:");
    for a in registry.all_sorted_by_age() {
        println!("    {}", a);
    }

    // 통계
    println!("  종별 통계:");
    let mut counts: Vec<(String, usize)> = registry.species_count().into_iter().collect();
    counts.sort_by(|a, b| a.0.cmp(&b.0));
    for (s, n) in &counts {
        println!("    {}: {}마리", s, n);
    }

    // 삭제
    let removed = registry.remove(id5).unwrap();
    println!("  삭제: {} → 남은 {}마리", removed.name, registry.count());

    let _ = (id3, id4); // unused 경고 방지
}
