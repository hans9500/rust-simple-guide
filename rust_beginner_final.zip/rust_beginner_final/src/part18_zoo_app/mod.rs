// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18: 동물원 관리 시스템 — 실전 종합 예제                         │
// │                                                                     │
// │  18-1: zoo_types      — struct/enum/Display/From/Result             │
// │  18-2: zoo_registry   — HashMap/Option/제네릭클로저/Iterator         │
// │  18-3: zoo_keeper     — Rc/RefCell/interior mutability              │
// │  18-4: zoo_storage    — 파일I/O/BufWriter/BufReader/?연산자          │
// │  18-5: zoo_mixed      — Box<dyn Trait>/라이프타임'a                 │
// │  18-6: zoo_concurrent — Arc/Mutex/thread::spawn/join                │
// │  18-7: zoo_app        — 전체 통합                                   │
// └─────────────────────────────────────────────────────────────────────┘

pub mod zoo_types;
pub mod zoo_registry;
pub mod zoo_keeper;
pub mod zoo_storage;
pub mod zoo_mixed;
pub mod zoo_concurrent;
pub mod zoo_app;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 18: 동물원 관리 시스템 — 실전 종합 예제");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

    println!("\n[18-1: 핵심 타입]");
    demo_types();

    println!("\n[18-2: 동물 CRUD + 검색]");
    let mut registry = crate::part18_zoo_app::zoo_registry::ZooRegistry::new();
    zoo_registry::demo(&mut registry);

    println!("\n[18-3: 사육사-동물 관계]");
    zoo_keeper::demo();

    println!("\n[18-4: 파일 저장/불러오기]");
    let mut r2 = crate::part18_zoo_app::zoo_registry::ZooRegistry::new();
    zoo_registry::demo(&mut r2);
    zoo_storage::demo(&r2);

    println!("\n[18-5: 다형성 + 라이프타임]");
    zoo_mixed::demo();

    println!("\n[18-6: 동시성]");
    zoo_concurrent::demo();

    println!("\n[18-7: 전체 통합]");
    zoo_app::run();
}

fn demo_types() {
    use zoo_types::{Animal, AnimalStatus, Species, ZooError};
    use std::fmt::Write;

    let mut a = Animal::new(1, "Simba", Species::Lion, 5);
    println!("  생성: {}", a);
    println!("  성체여부: {}", a.is_adult());
    println!("  소리: {}", a.species.sound());

    a.status = AnimalStatus::Eating;
    println!("  상태변경: {}", a);

    // From<io::Error> 확인
    let e: ZooError = std::io::Error::new(
        std::io::ErrorKind::NotFound, "파일없음"
    ).into();
    println!("  에러변환: {}", e);

    // Display 포맷
    let mut s = String::new();
    write!(s, "{}", a).unwrap();
    println!("  Display: {}", s);
}
