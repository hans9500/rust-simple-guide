// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-1: 핵심 타입 정의                                           │
// │                                                                     │
// │  여기서 배우는 문법:                                                  │
// │    struct       — 데이터 구조체                                      │
// │    enum         — 열거형, 상태 표현                                   │
// │    impl Display — 출력 형식 정의                                     │
// │    impl From    — 타입 변환 (? 연산자 자동 변환)                      │
// │    Result<T,E>  — 에러 처리 기반                                     │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  전체 타입 구조                                                      │
// │                                                                     │
// │  Animal                                                             │
// │    ├── id: u32                                                      │
// │    ├── name: String                                                 │
// │    ├── species: Species  (enum)                                     │
// │    ├── age: u32                                                     │
// │    └── status: AnimalStatus  (enum)                                 │
// │                                                                     │
// │  ZooError                                                           │
// │    ├── NotFound(u32)                                                │
// │    ├── DuplicateId(u32)                                             │
// │    ├── ParseError(String)                                           │
// │    └── IoError(io::Error)  ← From<io::Error> 로 ? 자동 변환         │
// └─────────────────────────────────────────────────────────────────────┘

use std::fmt;
use std::io;

// ── Animal ────────────────────────────────────────────────────────────
#[derive(Debug, Clone)]
pub struct Animal {
    pub id:      u32,
    pub name:    String,
    pub species: Species,
    pub age:     u32,
    pub status:  AnimalStatus,
}

impl Animal {
    pub fn new(id: u32, name: &str, species: Species, age: u32) -> Self {
        Animal {
            id,
            name: name.to_string(),
            species,
            age,
            status: AnimalStatus::Healthy,
        }
    }

    pub fn is_adult(&self) -> bool {
        self.age >= self.species.adult_age()
    }
}

// Display: println!("{}", animal) 로 출력
impl fmt::Display for Animal {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "[{}] {} ({}, {}살, {})",
            self.id, self.name, self.species, self.age, self.status)
    }
}

// ── Species ───────────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Species {
    Lion,
    Duck,
    Snake,
    Elephant,
    Penguin,
}

impl Species {
    pub fn adult_age(&self) -> u32 {
        match self {
            Species::Lion     => 4,
            Species::Duck     => 1,
            Species::Snake    => 3,
            Species::Elephant => 10,
            Species::Penguin  => 2,
        }
    }

    pub fn sound(&self) -> &str {
        match self {
            Species::Lion     => "으르렁",
            Species::Duck     => "꽥꽥",
            Species::Snake    => "쉬이익",
            Species::Elephant => "뿌우",
            Species::Penguin  => "아옹",
        }
    }
}

impl fmt::Display for Species {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            Species::Lion     => "사자",
            Species::Duck     => "오리",
            Species::Snake    => "뱀",
            Species::Elephant => "코끼리",
            Species::Penguin  => "펭귄",
        };
        write!(f, "{}", s)
    }
}

// From<&str>: CSV 파싱 시 "Lion" → Species::Lion
impl TryFrom<&str> for Species {
    type Error = ZooError;
    fn try_from(s: &str) -> Result<Self, ZooError> {
        match s.trim() {
            "Lion"     => Ok(Species::Lion),
            "Duck"     => Ok(Species::Duck),
            "Snake"    => Ok(Species::Snake),
            "Elephant" => Ok(Species::Elephant),
            "Penguin"  => Ok(Species::Penguin),
            other      => Err(ZooError::ParseError(
                format!("알 수 없는 종: {}", other)
            )),
        }
    }
}

// ── AnimalStatus ──────────────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq)]
pub enum AnimalStatus {
    Healthy,
    Sick,
    Eating,
    Sleeping,
}

impl fmt::Display for AnimalStatus {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let s = match self {
            AnimalStatus::Healthy  => "건강",
            AnimalStatus::Sick     => "아픔",
            AnimalStatus::Eating   => "식사중",
            AnimalStatus::Sleeping => "수면중",
        };
        write!(f, "{}", s)
    }
}

// ── ZooError ──────────────────────────────────────────────────────────
#[derive(Debug)]
pub enum ZooError {
    NotFound(u32),
    DuplicateId(u32),
    ParseError(String),
    IoError(io::Error),
}

impl fmt::Display for ZooError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            ZooError::NotFound(id)    => write!(f, "동물 ID {} 없음", id),
            ZooError::DuplicateId(id) => write!(f, "ID {} 중복", id),
            ZooError::ParseError(s)   => write!(f, "파싱 에러: {}", s),
            ZooError::IoError(e)      => write!(f, "I/O 에러: {}", e),
        }
    }
}

// From<io::Error>: ? 연산자가 io::Error → ZooError 자동 변환
impl From<io::Error> for ZooError {
    fn from(e: io::Error) -> Self {
        ZooError::IoError(e)
    }
}

impl std::error::Error for ZooError {}

// 편의 타입 별칭
pub type ZooResult<T> = Result<T, ZooError>;
