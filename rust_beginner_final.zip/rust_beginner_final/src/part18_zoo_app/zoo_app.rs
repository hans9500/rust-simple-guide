// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 18-7: 전체 통합 실행                                           │
// │                                                                     │
// │  지금까지 배운 모든 문법을 하나의 흐름으로                             │
// │                                                                     │
// │  실행 순서:                                                          │
// │    1. 동물 등록 (HashMap, enum, Result)                              │
// │    2. 검색/필터 (Iterator, 클로저, 제네릭)                            │
// │    3. 사육사 배정 (Rc, RefCell, borrow_mut)                          │
// │    4. 파일 저장/불러오기 (BufWriter, ?, From)                        │
// │    5. 다형성 전시관 (Box<dyn Trait>, 라이프타임)                      │
// │    6. 동시성 통계 (Arc, Mutex, thread)                               │
// └─────────────────────────────────────────────────────────────────────┘

use crate::part18_zoo_app::{
    zoo_types::Species,
    zoo_registry::ZooRegistry,
    zoo_keeper::Keeper,
    zoo_mixed::MixedExhibit,
};
use std::rc::Rc;
use std::cell::RefCell;
use crate::part18_zoo_app::zoo_types::{Animal, AnimalStatus};
use crate::part18_zoo_app::zoo_mixed::{SimpleLion, SimpleDuck, SimpleSnake};

pub fn run() {
    println!("\n  [18-7: 동물원 관리 시스템 — 전체 통합]");

    // ── 1. 동물 등록 (HashMap + enum + Result) ──────────────────────
    println!("\n  ══ 1단계: 동물 등록 ══");
    let mut registry = ZooRegistry::new();

    let id1 = registry.add("Simba",   Species::Lion,     5).unwrap();
    let id2 = registry.add("Donald",  Species::Duck,     3).unwrap();
    let id3 = registry.add("Nagini",  Species::Snake,    7).unwrap();
    let id4 = registry.add("Dumbo",   Species::Elephant, 12).unwrap();
    let _id5 = registry.add("Pingu",  Species::Penguin,  2).unwrap();

    println!("  등록 완료: {}마리", registry.count());
    registry.print_all();

    // ── 2. 검색/필터 (Iterator + 클로저 + 제네릭) ───────────────────
    println!("\n  ══ 2단계: 검색/필터 ══");

    // 제네릭 클로저로 검색
    let old_animals = registry.search(|a| a.age >= 5);
    print!("  5살 이상: ");
    println!("{}", old_animals.iter().map(|a| a.name.as_str()).collect::<Vec<_>>().join(", "));

    // 종별 필터
    let lions = registry.by_species(&Species::Lion);
    println!("  사자: {}마리", lions.len());

    // 통계
    println!("  종별 통계:");
    let mut counts: Vec<_> = registry.species_count().into_iter().collect();
    counts.sort_by(|a, b| a.0.cmp(&b.0));
    for (s, n) in &counts { println!("    {}: {}마리", s, n); }

    // ── 3. 사육사 배정 (Rc + RefCell) ───────────────────────────────
    println!("\n  ══ 3단계: 사육사 배정 (Rc/RefCell) ══");

    // 동물을 Rc<RefCell<>>로 감쌈 — 여러 소유자 + 수정 가능
    let simba  = Rc::new(RefCell::new(
        Animal::new(id1, "Simba", Species::Lion, 5)
    ));
    let donald = Rc::new(RefCell::new(
        Animal::new(id2, "Donald", Species::Duck, 3)
    ));
    let nagini = Rc::new(RefCell::new(
        Animal::new(id3, "Nagini", Species::Snake, 7)
    ));

    let mut keeper_a = Keeper::new("김사육사");
    let mut keeper_b = Keeper::new("이사육사");

    // 사자는 두 사육사 공동 담당
    keeper_a.assign(Rc::clone(&simba));
    keeper_a.assign(Rc::clone(&donald));
    keeper_b.assign(Rc::clone(&simba));  // 같은 simba 공유
    keeper_b.assign(Rc::clone(&nagini));

    keeper_a.feed_all();
    println!("  {}의 담당: {}", keeper_b.name, keeper_b.report());

    // borrow_mut으로 상태 직접 변경
    simba.borrow_mut().status = AnimalStatus::Healthy;
    println!("  Simba 회복: {}", simba.borrow().status);

    // ── 4. 파일 저장/불러오기 (I/O + ? + From) ──────────────────────
    println!("\n  ══ 4단계: 파일 저장/불러오기 ══");
    crate::part18_zoo_app::zoo_storage::demo(&registry);

    // ── 5. 다형성 전시관 (Box<dyn Trait> + 라이프타임) ───────────────
    println!("\n  ══ 5단계: 다형성 전시관 ══");
    let mut exhibit = MixedExhibit::new("특별 전시관");
    exhibit.add(SimpleLion  { name: "Simba".to_string(),  age: 5 });
    exhibit.add(SimpleDuck  { name: "Donald".to_string(), age: 3 });
    exhibit.add(SimpleSnake { name: "Nagini".to_string(), age: 7 });
    exhibit.show_all();

    if let Some(oldest) = exhibit.oldest() {
        println!("  최연장자: {}", oldest.describe());
    }

    // ── 6. 동시성 통계 (Arc + Mutex + thread) ───────────────────────
    println!("\n  ══ 6단계: 방문자 통계 (멀티스레드) ══");
    crate::part18_zoo_app::zoo_concurrent::demo();

    // ── 마무리 ──────────────────────────────────────────────────────
    println!("\n  ══ 총정리 ══");
    println!("  사용한 Rust 핵심 문법:");
    for (syntax, usage) in [
        ("struct/enum",      "Animal, Species, AnimalStatus, ZooError"),
        ("impl Display",     "동물 출력 형식"),
        ("impl From",        "io::Error → ZooError (? 연산자 자동 변환)"),
        ("HashMap",          "동물 등록소 (O(1) 조회)"),
        ("Option<T>",        "조회 결과 (있을 수도 없을 수도)"),
        ("Result<T,E>",      "에러 처리 + ? 연산자"),
        ("제네릭 클로저",     "search<F: Fn(&Animal)->bool>"),
        ("Iterator 체이닝",  "filter/map/sort_by/collect"),
        ("Rc<RefCell<T>>",   "여러 사육사 → 같은 동물 공유+수정"),
        ("Box<dyn Trait>",   "Vec에 다양한 동물 타입 혼합"),
        ("라이프타임 'a",     "참조를 구조체에 담을 때"),
        ("Arc<Mutex<T>>",    "스레드 간 방문자 통계 공유"),
        ("파일 I/O",         "BufWriter/BufReader, CSV 저장/불러오기"),
    ] {
        println!("    {:<18} → {}", syntax, usage);
    }

    let _ = (id4,); // unused 경고 방지
}
