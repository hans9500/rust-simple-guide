// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-6: 스레드 vs 비동기 — 선택 기준                            │
// │                                                                     │
// │  공식 문서: Rust Async Book Ch.7 "Workarounds to Know"              │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: CPU 바운드 vs I/O 바운드 구분                              │
// │    2단계: 스레드 비용                                                │
// │    3단계: 비동기 비용                                                │
// │    4단계: 실측 비교                                                  │
// │    5단계: 선택 기준 정리                                             │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  핵심 구분                                                           │
// │                                                                     │
// │  CPU 바운드: 계산이 많아서 느림 (암호화, 이미지 처리, 수치 계산)        │
// │    → CPU 코어를 100% 사용 중                                        │
// │    → 스레드로 코어 추가 활용이 효과적                                 │
// │    → async 는 효과 없음 (양보해도 CPU가 바빠서 다른 일 못 함)         │
// │                                                                     │
// │  I/O 바운드: 네트워크/파일 대기가 많아서 느림                         │
// │    → CPU 는 대기 중 (낭비)                                          │
// │    → async .await 로 대기 중 다른 작업 처리                          │
// │    → 스레드보다 훨씬 적은 메모리로 수만 개 동시 처리                  │
// └─────────────────────────────────────────────────────────────────────┘

use std::thread;
use std::time::{Duration, Instant};
use std::sync::{Arc, Mutex};

pub fn run() {
    println!("\n  [17-6: 스레드 vs 비동기 선택 기준]");
    demo_cpu_bound();
    demo_io_bound_thread();
    demo_thread_cost();
    demo_selection_guide();
}

// ── 1단계: CPU 바운드 — 스레드가 유리 ──────────────────────────────
fn demo_cpu_bound() {
    println!("\n  ── 1단계: CPU 바운드 — 스레드로 코어 활용 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  CPU 바운드 예: 합산 계산                                             │
// │                                                                     │
// │  순차:  [sum 0..25M] [sum 25M..50M] [sum 50M..75M] [sum 75M..100M]│
// │         총 T초                                                       │
// │                                                                     │
// │  4스레드: [0..25M]                                                  │
// │           [25M..50M]  동시 실행                                      │
// │           [50M..75M]                                                │
// │           [75M..100M]                                               │
// │  총 T/4초 (코어가 4개라면)                                           │
// └─────────────────────────────────────────────────────────────────────┘

    const N: u64 = 2_000_000;

    // 순차 계산
    let start = Instant::now();
    let sum_seq: u64 = (0..N).sum();
    let seq_time = start.elapsed().as_millis();

    // 2스레드 병렬 계산
    let start = Instant::now();
    let half = N / 2;
    let h1 = thread::spawn(move || (0..half).sum::<u64>());
    let h2 = thread::spawn(move || (half..N).sum::<u64>());
    let sum_par = h1.join().unwrap() + h2.join().unwrap();
    let par_time = start.elapsed().as_millis();

    println!("  순차 합산 (0..{}): {}ms", N, seq_time);
    println!("  2스레드 병렬:      {}ms", par_time);
    println!("  결과 동일: {}", sum_seq == sum_par);
    println!("  → CPU 바운드는 스레드로 코어 수만큼 빨라짐");
}

// ── 2단계: I/O 바운드 — 스레드로 처리할 때 비용 ────────────────────
fn demo_io_bound_thread() {
    println!("\n  ── 2단계: I/O 바운드 — 스레드 방식 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  I/O 바운드를 스레드로 처리:                                          │
// │                                                                     │
// │  연결 1개 → 스레드 1개 (8MB 스택)                                    │
// │  연결 1000개 → 스레드 1000개 (8GB 메모리!)                           │
// │                                                                     │
// │  async 방식:                                                         │
// │  연결 1000개 → Future 1000개 (각 수KB)                              │
// │             → 스레드는 코어 수만큼만 (예: 8개)                       │
// └─────────────────────────────────────────────────────────────────────┘

    // 10개 I/O 작업을 스레드로 처리 (sleep으로 시뮬레이션)
    let start = Instant::now();
    let results = Arc::new(Mutex::new(vec![]));
    let mut handles = vec![];

    for i in 0..10 {
        let results = Arc::clone(&results);
        let h = thread::spawn(move || {
            thread::sleep(Duration::from_millis(20)); // I/O 대기 시뮬레이션
            results.lock().unwrap().push(i * i);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }

    let elapsed = start.elapsed().as_millis();
    println!("  10개 I/O 작업 (스레드): {}ms", elapsed);
    println!("  스레드 10개 생성 — 각 ~8MB 스택 사용");
    println!("  결과 수: {}개", results.lock().unwrap().len());
    println!("  → 수천 개라면 메모리 문제 발생");
}

// ── 3단계: 스레드 비용 ─────────────────────────────────────────────
fn demo_thread_cost() {
    println!("\n  ── 3단계: 스레드 생성 비용 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  스레드 비용:                                                        │
// │    생성: OS 시스템 콜 (느림)                                         │
// │    스택: 기본 8MB (Linux), 조정 가능하나 최소 수십KB                  │
// │    컨텍스트 스위치: 레지스터 저장/복원 (~수 μs)                       │
// │                                                                     │
// │  비동기(Future) 비용:                                                │
// │    생성: 힙 할당 (빠름)                                              │
// │    크기: Future 구조체 크기 (수십~수백 byte)                          │
// │    전환: .await 지점에서 협력적 전환 (컨텍스트 스위치 없음)            │
// └─────────────────────────────────────────────────────────────────────┘

    // 스레드 100개 생성 시간 측정
    let start = Instant::now();
    let mut handles = vec![];
    for _ in 0..100 {
        let h = thread::spawn(|| { /* 즉시 완료 */ });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }
    println!("  스레드 100개 생성+종료: {}ms", start.elapsed().as_millis());
    println!("  → 스레드는 생성 비용이 상당함");
    println!("  → async 태스크는 이보다 훨씬 가벼움 (tokio 기준 수십 ns)");
}

// ── 4단계: 선택 기준 정리 ───────────────────────────────────────────
fn demo_selection_guide() {
    println!("\n  ── 4단계: 선택 기준 정리 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  스레드를 선택:                                                      │
// │    CPU 집약 계산 (행렬곱, 암호화, 압축)                              │
// │    블로킹 라이브러리 사용 (블로킹 DB 드라이버 등)                     │
// │    병렬성이 코어 수에 비례                                            │
// │    격리성 필요 (panic 격리)                                          │
// │                                                                     │
// │  비동기를 선택:                                                      │
// │    네트워크 I/O (HTTP 서버, DB 클라이언트)                           │
// │    동시 연결 수천~수만 개                                             │
// │    메모리 효율이 중요                                                │
// │    I/O 대기 중 다른 작업 처리                                        │
// │                                                                     │
// │  둘 다 사용:                                                         │
// │    tokio::task::spawn_blocking → async 안에서 블로킹 코드 실행       │
// │    rayon → CPU 바운드 병렬 처리 (async와 병행 가능)                  │
// └─────────────────────────────────────────────────────────────────────┘

    println!("  스레드 선택:");
    println!("    CPU 집약 계산, 블로킹 라이브러리, 코어 병렬화");

    println!("  비동기 선택:");
    println!("    네트워크 I/O, 수천 동시 연결, 메모리 효율");

    println!("  함께 사용:");
    println!("    spawn_blocking → async 안에서 블로킹 작업 분리");
    println!("    rayon → CPU 병렬 + tokio I/O 조합 가능");

    println!();
    println!("  Part 17 정리:");
    println!("    스레드: std::thread — 완전한 예제 가능");
    println!("    프로세스: std::process::Command — 완전한 예제 가능");
    println!("    async/await: 문법은 std에 있음, 실행은 tokio 필요");
    println!("    Future 직접 구현: 이해를 위한 것, 실전은 async fn 사용");
}
