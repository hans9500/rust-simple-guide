// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-2: 스레드 동기화                                            │
// │                                                                     │
// │  공식 문서: std::thread::scope (Rust 1.63+)                         │
// │            std::sync::{Barrier, Condvar, Mutex}                    │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: thread::scope — Arc 없이 참조 공유                         │
// │    2단계: Barrier — N개 스레드 동기화 지점                           │
// │    3단계: Condvar — 조건 충족까지 대기                               │
// │    4단계: park / unpark — 명시적 스레드 제어                         │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  동기화 도구 선택 기준                                                │
// │                                                                     │
// │  Arc 없이 참조 공유 (수명 제한됨)  →  thread::scope                 │
// │  N개 스레드를 특정 지점에서 만남   →  Barrier                        │
// │  조건이 충족될 때까지 대기         →  Condvar + Mutex                │
// │  이벤트로 특정 스레드 깨우기       →  park / unpark                  │
// └─────────────────────────────────────────────────────────────────────┘

use std::thread;
use std::time::Duration;
use std::sync::{Arc, Barrier, Condvar, Mutex};
use std::sync::atomic::{AtomicBool, Ordering};

pub fn run() {
    println!("\n  [17-2: 스레드 동기화]");
    demo_scope();
    demo_barrier();
    demo_condvar();
    demo_park_unpark();
}

// ── 1단계: thread::scope ─────────────────────────────────────────────
fn demo_scope() {
    println!("\n  ── 1단계: thread::scope — Arc 없이 참조 공유 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Arc 없이 &data 를 스레드에 넘길 수 있는 이유:                       │
// │                                                                     │
// │  thread::scope(|s| {                                                │
// │      s.spawn(|| { ... &data ... });   ← &data 참조 가능             │
// │  });  ← 여기서 모든 스레드 자동 join                                 │
// │         스레드 수명 ⊂ scope 수명 → 컴파일러가 보장                   │
// └─────────────────────────────────────────────────────────────────────┘

    let animals = vec!["사자", "오리", "뱀", "코끼리"];

    thread::scope(|s| {
        // animals 슬라이스 참조를 직접 공유 — Arc 불필요
        for name in &animals {
            s.spawn(move || {
                println!("  scope 스레드: {} → 길이 {}", name, name.len());
            });
        }
        // scope 블록 끝에서 모든 스레드 자동 join
    });

    // scope 이후에도 animals 사용 가능 (스레드 모두 종료됨)
    println!("  동물 수: {} (scope 후 animals 여전히 유효)", animals.len());
    println!("  → scope 블록이 끝나면 모든 스레드 join 보장");
}

// ── 2단계: Barrier ───────────────────────────────────────────────────
fn demo_barrier() {
    println!("\n  ── 2단계: Barrier — 모든 스레드가 준비될 때까지 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Barrier 동작:                                                       │
// │                                                                     │
// │  T1: 먹이 준비 ────────▶ wait() ─┐                                  │
// │  T2: 먹이 준비 ──────────▶ wait() ─┼──▶ 동시에 급식 시작!           │
// │  T3: 먹이 준비 ────────────▶ wait() ─┘                              │
// │                                                                     │
// │  모든 스레드가 wait()에 도달해야 다음으로 진행                         │
// │  주의: Barrier::new(N) 의 N = spawn 수 정확히 일치                   │
// └─────────────────────────────────────────────────────────────────────┘

    const N: usize = 3;
    let barrier = Arc::new(Barrier::new(N));
    let mut handles = vec![];

    for (i, name) in ["사자", "오리", "뱀"].iter().enumerate() {
        let b = Arc::clone(&barrier);
        let h = thread::spawn(move || {
            // 각자 준비 (시간이 다름)
            thread::sleep(Duration::from_millis(10 * (i as u64 + 1)));
            println!("  {} 먹이 준비 완료, 대기 중...", name);

            b.wait(); // 모든 스레드가 여기 도달할 때까지 대기

            println!("  {} 급식 시작!", name);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }
    println!("  → 모든 동물이 동시에 급식 시작");
}

// ── 3단계: Condvar ───────────────────────────────────────────────────
fn demo_condvar() {
    println!("\n  ── 3단계: Condvar — 조건 충족까지 대기 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Condvar 패턴 (공식 문서):                                           │
// │                                                                     │
// │  대기자: lock 획득 → wait_while(lock, |v| !*v)                      │
// │           조건이 false인 동안 자동으로 대기                           │
// │           조건이 true가 되면 깨어남                                   │
// │                                                                     │
// │  알림자: lock 획득 → 조건 변경 → notify_one()                        │
// │                                                                     │
// │  주의: wait_while 사용 필수 — spurious wakeup 방지                   │
// └─────────────────────────────────────────────────────────────────────┘

    let pair = Arc::new((Mutex::new(false), Condvar::new()));

    // 대기자 스레드 — 먹이가 준비될 때까지 대기
    let pair_clone = Arc::clone(&pair);
    let waiter = thread::spawn(move || {
        let (lock, cvar) = &*pair_clone;
        let guard = lock.lock().unwrap();

        // wait_while: 조건(먹이 미준비)인 동안 대기
        let _guard = cvar.wait_while(guard, |ready| !*ready).unwrap();
        println!("  동물: 먹이 준비됨! 먹기 시작");
    });

    // 알림자 스레드 — 먹이 준비 후 알림
    let pair_clone2 = Arc::clone(&pair);
    let notifier = thread::spawn(move || {
        thread::sleep(Duration::from_millis(20));
        let (lock, cvar) = &*pair_clone2;
        let mut ready = lock.lock().unwrap();
        *ready = true;           // 조건 변경
        cvar.notify_one();       // 대기자 깨우기
        println!("  사육사: 먹이 준비 완료, 알림 전송");
    });

    notifier.join().unwrap();
    waiter.join().unwrap();
}

// ── 4단계: park / unpark ─────────────────────────────────────────────
fn demo_park_unpark() {
    println!("\n  ── 4단계: park / unpark — 명시적 스레드 제어 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  park / unpark 특성:                                                 │
// │                                                                     │
// │  unpark()는 "토큰"을 저장                                            │
// │  park()는 토큰이 있으면 즉시 반환 (대기 안 함)                        │
// │  → unpark가 park보다 먼저 와도 안전                                  │
// │                                                                     │
// │  spurious wakeup 가능 → AtomicBool + while 패턴 필수                │
// └─────────────────────────────────────────────────────────────────────┘

    let done = Arc::new(AtomicBool::new(false));
    let done_clone = Arc::clone(&done);

    let worker = thread::spawn(move || {
        println!("  작업자: 시작, 신호 대기 중...");

        // while 루프 필수 — spurious wakeup 방어
        while !done_clone.load(Ordering::Relaxed) {
            thread::park(); // 토큰 없으면 대기
        }

        println!("  작업자: 신호 받음, 작업 수행");
    });

    // 잠시 후 신호 전송
    thread::sleep(Duration::from_millis(20));
    done.store(true, Ordering::Relaxed); // 조건 먼저 변경
    worker.thread().unpark();            // 토큰 전달

    worker.join().unwrap();
    println!("  → park/unpark: Condvar보다 가볍지만 단순한 경우에만 사용");
}
