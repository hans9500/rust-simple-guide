// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17: 스레드 / 프로세스 / async                                  │
// │                                                                     │
// │  17-1: thread_basic   — 스레드 기초 (spawn→join→move→Arc)           │
// │  17-2: thread_sync    — 동기화 (scope/Barrier/Condvar/park)         │
// │  17-3: process_basic  — 외부 프로세스 (Command)                     │
// │  17-4: future_concept — Future 개념 (poll/Pending/Ready)            │
// │  17-5: async_syntax   — async/await 문법과 원리                     │
// │  17-6: thread_vs_async— 스레드 vs 비동기 선택 기준                   │
// └─────────────────────────────────────────────────────────────────────┘

pub mod thread_basic;
pub mod thread_sync;
pub mod process_basic;
pub mod future_concept;
pub mod async_syntax;
pub mod thread_vs_async;

pub fn run() {
    thread_basic::run();
    thread_sync::run();
    process_basic::run();
    future_concept::run();
    async_syntax::run();
    thread_vs_async::run();
}
