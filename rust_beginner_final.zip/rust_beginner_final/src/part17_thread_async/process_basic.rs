// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-3: 외부 프로세스                                            │
// │                                                                     │
// │  공식 문서: std::process::Command                                    │
// │            Rust Reference "Process"                                 │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: Command::output() — 동기 실행, 결과 수집                   │
// │    2단계: Command::spawn() — 비동기 실행, Child 핸들                 │
// │    3단계: stdin/stdout 파이프                                         │
// │    4단계: 환경변수, 작업 디렉토리                                     │
// │    5단계: 종료 코드와 에러 처리                                       │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  스레드 vs 프로세스                                                   │
// │                                                                     │
// │  스레드: 같은 프로세스 안, 메모리 공유, 빠른 통신                      │
// │  프로세스: 독립된 메모리 공간, IPC로 통신, 격리성 높음                │
// │                                                                     │
// │  Command: 외부 프로그램을 자식 프로세스로 실행                         │
// │    output()  → 완료까지 대기 후 stdout/stderr 수집                   │
// │    spawn()   → 즉시 반환, Child 핸들로 나중에 wait()                 │
// └─────────────────────────────────────────────────────────────────────┘

use std::process::{Command, Stdio};

pub fn run() {
    println!("\n  [17-3: 외부 프로세스]");
    demo_output();
    demo_spawn();
    demo_pipe();
    demo_env_and_exit();
}

// ── 1단계: output() — 동기 실행 ─────────────────────────────────────
fn demo_output() {
    println!("\n  ── 1단계: Command::output() — 완료까지 대기 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  output() 흐름:                                                      │
// │                                                                     │
// │  Command::new("rustc")                                              │
// │    .arg("--version")                                                │
// │    .output()     → 프로세스 실행 → 완료까지 대기                     │
// │    → Output { status, stdout, stderr }                              │
// └─────────────────────────────────────────────────────────────────────┘

    let output = Command::new("rustc")
        .arg("--version")
        .output()
        .expect("rustc 실행 실패");

    println!("  종료코드: {}", output.status);
    println!("  stdout: {}", String::from_utf8_lossy(&output.stdout).trim());

    // 실패하는 명령어
    let output2 = Command::new("rustc")
        .arg("--invalid-flag")
        .output()
        .expect("실행 실패");

    println!("  잘못된 플래그 종료코드: {}", output2.status);
    if !output2.status.success() {
        let err = String::from_utf8_lossy(&output2.stderr);
        println!("  stderr: {}", err.lines().next().unwrap_or(""));
    }
}

// ── 2단계: spawn() — 비동기 실행 ────────────────────────────────────
fn demo_spawn() {
    println!("\n  ── 2단계: Command::spawn() — 즉시 반환 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  spawn() 흐름:                                                       │
// │                                                                     │
// │  let mut child = Command::new(...).spawn()?;                        │
// │  // 여기서 즉시 반환 — child는 실행 중                               │
// │  // 다른 작업 수행 가능                                              │
// │  let status = child.wait()?;  // 완료 대기                          │
// └─────────────────────────────────────────────────────────────────────┘

    // cargo --version 을 자식 프로세스로 실행
    let mut child = Command::new("cargo")
        .arg("--version")
        .stdout(Stdio::piped())
        .spawn()
        .expect("cargo 실행 실패");

    println!("  자식 프로세스 시작됨 (pid 별도)");
    println!("  main은 계속 실행 중...");

    // 자식 프로세스 완료 대기
    let status = child.wait().expect("wait 실패");
    println!("  자식 프로세스 종료: {}", status);
}

// ── 3단계: 파이프 ───────────────────────────────────────────────────
fn demo_pipe() {
    println!("\n  ── 3단계: stdout 파이프 — 출력 캡처 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Stdio::piped() : 출력을 파이프로 연결 → 프로그램에서 읽기 가능       │
// │  Stdio::null()  : 출력 버림                                          │
// │  Stdio::inherit(): 부모 프로세스의 stdout/stderr 그대로 사용          │
// └─────────────────────────────────────────────────────────────────────┘

    // rustfmt --version 출력을 파이프로 캡처
    let output = Command::new("rustc")
        .args(["--print", "sysroot"])
        .stdout(Stdio::piped())
        .stderr(Stdio::null())  // stderr 버림
        .output();

    match output {
        Ok(o) => {
            let sysroot = String::from_utf8_lossy(&o.stdout);
            println!("  rustc sysroot: {}", sysroot.trim());
        }
        Err(e) => println!("  실행 실패: {}", e),
    }
}

// ── 4단계: 환경변수, 종료 코드 ──────────────────────────────────────
fn demo_env_and_exit() {
    println!("\n  ── 4단계: 환경변수 설정과 종료 코드 처리 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  종료 코드:                                                          │
// │    0        → 성공                                                  │
// │    비 0     → 실패 (관례)                                            │
// │                                                                     │
// │  status.success()  → 종료코드 0 여부                                 │
// │  status.code()     → Option<i32> (시그널 종료 시 None)              │
// └─────────────────────────────────────────────────────────────────────┘

    // 환경변수 설정
    let output = Command::new("rustc")
        .arg("--version")
        .env("RUST_BACKTRACE", "0")  // 환경변수 추가
        .output()
        .expect("실행 실패");

    // 종료 코드 확인
    match output.status.code() {
        Some(0) => println!("  성공 (종료코드 0)"),
        Some(n) => println!("  실패 (종료코드 {})", n),
        None    => println!("  시그널로 종료됨"),
    }

    // success() 패턴
    if output.status.success() {
        println!("  출력: {}", String::from_utf8_lossy(&output.stdout).trim());
    }

    println!("\n  정리:");
    println!("  output()  → 완료까지 대기, 결과 수집 (소규모)");
    println!("  spawn()   → 즉시 반환, Child.wait() 로 나중에 수집");
    println!("  Stdio::piped() → 출력 캡처  Stdio::null() → 출력 버림");
}
