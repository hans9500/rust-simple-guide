// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-1: 스레드 기초                                              │
// │                                                                     │
// │  공식 문서: Rust Book Ch.16.1                                        │
// │            std::thread                                              │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: 순차 실행의 한계                                            │
// │    2단계: thread::spawn — 그런데 main이 먼저 끝난다                  │
// │    3단계: JoinHandle::join() — 완료 보장                             │
// │    4단계: join()의 반환값 — 패닉 감지                                │
// │    5단계: move 클로저 — 데이터 소유권 이동                            │
// │    6단계: 여러 스레드 — Arc로 공유                                    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  스레드 생명주기                                                      │
// │                                                                     │
// │  spawn() → [자식 스레드 실행 중] → join() → 결과 Ok(T)/Err          │
// │                                                                     │
// │  join() 없으면:                                                      │
// │  spawn() → [자식 실행 중] → main 종료 → 자식 강제 종료!             │
// └─────────────────────────────────────────────────────────────────────┘

use std::thread;
use std::time::Duration;
use std::sync::{Arc, Mutex};

pub fn run() {
    println!("\n  [17-1: 스레드 기초]");
    demo_sequential();
    demo_spawn_problem();
    demo_join();
    demo_join_result();
    demo_move_closure();
    demo_arc_share();
}

// ── 1단계: 순차 실행의 한계 ───────────────────────────────────────────
fn simulate_work(name: &str, ms: u64) {
    thread::sleep(Duration::from_millis(ms));
    println!("  {} 완료 ({}ms)", name, ms);
}

fn demo_sequential() {
    println!("\n  ── 1단계: 순차 실행 (총 소요 = 합산) ──");
    let start = std::time::Instant::now();

    simulate_work("사자 먹이", 30);
    simulate_work("오리 먹이", 20);
    simulate_work("뱀 먹이",   25);

    println!("  순차 총 소요: {}ms (모두 더함)", start.elapsed().as_millis());
    println!("  → 동시에 처리할 수 있다면 가장 긴 것(30ms)만 걸린다");
}

// ── 2단계: spawn — 그런데 main이 먼저 끝난다 ──────────────────────────
fn demo_spawn_problem() {
    println!("\n  ── 2단계: join() 없으면 출력이 안 나올 수 있음 ──");

    // join() 없이 spawn만 하면 main이 먼저 끝나 자식 강제 종료
    // 아래는 의도적으로 즉시 완료되는 작업만 사용
    let h = thread::spawn(|| {
        println!("  자식 스레드: 실행됨");
    });
    h.join().unwrap(); // 여기서는 join 포함 — 다음 단계로 자연스럽게 연결
    println!("  → join() 없으면 위 출력이 안 나올 수도 있음");
}

// ── 3단계: JoinHandle::join() — 완료 보장 ────────────────────────────
fn demo_join() {
    println!("\n  ── 3단계: join()으로 완료 보장 ──");

    let start = std::time::Instant::now();
    let mut handles = vec![];

    // 세 스레드를 동시에 시작
    for (name, ms) in [("사자", 30u64), ("오리", 20), ("뱀", 25)] {
        let h = thread::spawn(move || {
            thread::sleep(Duration::from_millis(ms));
            println!("  {} 먹이 완료 ({}ms)", name, ms);
        });
        handles.push(h);
    }

    // 모든 스레드가 끝날 때까지 대기
    for h in handles {
        h.join().unwrap();
    }

    println!("  병렬 총 소요: {}ms (가장 긴 것만)", start.elapsed().as_millis());
    println!("  → 모든 join() 호출 필수: 하나라도 빠지면 강제 종료 위험");
}

// ── 4단계: join()의 반환값 — 패닉 감지 ──────────────────────────────
fn demo_join_result() {
    println!("\n  ── 4단계: join() → Result — 패닉 감지 가능 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  join() 반환값                                                       │
// │                                                                     │
// │  Ok(T)              → 스레드가 정상 완료, T는 클로저 반환값          │
// │  Err(Box<dyn Any>)  → 스레드가 panic! 발생                          │
// │                                                                     │
// │  중요: 자식 스레드의 panic은 main으로 전파되지 않는다                 │
// │        join()의 Err로 감지해야 한다                                  │
// └─────────────────────────────────────────────────────────────────────┘

    // 정상 완료 — Ok(반환값)
    let h1 = thread::spawn(|| {
        42u32  // 클로저의 반환값
    });
    match h1.join() {
        Ok(v)  => println!("  정상 완료: Ok({})", v),
        Err(_) => println!("  패닉 발생"),
    }

    // join() → Err 반환 시뮬레이션
    // 실제 panic! 은 RUST_BACKTRACE 설정에 따라 backtrace를 출력함
    // 여기서는 스레드 안에서 Result::Err 를 반환하는 방식으로 동일 효과 확인
    let h2 = thread::spawn(|| -> Result<(), &'static str> {
        Err("스레드 내부 에러")   // panic 없이 Err 반환
    });
    match h2.join() {
        Ok(Err(e)) => println!("  스레드 Err 반환: {} (join은 Ok)", e),
        Ok(Ok(_))  => println!("  정상 완료"),
        Err(_)     => println!("  패닉 감지: Err"),
    }
    println!("  → 스레드 panic 시 join() → Err(Box<dyn Any>) 반환");
    println!("  → RUST_BACKTRACE=1 환경변수로 backtrace 활성화 가능");
}

// ── 5단계: move 클로저 ────────────────────────────────────────────────
fn demo_move_closure() {
    println!("\n  ── 5단계: move 클로저 — 소유권 이동 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  왜 move가 필요한가?                                                  │
// │                                                                     │
// │  let name = "Simba";                                                │
// │  thread::spawn(|| println!("{}", name));  // 컴파일 에러!           │
// │  // 이유: 스레드가 name보다 오래 살 수 있음                           │
// │  //       name의 라이프타임을 컴파일러가 보장 못 함                   │
// │                                                                     │
// │  thread::spawn(move || println!("{}", name));  // OK                │
// │  // move: name 소유권을 스레드로 이동 → 라이프타임 문제 해결          │
// └─────────────────────────────────────────────────────────────────────┘

    let name = String::from("Simba");
    let age  = 5u32;

    let h = thread::spawn(move || {
        // name, age 가 이 스레드로 이동됨
        println!("  스레드 안: {} ({}살)", name, age);
    });
    h.join().unwrap();
    // name은 moved — 여기서 사용 불가

    // 여러 값을 스레드로 전달
    let animals = vec![
        ("Donald", 3u32),
        ("Nagini",  8),
    ];
    let mut handles = vec![];
    for (name, age) in animals {
        let h = thread::spawn(move || {
            println!("  스레드: {} {}살", name, age);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }
}

// ── 6단계: Arc로 여러 스레드가 같은 데이터 공유 ──────────────────────
fn demo_arc_share() {
    println!("\n  ── 6단계: Arc<Mutex<T>> — 공유 가변 데이터 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  여러 스레드가 같은 데이터를 수정하려면?                               │
// │                                                                     │
// │  move로는 소유권이 하나뿐 → 스레드 여러 개에 move 불가               │
// │  Arc: 원자적 참조 카운팅 → 여러 스레드에서 Clone 가능                │
// │  Mutex: 한 번에 하나의 스레드만 접근 → 데이터 경쟁 방지              │
// └─────────────────────────────────────────────────────────────────────┘

    let counter = Arc::new(Mutex::new(0u32));
    let mut handles = vec![];

    for i in 0..5 {
        let c = Arc::clone(&counter);
        let h = thread::spawn(move || {
            let mut val = c.lock().unwrap();
            *val += 1;
            println!("  스레드 {}: counter = {}", i, *val);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }

    println!("  최종 counter: {}", counter.lock().unwrap());
    println!("  → Arc::clone은 소유권 복사가 아닌 참조 카운트 증가");
}
