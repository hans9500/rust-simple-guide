// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-5: async / await 문법                                      │
// │                                                                     │
// │  공식 문서: Rust Async Book Ch.3                                     │
// │            Rust Reference "Async expressions"                       │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: async fn 선언 → impl Future<Output=T> 반환                │
// │    2단계: async 블록 → 인라인 Future 생성                            │
// │    3단계: 왜 런타임이 필요한가                                        │
// │    4단계: 실행 불가 예시 — 에러로 배우기                              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  async fn — 문법 설탕(syntax sugar)                                 │
// │                                                                     │
// │  async fn greet(name: &str) -> String {                            │
// │      format!("안녕, {}!", name)                                     │
// │  }                                                                  │
// │          ↓ 컴파일러 변환                                             │
// │  fn greet(name: &str) -> impl Future<Output = String> {            │
// │      async { format!("안녕, {}!", name) }                           │
// │  }                                                                  │
// └─────────────────────────────────────────────────────────────────────┘

pub fn run() {
    println!("\n  [17-5: async/await 문법]");
    demo_async_fn_type();
    demo_async_block();
    demo_runtime_required();
    demo_what_tokio_does();
}

// ── 1단계: async fn 의 타입 ─────────────────────────────────────────
fn demo_async_fn_type() {
    println!("\n  ── 1단계: async fn → impl Future 반환 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  핵심: async fn 을 호출해도 실행되지 않는다                           │
// │                                                                     │
// │  async fn greet() -> &'static str { "안녕!" }                      │
// │                                                                     │
// │  let f = greet();  // 실행 안 됨! Future 구조체만 반환               │
// │  // f 의 타입: impl Future<Output = &'static str>                  │
// │  // f 를 실행하려면 executor 가 poll() 을 호출해야 함                 │
// └─────────────────────────────────────────────────────────────────────┘

    async fn greet(name: &str) -> String {
        format!("안녕, {}!", name)
    }

    // greet() 호출 — Future 구조체 반환 (실행 안 됨)
    let _future = greet("Simba");
    println!("  greet() 호출 → Future 구조체 반환됨 (아직 실행 안 됨)");
    println!("  타입: impl Future<Output = String>");
    println!();

    // std::future::Future 의 Output 타입 확인
    use std::future::Future;
    fn show_type<F: Future>(_f: F) {
        println!("  Future 구현체 생성됨 (Output = {})", std::any::type_name::<F::Output>());
    }
    show_type(greet("Donald"));
}

// ── 2단계: async 블록 ───────────────────────────────────────────────
fn demo_async_block() {
    println!("\n  ── 2단계: async 블록 — 인라인 Future ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  async 블록: async fn 없이 Future 생성                               │
// │                                                                     │
// │  let future = async {                                               │
// │      let x = 1;                                                     │
// │      let y = 2;                                                     │
// │      x + y   // 블록의 마지막 표현식이 Output                        │
// │  };                                                                 │
// │  // future: impl Future<Output = i32>                              │
// └─────────────────────────────────────────────────────────────────────┘

    // async 블록 생성
    let _compute = async {
        let x = 10;
        let y = 20;
        x + y
    };
    println!("  async 블록 생성 → Future<Output=i32>");
    println!("  아직 실행 안 됨 — poll() 호출 전까지");

    // async 블록에서 외부 변수 캡처
    let prefix = "동물원";
    let _announce = async move {
        format!("[{}] 개장!", prefix)
    };
    println!("  async move 블록 → prefix 소유권 이동");

    println!();
    println!("  async fn vs async 블록:");
    println!("    async fn → 이름 있는 Future 생성자");
    println!("    async {{ }} → 이름 없는 인라인 Future");
}

// ── 3단계: 왜 런타임이 필요한가 ─────────────────────────────────────
fn demo_runtime_required() {
    println!("\n  ── 3단계: 런타임이 필요한 이유 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  컴파일 에러 예시:                                                    │
// │                                                                     │
// │  async fn main() {    // ❌ 에러!                                   │
// │      greet("Simba").await;                                          │
// │  }                                                                  │
// │                                                                     │
// │  error[E0752]: `main` function is not allowed to be `async`        │
// │                                                                     │
// │  이유:                                                               │
// │    main() 은 프로그램 진입점                                          │
// │    async fn main() 은 Future 반환 → 아무도 poll() 안 함             │
// │    → 프로그램이 시작되자마자 아무것도 안 하고 종료                     │
// └─────────────────────────────────────────────────────────────────────┘

    println!("  async fn main() 은 컴파일 에러:");
    println!("    error[E0752]: main function is not allowed to be async");
    println!();
    println!("  이유:");
    println!("    async fn main() → Future 반환");
    println!("    아무도 poll() 안 함 → 실행 안 됨");
    println!();
    println!("  해결: 런타임이 main Future를 poll() 해줌");
    println!("    #[tokio::main]");
    println!("    async fn main() {{ ... }}");
    println!("    → tokio 런타임이 시작되고 main Future를 실행");
}

// ── 4단계: tokio 가 하는 일 ─────────────────────────────────────────
fn demo_what_tokio_does() {
    println!("\n  ── 4단계: 런타임(tokio)이 하는 일 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  tokio 런타임 구조 (간략):                                           │
// │                                                                     │
// │  ┌────────────────────────────────┐                                │
// │  │  tokio Executor                │                                │
// │  │                                │                                │
// │  │  태스크 큐: [Future1, Future2, ...] │                            │
// │  │                                │                                │
// │  │  루프: Future.poll()            │                                │
// │  │    Ready → 완료, 제거           │                                │
// │  │    Pending → 큐 뒤로, 다음 실행 │                                │
// │  └────────────────────────────────┘                                │
// │                                                                     │
// │  tokio::spawn → 태스크 큐에 추가                                     │
// │  .await → 현재 태스크 Pending, 다음 태스크 실행                      │
// └─────────────────────────────────────────────────────────────────────┘

    println!("  런타임의 핵심 역할:");
    println!("    1. 태스크 큐 관리 (어떤 Future를 언제 poll할지)");
    println!("    2. I/O 이벤트 감시 (epoll/kqueue)");
    println!("    3. Waker 를 통한 태스크 재활성화");
    println!("    4. 스레드 풀 관리 (multi-thread runtime)");
    println!();
    println!("  tokio 없이 async/await 요약:");
    println!("    async fn  → Future 생성 O  실행 X");
    println!("    .await    → 문법 O  실행 X (런타임 없으면)");
    println!("    실행       → #[tokio::main] 또는 block_on() 필요");
    println!();
    println!("  std 만으로는: futures::executor::block_on() 사용 가능");
    println!("    (futures 크레이트, tokio 없이 단순 실행)");
}
