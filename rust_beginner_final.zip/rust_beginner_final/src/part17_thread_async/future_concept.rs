// ┌─────────────────────────────────────────────────────────────────────┐
// │  Part 17-4: Future 개념                                             │
// │                                                                     │
// │  공식 문서: std::future::Future                                      │
// │            Rust Async Book Ch.2                                     │
// │                                                                     │
// │  학습 순서:                                                          │
// │    1단계: 동기 I/O의 문제 — 대기 중 CPU 낭비                         │
// │    2단계: Future trait 구조                                          │
// │    3단계: async fn 이 컴파일러가 변환하는 것                          │
// │    4단계: .await 가 하는 일                                          │
// │    5단계: std::future::Future 직접 구현                              │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Future trait (표준 라이브러리)                                       │
// │                                                                     │
// │  pub trait Future {                                                 │
// │      type Output;                                                   │
// │      fn poll(self: Pin<&mut Self>,                                  │
// │              cx: &mut Context) -> Poll<Self::Output>;               │
// │  }                                                                  │
// │                                                                     │
// │  Poll<T>:                                                           │
// │      Ready(T)  → 완료, 값 반환                                       │
// │      Pending   → 아직 준비 안 됨, Waker 등록                        │
// └─────────────────────────────────────────────────────────────────────┘

use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll, Waker};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

pub fn run() {
    println!("\n  [17-4: Future 개념]");
    demo_sync_problem();
    demo_future_trait();
    demo_async_transform();
    demo_await_meaning();
    demo_custom_future();
}

// ── 1단계: 동기 I/O의 문제 ─────────────────────────────────────────
fn demo_sync_problem() {
    println!("\n  ── 1단계: 동기 방식 — 대기 중 CPU 낭비 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  동기 방식:                                                          │
// │                                                                     │
// │  read_file()  → [파일 읽는 중... 대기] → 완료 → 다음 작업           │
// │                  ↑ 이 시간 동안 CPU는 아무것도 못 함                 │
// │                                                                     │
// │  비동기 방식:                                                        │
// │  read_file().await → [양보] → 다른 작업 실행 → I/O완료 → 재개       │
// └─────────────────────────────────────────────────────────────────────┘

    // 동기: 순차 실행 (각 작업이 완료될 때까지 대기)
    fn sync_fetch(name: &str, ms: u64) -> String {
        thread::sleep(Duration::from_millis(ms)); // I/O 대기 시뮬레이션
        format!("{}의 데이터", name)
    }

    let start = std::time::Instant::now();
    let r1 = sync_fetch("사자",  20);
    let r2 = sync_fetch("오리",  15);
    let r3 = sync_fetch("뱀",    18);
    println!("  동기 결과: {}, {}, {}", r1, r2, r3);
    println!("  소요: {}ms (20+15+18=53ms)", start.elapsed().as_millis());
    println!("  → 비동기라면 가장 긴 20ms만 걸림");
}

// ── 2단계: Future trait 구조 ────────────────────────────────────────
fn demo_future_trait() {
    println!("\n  ── 2단계: Future trait — poll() 기반 ──");

    println!("  Future trait 핵심:");
    println!("    poll() 호출 → Ready(값) 또는 Pending 반환");
    println!("    Pending 시  → Waker 등록, I/O 완료 시 wake() 호출");
    println!("    wake() 호출 → Executor가 다시 poll()");
    println!();
    println!("  Poll<T> 두 가지 상태:");
    println!("    Poll::Ready(v) → 완료, 값 v 반환");
    println!("    Poll::Pending  → 아직 준비 안 됨");
}

// ── 3단계: async fn 변환 ────────────────────────────────────────────
fn demo_async_transform() {
    println!("\n  ── 3단계: async fn → Future 상태 머신 변환 ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  작성한 코드:                                                        │
// │  async fn fetch(url: &str) -> String {                              │
// │      let data = read(url).await;  ← .await 지점 1                  │
// │      let parsed = parse(data).await;  ← .await 지점 2              │
// │      parsed                                                         │
// │  }                                                                  │
// │                                                                     │
// │  컴파일러 생성 (의사코드):                                            │
// │  fn fetch(url: &str) -> impl Future<Output=String> {               │
// │      FetchFuture { state: State0, url }  ← 상태 머신 구조체         │
// │  }                                                                  │
// │                                                                     │
// │  poll() 호출 시:                                                     │
// │    State0 → read 시작 → Pending 반환                                │
// │    State1 → read 완료 → parse 시작 → Pending 반환                   │
// │    State2 → parse 완료 → Ready(결과) 반환                           │
// └─────────────────────────────────────────────────────────────────────┘

    println!("  async fn 은 즉시 실행되지 않는다:");
    println!("    호출 → Future 구조체 반환 (설계도)");
    println!("    executor 가 poll() 호출 → 실제 실행");
    println!();
    println!("  .await 지점마다:");
    println!("    내부 Future가 Pending → 현재 Future도 Pending 반환 (양보)");
    println!("    내부 Future가 Ready  → 다음 .await 지점으로 진행");
}

// ── 4단계: .await 의 의미 ───────────────────────────────────────────
fn demo_await_meaning() {
    println!("\n  ── 4단계: .await — 협력적 양보(cooperative yield) ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  .await 의 동작:                                                     │
// │                                                                     │
// │  some_future.await 는 아래와 같다 (의사코드):                        │
// │                                                                     │
// │  loop {                                                             │
// │      match some_future.poll(cx) {                                   │
// │          Poll::Ready(v) => break v,    // 완료 → 값 꺼냄            │
// │          Poll::Pending  => yield,      // 미완료 → 양보             │
// │      }                                                              │
// │  }                                                                  │
// │                                                                     │
// │  yield: 현재 태스크를 멈추고 executor에게 제어권 반환                 │
// │         다른 태스크가 실행될 수 있음                                   │
// └─────────────────────────────────────────────────────────────────────┘

    println!("  .await 핵심:");
    println!("    Future가 Ready → 값을 꺼내서 계속 진행");
    println!("    Future가 Pending → 현재 태스크 멈춤, 다른 태스크 실행");
    println!("    → 스레드 블로킹 없이 대기 → CPU 효율적 사용");
    println!();
    println!("  스레드 sleep vs async sleep:");
    println!("    thread::sleep(1s) → 스레드 자체를 1초 블로킹");
    println!("    tokio::time::sleep(1s).await → 태스크만 양보, 스레드는 다른 일");
}

// ── 5단계: Future 직접 구현 ─────────────────────────────────────────
fn demo_custom_future() {
    println!("\n  ── 5단계: Future 직접 구현 (개념 이해용) ──");

// ┌─────────────────────────────────────────────────────────────────────┐
// │  DelayedValue: N번 poll 후 Ready 반환하는 Future                    │
// │                                                                     │
// │  poll() 1회차 → Pending (아직 준비 안 됨)                           │
// │  poll() 2회차 → Pending                                             │
// │  poll() 3회차 → Ready(42) (완료)                                    │
// └─────────────────────────────────────────────────────────────────────┘

    // 간단한 Future 직접 구현
    struct DelayedValue {
        polls_remaining: u32,
        value: i32,
        waker: Arc<Mutex<Option<Waker>>>,
    }

    impl Future for DelayedValue {
        type Output = i32;

        fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<i32> {
            if self.polls_remaining == 0 {
                Poll::Ready(self.value)
            } else {
                self.polls_remaining -= 1;
                // Waker 저장 (실제로는 I/O 완료 시 wake() 호출)
                *self.waker.lock().unwrap() = Some(cx.waker().clone());
                Poll::Pending
            }
        }
    }

    // 간단한 블로킹 executor — tokio 없이 Future 실행
    fn block_on<F: Future>(mut future: F) -> F::Output
where F::Output: std::fmt::Display {
        use std::task::{RawWaker, RawWakerVTable};

        // 아무것도 안 하는 Waker (예제용)
        fn noop(_: *const ()) {}
        fn noop_clone(p: *const ()) -> RawWaker { RawWaker::new(p, &VTABLE) }
        static VTABLE: RawWakerVTable = RawWakerVTable::new(
            noop_clone, noop, noop, noop
        );
        let raw_waker = RawWaker::new(std::ptr::null(), &VTABLE);
        let waker = unsafe { Waker::from_raw(raw_waker) };
        let mut cx = Context::from_waker(&waker);

        let mut pinned = unsafe { Pin::new_unchecked(&mut future) };
        let mut poll_count = 0;
        loop {
            poll_count += 1;
            match pinned.as_mut().poll(&mut cx) {
                Poll::Ready(v) => {
                    println!("  {}회 poll 후 Ready({})", poll_count, v);
                    return v;
                }
                Poll::Pending => {
                    println!("  {}회차 poll → Pending", poll_count);
                }
            }
        }
    }

    let waker_store = Arc::new(Mutex::new(None));
    let future = DelayedValue {
        polls_remaining: 2,
        value: 42,
        waker: Arc::clone(&waker_store),
    };

    let result = block_on(future);
    println!("  최종 결과: {}", result);
    println!("  → 실제 tokio는 이런 poll 루프를 효율적으로 관리함");
}
