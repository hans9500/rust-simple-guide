// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴13: &dyn Trait vs &impl Trait vs impl Trait (값)                  │
// │          Object Safety + RPIT (Return Position impl Trait)            │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Box<dyn Sound> 메모리 구조 ──────────────────────────────────────────
//
//  Box<dyn Sound> 는 스택에 fat pointer(16바이트)를 가진다:
//
//  스택 (Box<dyn Sound>, 16바이트)
//  ┌──────────────────┐
//  │ data_ptr (8바이트)──────────────▶ 힙: Lion { name_ptr, len, cap, age, hungry }
//  │ vtable_ptr(8바이트)─────────────▶ static: LION_SOUND_VTABLE {
//  └──────────────────┘                  size:        32,
//                                        align:       8,
//                                        drop_fn:     drop_in_place::<Lion>,
//                                        make_sound:  Lion::make_sound,
//                                        loud_sound:  Lion::loud_sound,
//                                      }
//
//  &dyn Sound (참조):
//  스택 (16바이트)
//  ┌──────────────────┐
//  │ data_ptr ────────┼──▶ 스택 or 힙의 실제 데이터
//  │ vtable_ptr ──────┼──▶ static VTABLE
//  └──────────────────┘
//
//  vs &Lion (일반 참조, 8바이트):
//  스택
//  ┌──────────────────┐
//  │ data_ptr ────────┼──▶ 스택의 Lion 데이터
//  └──────────────────┘

// ─── Object Safety (객체 안전성) ──────────────────────────────────────────
//
//  dyn Trait이 되려면 trait이 object-safe해야 한다.
//  vtable을 만들 수 없는 메서드가 있으면 object-safe 하지 않다.
//
//  ❌ object-safe 하지 않은 경우:
//  trait NotSafe {
//      fn clone_self(&self) -> Self;       // Self 반환 → 크기 불확정
//      fn compare<T>(&self, other: T);     // 제네릭 메서드 → vtable 생성 불가
//      fn new() -> Self;                   // self 없는 연관 함수
//  }
//  // &dyn NotSafe → 컴파일 에러
//
//  ✅ object-safe한 경우:
//  trait Sound {
//      fn make_sound(&self) -> String;     // &self, 구체 반환 → OK
//      fn loud_sound(&self);               // &self → OK
//  }

// ─── 단형화 의사코드 ──────────────────────────────────────────────────────
//
//  작성한 코드:
//    fn inspect_impl<T: Sound>(animal: &T) { animal.make_sound(); }
//
//  컴파일러가 생성하는 코드 (개념적):
//    fn inspect_impl__Lion(animal: *const Lion) {
//        Lion::make_sound(animal);   // 직접 연결, 인라인 가능
//    }
//    fn inspect_impl__Duck(animal: *const Duck) {
//        Duck::make_sound(animal);   // 직접 연결, 인라인 가능
//    }
//    // 런타임에 타입 확인 코드 없음

use crate::part2_patterns::animals::{Lion, Duck};
use crate::part2_patterns::pattern2_trait::Sound;

// 세 가지 인자 형태
fn inspect_dyn    (a: &dyn Sound)  { println!("    &dyn:      {}", a.make_sound()); }
fn inspect_ref_impl(a: &impl Sound) { println!("    &impl:     {}", a.make_sound()); }
fn inspect_val_impl(a: impl Sound)  { println!("    impl(값):  {}", a.make_sound()); }

// RPIT (Return Position impl Trait) — 반환 타입이 하나로 고정
fn make_one_animal() -> impl Sound {
    Lion::new("반환된 사자", 3)
    // 컴파일러 내부: 반환 타입 = Lion으로 고정
    // 호출자는 "impl Sound를 구현한 어떤 타입" 이라고만 알 수 있음
}

// 여러 타입을 반환하려면 Box<dyn>
fn make_dynamic(big: bool) -> Box<dyn Sound> {
    if big { Box::new(Lion::new("큰 동물", 5)) }
    else   { Box::new(Duck::new("작은 동물", 2)) }
    // Box<dyn Sound>: 힙에 동물 + vtable 포인터
}

pub fn run() {
    println!("\n─── 패턴13: 디스패치 완전 비교 ───");

    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);

    // &dyn — fat pointer(16B), 런타임 결정
    inspect_dyn(&simba);
    inspect_dyn(&donald);

    // &impl — 8바이트 참조, 컴파일 타임, 단형화
    inspect_ref_impl(&simba);
    inspect_ref_impl(&donald);

    // impl (값) — 소유권 이동, 컴파일 타임
    inspect_val_impl(Lion::new("복사본", 1));

    // Vec<&dyn> — 여러 타입 혼합 (dyn만 가능)
    let animals: Vec<&dyn Sound> = vec![&simba, &donald];
    println!("    Vec<&dyn>:");
    for a in &animals { println!("      {}", a.make_sound()); }

    // RPIT — impl 반환
    let a = make_one_animal();
    println!("    RPIT: {}", a.make_sound());

    // Box<dyn> — 런타임 분기 반환
    println!("    Box<dyn>(big=true):  {}", make_dynamic(true).make_sound());
    println!("    Box<dyn>(big=false): {}", make_dynamic(false).make_sound());
}
