// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 4 심화.  디스패치 고급 — fat pointer 실측, 실수 패턴              │
// └───────────────────────────────────────────────────────────────────────┘

use std::mem;
use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;

// ─── 심화 1: fat pointer 크기 실측 ────────────────────────────────────────
//
//  64비트 시스템 기준:
//    일반 참조 &T     = 8바이트  (data_ptr 하나)
//    fat pointer      = 16바이트 (data_ptr + vtable_ptr)
//
//  fat pointer가 생성되는 타입들:
//    &dyn Trait       — 가장 흔한 경우
//    &mut dyn Trait
//    Box<dyn Trait>
//    &[T]             — 슬라이스도 fat pointer (ptr + len)
//    &str             — 문자열 슬라이스 (ptr + len)
//
//  ─── 슬라이스 fat pointer 도식 ───────────────────────────────────────
//
//  &[Lion] (16바이트):
//  ┌──────────────────┐
//  │  data_ptr (8B) ──┼──▶ [Lion0, Lion1, Lion2, ...]
//  │  len      (8B)   │    연속된 메모리
//  └──────────────────┘
//
//  &str (16바이트):
//  ┌──────────────────┐
//  │  data_ptr (8B) ──┼──▶ UTF-8 바이트들
//  │  len      (8B)   │
//  └──────────────────┘
//
//  &dyn Sound (16바이트):
//  ┌──────────────────┐
//  │  data_ptr (8B) ──┼──▶ Lion 데이터
//  │  vtable_ptr(8B)──┼──▶ LION_SOUND_VTABLE
//  └──────────────────┘
//
//  공통점: 두 포인터 = 16바이트
//  차이점: len vs vtable_ptr — 용도가 다름

fn demo_fat_pointer_sizes() {
    println!("\n  [심화1: fat pointer 크기 실측]");

    // 일반 참조
    println!("  &Lion:           {} bytes", mem::size_of::<&Lion>());
    println!("  &mut Lion:       {} bytes", mem::size_of::<&mut Lion>());

    // fat pointer — dyn trait
    println!("  &dyn Sound:      {} bytes", mem::size_of::<&dyn Sound>());
    println!("  &mut dyn Sound:  {} bytes", mem::size_of::<&mut dyn Sound>());
    println!("  Box<dyn Sound>:  {} bytes", mem::size_of::<Box<dyn Sound>>());

    // fat pointer — 슬라이스
    println!("  &[Lion]:         {} bytes", mem::size_of::<&[Lion]>());
    println!("  &str:            {} bytes", mem::size_of::<&str>());

    // struct 크기
    println!("\n  [struct 크기]");
    println!("  Lion:   {} bytes", mem::size_of::<Lion>());
    println!("  Duck:   {} bytes", mem::size_of::<Duck>());
    println!("  Snake:  {} bytes", mem::size_of::<Snake>());

    // Option NPO (Null Pointer Optimization)
    println!("\n  [Null Pointer Optimization]");
    println!("  Box<Lion>:         {} bytes", mem::size_of::<Box<Lion>>());
    println!("  Option<Box<Lion>>: {} bytes", mem::size_of::<Option<Box<Lion>>>());
    // 같은 크기 — None = null pointer

    println!("  &Lion:             {} bytes", mem::size_of::<&Lion>());
    println!("  Option<&Lion>:     {} bytes", mem::size_of::<Option<&Lion>>());
    // 같은 크기 — None = null reference
}

// ─── 심화 2: &dyn Trait의 숨겨진 라이프타임 ──────────────────────────────
//
//  fn f(x: &dyn Sound)
//  실제: fn f<'a>(x: &'a dyn Sound)
//  또는: fn f(x: &'_ dyn Sound)    ('_ : 추론된 수명)
//
//  &dyn Sound + 'static:
//    trait object가 'static 라이프타임을 가져야 할 때
//    fn f(x: Box<dyn Sound + 'static>)  → 안에 빌린 참조가 없어야 함
//    fn f(x: Box<dyn Sound>)            → 묵시적으로 + 'static (Box의 기본)
//    fn f(x: &dyn Sound)                → 묵시적으로 + '_ (참조의 수명)
//
//  Box<dyn Sound> vs &dyn Sound 라이프타임 차이:
//
//  fn use_box(s: Box<dyn Sound>) { ... }
//    → s의 데이터를 Box가 소유 → 라이프타임 제약 없음
//
//  fn use_ref(s: &dyn Sound) { ... }
//    → s는 빌림 → s가 가리키는 데이터가 살아있어야 함

fn use_box_dyn(s: Box<dyn Sound>) {
    println!("    Box<dyn> 소유: {}", s.make_sound());
}
fn use_ref_dyn<'a>(s: &'a dyn Sound) {
    println!("    &dyn 빌림: {}", s.make_sound());
}

fn demo_dyn_lifetime() {
    println!("\n  [심화2: &dyn Trait의 숨겨진 라이프타임]");

    // Box<dyn Sound> — 소유권 있음, 라이프타임 제약 없음
    let boxed: Box<dyn Sound> = Box::new(Lion::new("Simba", 5));
    use_box_dyn(boxed);

    // &dyn Sound — 빌림, 원본 수명에 묶임
    let lion = Lion::new("Nala", 4);
    use_ref_dyn(&lion);
    println!("  원본 여전히 유효: {}", lion.name());

    // Box<dyn Sound + 'static> vs Box<dyn Sound + '_>
    // 함수가 반환하는 Box<dyn Sound>는 'static이어야 함이 기본
    fn make_animal() -> Box<dyn Sound> {  // 묵시적 + 'static
        Box::new(Duck::new("Donald", 3))  // Duck은 소유 → 'static 충족
    }
    let a = make_animal();
    println!("  make_animal: {}", a.make_sound());
}

// ─── 심화 3: impl Trait 반환의 한계와 해결책 ─────────────────────────────
//
//  impl Trait 반환의 핵심 제약:
//    "반환 타입이 하나의 구체 타입으로 고정되어야 한다."
//
//  실수 패턴:
//  fn make_animal(is_lion: bool) -> impl Sound {
//      if is_lion {
//          Lion::new("Simba", 5)       // Lion
//      } else {
//          Duck::new("Donald", 3)      // Duck ← 에러!
//      }
//  }
//  // 에러: if and else have incompatible types
//  // note: expected `Lion`, found `Duck`
//
//  이유:
//    impl Sound는 "하나의 고정된 타입"을 의미한다.
//    컴파일러가 컴파일 타임에 반환 타입을 알아야 한다.
//    Lion과 Duck은 다른 타입 → 컴파일러가 하나를 선택할 수 없음.
//
//  해결책 1: Box<dyn Sound>
//    fn make_animal(is_lion: bool) -> Box<dyn Sound> {
//        if is_lion { Box::new(Lion::...) }
//        else       { Box::new(Duck::...) }
//    }
//    → 힙 할당 필요. 런타임 결정.
//
//  해결책 2: enum으로 감싸기 (힙 할당 없음)
//    enum Animal { Lion(Lion), Duck(Duck) }
//    impl Sound for Animal { ... }
//    fn make_animal(is_lion: bool) -> Animal { ... }

enum AnyAnimal {
    Lion(Lion),
    Duck(Duck),
    Snake(Snake),
}

impl Sound for AnyAnimal {
    fn make_sound(&self) -> String {
        match self {
            AnyAnimal::Lion(l)  => l.make_sound(),
            AnyAnimal::Duck(d)  => d.make_sound(),
            AnyAnimal::Snake(s) => s.make_sound(),
        }
    }
}

// impl Trait 반환 — 타입 고정
fn make_lion_impl() -> impl Sound {
    Lion::new("고정된 사자", 3)
}

// Box<dyn> 반환 — 런타임 분기
fn make_animal_dyn(kind: &str) -> Box<dyn Sound> {
    match kind {
        "lion"  => Box::new(Lion::new("Simba", 5)),
        "duck"  => Box::new(Duck::new("Donald", 3)),
        _       => Box::new(Snake::new("Kaa", 5, false)),
    }
}

// enum 반환 — 힙 할당 없음, 런타임 분기
fn make_animal_enum(kind: &str) -> AnyAnimal {
    match kind {
        "lion" => AnyAnimal::Lion(Lion::new("Simba", 5)),
        "duck" => AnyAnimal::Duck(Duck::new("Donald", 3)),
        _      => AnyAnimal::Snake(Snake::new("Kaa", 5, false)),
    }
}

fn demo_impl_trait_limits() {
    println!("\n  [심화3: impl Trait 반환 한계와 해결책]");

    // impl Trait — 타입 고정
    let a = make_lion_impl();
    println!("  impl Trait: {}", a.make_sound());

    // Box<dyn> — 런타임 분기, 힙 할당
    for kind in &["lion", "duck", "snake"] {
        let a = make_animal_dyn(kind);
        println!("  Box<dyn> [{}]: {}", kind, a.make_sound());
    }

    // enum — 런타임 분기, 힙 할당 없음
    for kind in &["lion", "duck", "snake"] {
        let a = make_animal_enum(kind);
        println!("  enum [{}]: {}", kind, a.make_sound());
    }

    println!("\n  [impl Trait vs Box<dyn> vs enum 비교]");
    println!("  impl Trait : 타입 고정, 힙 불필요, 인라인 가능, 단일 타입만");
    println!("  Box<dyn>   : 런타임 분기, 힙 필요, vtable 조회, 여러 타입");
    println!("  enum       : 런타임 분기, 힙 불필요, match 필요, 타입 미리 열거");
}

// ─── 심화 4: 단형화 코드 팽창(code bloat) 방지 ───────────────────────────
//
//  제네릭 함수를 많이 쓰면 바이너리 크기가 커질 수 있다.
//  실제 전략: 제네릭 래퍼 + 내부 dyn 구현
//
//  fn process<T: Sound>(animals: &[T]) {   // T마다 별도 코드 생성
//      inner_process(animals as &[&dyn Sound])  // 하나의 구현으로 위임
//  }
//
//  이 패턴은 표준 라이브러리에서도 사용된다.

fn inner_process(animals: &[&dyn Sound]) {  // 하나의 구현
    for a in animals {
        print!("  {} | ", a.make_sound());
    }
    println!();
}

fn process<T: Sound>(animals: &[T]) {        // 제네릭 래퍼
    let refs: Vec<&dyn Sound> = animals.iter().map(|a| a as &dyn Sound).collect();
    inner_process(&refs);
}

fn demo_code_bloat() {
    println!("\n  [심화4: 코드 팽창 방지 패턴]");

    let lions = vec![Lion::new("Simba", 5), Lion::new("Nala", 4)];
    let ducks = vec![Duck::new("Donald", 3)];

    print!("  Lions: ");
    process(&lions);    // 타입별로 단형화 (얇은 래퍼)

    print!("  Ducks: ");
    process(&ducks);    // inner_process는 하나만 존재
}

pub fn run() {
    println!("\n══════ Part 4 심화: 디스패치 고급 ══════");
    demo_fat_pointer_sizes();
    demo_dyn_lifetime();
    demo_impl_trait_limits();
    demo_code_bloat();
}
