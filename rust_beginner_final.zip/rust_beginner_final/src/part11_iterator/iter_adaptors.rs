// ┌─────────────────────────────────────────────────────────────────────┐
// │  Iterator 어댑터 체이닝 흐름 (지연 평가)                             │
// │                                                                     │
// │  vec![1,2,3,4,5]                                                    │
// │    .iter()           ← IntoIterator                                 │
// │    .filter(|x| x>2)  ← Filter<Iter> 생성 (아직 실행 안 됨)          │
// │    .map(|x| x*10)    ← Map<Filter<Iter>> 생성 (아직 실행 안 됨)     │
// │    .collect()        ← 여기서 실제 실행! → [30, 40, 50]             │
// │                                                                     │
// │  어댑터 종류:                                                        │
// │    변환:  map, flat_map, flatten                                     │
// │    필터:  filter, take, skip, take_while, skip_while                │
// │    조합:  chain, zip, enumerate, peekable                           │
// │    중복:  cloned, copied                                            │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 11-2: Iterator 어댑터
// │
// │ 어댑터: Iterator를 받아 다른 Iterator를 반환 (지연 평가)
// │   map, filter, flat_map, chain, zip, take, skip,
// │   enumerate, peekable, flatten, take_while, skip_while
// │
// │ 핵심: 어댑터는 실제로 연산하지 않는다.
// │       소비자(collect, sum, for_each 등)가 호출될 때 실행된다.
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [11-2: Iterator 어댑터]");
    demo_map_filter();
    demo_flat_map();
    demo_chain_zip();
    demo_take_skip();
    demo_chaining();
}

fn demo_map_filter() {
    println!("\n  ── map / filter ──");

    let animals = vec![
        ("Simba",  "사자", 5u32),
        ("Donald", "오리", 3),
        ("Nagini", "뱀",   8),
        ("Dumbo",  "코끼리", 10),
    ];

    // map: 각 요소 변환
    let names: Vec<&str> = animals.iter()
        .map(|(name, _, _)| *name)
        .collect();
    println!("  이름만: {:?}", names);

    // filter: 조건 만족하는 요소만
    let adults: Vec<&str> = animals.iter()
        .filter(|(_, _, age)| *age >= 5)
        .map(|(name, _, _)| *name)
        .collect();
    println!("  5살 이상: {:?}", adults);

    // filter_map: filter + map 동시 (None 제거)
    let parsed: Vec<u32> = vec!["1", "두", "3", "넷", "5"]
        .iter()
        .filter_map(|s| s.parse::<u32>().ok())
        .collect();
    println!("  파싱 성공: {:?}", parsed);
}

fn demo_flat_map() {
    println!("\n  ── flat_map / flatten ──");

    // flat_map: map 후 1단계 평탄화
    let zoo_groups = vec![
        vec!["사자", "호랑이"],
        vec!["오리", "독수리"],
        vec!["뱀", "도마뱀"],
    ];

    // flatten: 중첩 제거
    let all_animals: Vec<&&str> = zoo_groups.iter()
        .flatten()
        .collect();
    println!("  flatten: {:?}", all_animals);

    // flat_map: 각 요소를 이터레이터로 변환 후 평탄화
    let sentences = vec!["사자 Simba", "오리 Donald"];
    let words: Vec<&str> = sentences.iter()
        .flat_map(|s| s.split_whitespace())
        .collect();
    println!("  flat_map 단어: {:?}", words);

    // 실전: 각 동물의 서식지 목록 펼치기
    let habitats = vec![
        ("사자", vec!["초원", "사바나"]),
        ("오리", vec!["연못", "강", "바다"]),
        ("뱀",   vec!["숲", "사막"]),
    ];
    let all_habitats: Vec<&str> = habitats.iter()
        .flat_map(|(_, places)| places.iter().copied())
        .collect();
    println!("  모든 서식지: {:?}", all_habitats);
}

fn demo_chain_zip() {
    println!("\n  ── chain / zip ──");

    let zoo1 = vec!["사자", "오리"];
    let zoo2 = vec!["뱀", "코끼리", "기린"];

    // chain: 두 이터레이터 연결
    let combined: Vec<&&str> = zoo1.iter().chain(zoo2.iter()).collect();
    println!("  chain: {:?}", combined);

    // zip: 두 이터레이터를 쌍으로
    let names = ["Simba", "Donald", "Nagini"];
    let ages  = [5u32, 3, 8, 10];  // 더 길어도 짧은 쪽 기준
    let paired: Vec<(&&str, &u32)> = names.iter().zip(ages.iter()).collect();
    println!("  zip: {:?}", paired);

    // unzip: zip의 역
    let (ns, as2): (Vec<&&str>, Vec<&u32>) = names.iter().zip(ages.iter()).unzip();
    println!("  unzip 이름: {:?}", ns);
    println!("  unzip 나이: {:?}", as2);
}

fn demo_take_skip() {
    println!("\n  ── take / skip / take_while / skip_while ──");

    let nums: Vec<u32> = (1..=10).collect();
    println!("  원본: {:?}", nums);

    // take: 앞에서 N개
    let first3: Vec<&u32> = nums.iter().take(3).collect();
    println!("  take(3): {:?}", first3);

    // skip: 앞에서 N개 건너뜀
    let after3: Vec<&u32> = nums.iter().skip(3).collect();
    println!("  skip(3): {:?}", after3);

    // take_while: 조건이 참인 동안
    let while_lt5: Vec<&u32> = nums.iter().take_while(|&&x| x < 5).collect();
    println!("  take_while(<5): {:?}", while_lt5);

    // skip_while: 조건이 참인 동안 건너뜀
    let after_lt5: Vec<&u32> = nums.iter().skip_while(|&&x| x < 5).collect();
    println!("  skip_while(<5): {:?}", after_lt5);
}

fn demo_chaining() {
    println!("\n  ── 어댑터 체이닝 실전 ──");

    // 동물원 데이터 처리 파이프라인
    let animals = vec![
        ("Simba",   "사자",   5u32,  190.0f64, true),
        ("Donald",  "오리",   3,     2.5,      true),
        ("Nagini",  "뱀",     8,     15.0,     false),
        ("Dumbo",   "코끼리", 10,    4000.0,   true),
        ("Giraffe", "기린",   6,     800.0,    true),
        ("Cobra",   "코브라", 4,     5.0,      false),
    ];
    // (이름, 종, 나이, 체중kg, 전시중)

    // 전시 중인 5살 이상 동물의 이름을 알파벳 순으로
    let mut display: Vec<&str> = animals.iter()
        .filter(|(_, _, age, _, display)| *display && *age >= 5)
        .map(|(name, _, _, _, _)| *name)
        .collect();
    display.sort();
    println!("  전시중 성체 동물(정렬): {:?}", display);

    // 전체 체중 합계 (전시 중인 것만)
    let total_weight: f64 = animals.iter()
        .filter(|(_, _, _, _, d)| *d)
        .map(|(_, _, _, w, _)| w)
        .sum();
    println!("  전시 동물 총 체중: {:.1}kg", total_weight);

    // 종별 최고령
    use std::collections::HashMap;
    let oldest_by_species: HashMap<&str, u32> = animals.iter()
        .fold(HashMap::new(), |mut map, (_, species, age, _, _)| {
            let entry = map.entry(species).or_insert(0);
            if *age > *entry { *entry = *age; }
            map
        });
    let mut species_list: Vec<(&&str, &u32)> = oldest_by_species.iter().collect();
    species_list.sort_by_key(|(s, _)| **s);
    println!("  종별 최고령:");
    for (species, age) in &species_list {
        println!("    {} → {}살", species, age);
    }
}
