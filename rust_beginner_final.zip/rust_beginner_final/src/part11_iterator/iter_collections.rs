// ┌──────────────────────────────────────────────────────────────────
// │ Part 11 보강: VecDeque / mem::swap / mem::replace
// │
// │ 공식 문서: std::collections::VecDeque, std::mem
// │
// │ VecDeque: 양방향 큐(Deque = Double-Ended Queue)
// │   앞/뒤 모두 O(1) 삽입/삭제
// │   Vec: 앞 삽입/삭제 O(n) — 모든 요소 이동 필요
// │
// │ mem::swap: 소유권 이동 없이 두 값 교환
// │ mem::replace: 값 교체 후 이전 값 반환
// └──────────────────────────────────────────────────────────────────

use std::collections::VecDeque;
use std::mem;

pub fn run() {
    println!("\n  [Part 11 보강: VecDeque / mem::swap / mem::replace]");
    demo_vecdeque();
    demo_vecdeque_as_queue();
    demo_mem_swap();
    demo_mem_replace();
}

fn demo_vecdeque() {
    println!("\n  ── VecDeque 기본 ──");

    let mut deque: VecDeque<&str> = VecDeque::new();

    // 뒤에 추가 (push_back) — Vec과 동일
    deque.push_back("오리");
    deque.push_back("뱀");

    // 앞에 추가 (push_front) — Vec은 O(n), VecDeque는 O(1)
    deque.push_front("사자");
    deque.push_front("코끼리");

    println!("  deque: {:?}", deque);

    // 앞에서 꺼내기 (pop_front)
    println!("  pop_front: {:?}", deque.pop_front());
    println!("  pop_back:  {:?}", deque.pop_back());
    println!("  남은 것:   {:?}", deque);

    // 인덱스 접근 — Vec처럼 가능
    let mut d: VecDeque<u32> = VecDeque::from(vec![1, 2, 3, 4, 5]);
    d[2] = 99;
    println!("  인덱스 수정: {:?}", d);

    // Vec ↔ VecDeque 변환
    let v: Vec<u32> = d.into_iter().collect();
    let d2: VecDeque<u32> = v.into();
    println!("  Vec → VecDeque: {:?}", d2);
}

fn demo_vecdeque_as_queue() {
    println!("\n  ── VecDeque: 큐 / 슬라이딩 윈도우 ──");

    // FIFO 큐 — 동물 입장 대기열
    let mut queue: VecDeque<(&str, u32)> = VecDeque::new();

    // 입장 대기 (뒤에 추가)
    for (name, ticket) in [("Simba", 1), ("Donald", 2), ("Nagini", 3)] {
        queue.push_back((name, ticket));
        println!("  대기 추가: {} (티켓 {})", name, ticket);
    }

    // 입장 처리 (앞에서 꺼내기)
    println!("  입장 처리:");
    while let Some((name, ticket)) = queue.pop_front() {
        println!("    {} 입장 (티켓 {})", name, ticket);
    }

    // 슬라이딩 윈도우 — 최근 N개만 유지
    let max_size = 3usize;
    let mut window: VecDeque<u32> = VecDeque::with_capacity(max_size);
    let data = vec![10u32, 20, 30, 40, 50, 60];

    println!("  슬라이딩 윈도우(크기 {}):", max_size);
    for &val in &data {
        if window.len() == max_size {
            window.pop_front();  // 오래된 것 제거
        }
        window.push_back(val);
        let avg = window.iter().sum::<u32>() as f64 / window.len() as f64;
        println!("    {:?} → 평균: {:.1}", window, avg);
    }
}

fn demo_mem_swap() {
    println!("\n  ── mem::swap ──");

    // swap: 소유권 이동 없이 두 변수 값 교환
    let mut a = String::from("사자");
    let mut b = String::from("오리");
    println!("  교환 전: a={}, b={}", a, b);

    mem::swap(&mut a, &mut b);
    println!("  교환 후: a={}, b={}", a, b);

    // Vec 정렬에서 swap
    let mut ages = vec![5u32, 3, 8, 1, 10];
    // 버블 정렬 (swap 사용)
    let n = ages.len();
    for i in 0..n {
        for j in 0..n-1-i {
            if ages[j] > ages[j+1] {
                ages.swap(j, j+1);  // Vec::swap (내부적으로 mem::swap)
            }
        }
    }
    println!("  정렬 후: {:?}", ages);

    // 구조체 필드 swap — 소유권 규칙상 직접 못 하지만 mem::swap으로 가능
    let mut zoo1 = vec!["사자".to_string(), "오리".to_string()];
    let mut zoo2 = vec!["뱀".to_string(), "코끼리".to_string()];
    mem::swap(&mut zoo1, &mut zoo2);
    println!("  zoo1: {:?}", zoo1);
    println!("  zoo2: {:?}", zoo2);
}

fn demo_mem_replace() {
    println!("\n  ── mem::replace ──");

    // replace: 새 값으로 교체하고 이전 값 반환
    let mut name = String::from("Simba");
    let old = mem::replace(&mut name, String::from("Mufasa"));
    println!("  교체 전: {}", old);
    println!("  교체 후: {}", name);

    // 실전: 구조체 필드에서 소유권 이동
    // self.field 를 move out 하면서 기본값으로 교체
    struct Animal {
        name: String,
        data: Vec<u32>,
    }

    impl Animal {
        fn new(name: &str) -> Self {
            Animal { name: name.to_string(), data: vec![1, 2, 3] }
        }

        pub fn take_data(&mut self) -> Vec<u32> {
            mem::replace(&mut self.data, Vec::new())
            // 또는: std::mem::take(&mut self.data)  — Default로 교체
        }
    }

    let mut animal = Animal::new("Simba");
    println!("  동물 이름: {}", animal.name);  // name 사용
    let data = animal.take_data();
    println!("  꺼낸 data: {:?}", data);
    println!("  animal.data 이후: {:?}", animal.data);  // 빈 Vec

    // mem::take: Default로 교체 (replace의 간편 버전)
    let mut scores = vec![95u32, 87, 76];
    let taken = mem::take(&mut scores);  // Vec::new()로 교체
    println!("  take: {:?}", taken);
    println!("  원본: {:?}", scores);  // []

    println!("\n  ── 컬렉션 선택 가이드 ──");
    println!("  Vec<T>:      인덱스 접근, 뒤 삽입/삭제 → 범용");
    println!("  VecDeque<T>: 앞/뒤 삽입/삭제 → 큐, 슬라이딩 윈도우");
    println!("  HashMap<K,V>: 키-값, 빠른 조회 → 빈도수, 캐시");
    println!("  BTreeMap<K,V>: 정렬된 키-값 → 범위 쿼리");
    println!("  HashSet<T>:  중복 제거, 집합 연산");
}
