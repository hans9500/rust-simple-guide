// ┌──────────────────────────────────────────────────────────────────
// │ Part 11: Iterator 심화
// │
// │ 공식 문서: Rust Book Ch.13.2, std::iter
// └──────────────────────────────────────────────────────────────────

pub mod iter_basic;
pub mod iter_adaptors;
pub mod iter_consumers;
pub mod iter_custom;
pub mod iter_collections;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 11: Iterator 심화");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    iter_basic::run();
    iter_adaptors::run();
    iter_consumers::run();
    iter_custom::run();
    iter_collections::run();
}
