// ┌─────────────────────────────────────────────────────────────────────┐
// │  소비자(Consumer) — Iterator를 소진해서 값 생성                      │
// │                                                                     │
// │  iter ──▶ collect()   → Vec, HashMap 등                             │
// │  iter ──▶ sum()       → 합계                                        │
// │  iter ──▶ count()     → 개수                                        │
// │  iter ──▶ fold(init, f) → 누적값                                    │
// │  iter ──▶ for_each(f) → 부수효과만 (반환 없음)                       │
// │  iter ──▶ find(pred)  → Option<T>                                  │
// │  iter ──▶ any(pred)   → bool                                        │
// │  iter ──▶ all(pred)   → bool                                        │
// │                                                                     │
// │  fold 동작:                                                         │
// │    fold(0, |acc, x| acc + x)                                        │
// │    0 → acc+1=1 → acc+2=3 → acc+3=6  (합계)                         │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 11-3: Iterator 소비자(Consumers)
// │
// │ 소비자: Iterator를 소비하고 최종 값을 반환
// │   collect, sum, product, fold, reduce,
// │   count, min, max, any, all, find, position,
// │   for_each, partition, unzip
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [11-3: Iterator 소비자]");
    demo_collect();
    demo_fold_reduce();
    demo_search();
    demo_partition();
}

fn demo_collect() {
    println!("\n  ── collect ──");

    let names = vec!["Simba", "Donald", "Nagini"];

    // Vec로 수집
    let upper: Vec<String> = names.iter()
        .map(|s| s.to_uppercase())
        .collect();
    println!("  Vec<String>: {:?}", upper);

    // HashMap으로 수집
    use std::collections::HashMap;
    let name_len: HashMap<&str, usize> = names.iter()
        .map(|&name| (name, name.len()))
        .collect();
    println!("  HashMap: {:?}", name_len);

    // HashSet으로 수집 (중복 제거)
    use std::collections::HashSet;
    let species = vec!["사자", "오리", "사자", "뱀", "오리"];
    let unique: HashSet<&&str> = species.iter().collect();
    let mut sorted: Vec<_> = unique.iter().collect();
    sorted.sort();
    println!("  HashSet(중복제거): {:?}", sorted);

    // String으로 수집
    let words = vec!["동물", "원", "에", "오세요"];
    let sentence: String = words.into_iter().collect();
    println!("  String: {}", sentence);

    // sum / product
    let ages = vec![5u32, 3, 8, 10, 6];
    let total: u32 = ages.iter().sum();
    let product: u32 = ages.iter().take(3).product();
    println!("  sum: {}, product(앞3): {}", total, product);
}

fn demo_fold_reduce() {
    println!("\n  ── fold / reduce ──");

    let weights = vec![190.0f64, 2.5, 15.0, 4000.0, 800.0];

    // fold: 초기값 있음, 모든 타입 가능
    let total = weights.iter().fold(0.0f64, |acc, &w| acc + w);
    println!("  fold 총합: {:.1}", total);

    // reduce: 초기값 없음, 빈 이터레이터면 None
    let max = weights.iter().copied().reduce(f64::max);
    println!("  reduce 최대: {:?}", max);

    // fold로 복잡한 집계
    let animals = vec![
        ("Simba",   5u32,  190.0f64),
        ("Donald",  3,     2.5),
        ("Nagini",  8,     15.0),
        ("Dumbo",   10,    4000.0),
    ];

    // fold로 통계 계산
    let (count, total_age, total_weight) = animals.iter()
        .fold((0u32, 0u32, 0.0f64), |(cnt, age, w), (_, a, wt)| {
            (cnt + 1, age + a, w + wt)
        });
    println!("  count={}, 평균나이={:.1}, 평균체중={:.1}kg",
        count,
        total_age as f64 / count as f64,
        total_weight / count as f64
    );

    // scan: fold의 중간값도 산출하는 버전
    let running_total: Vec<u32> = vec![1u32, 2, 3, 4, 5]
        .iter()
        .scan(0u32, |acc, &x| {
            *acc += x;
            Some(*acc)
        })
        .collect();
    println!("  누적합: {:?}", running_total);
}

fn demo_search() {
    println!("\n  ── any / all / find / position / count ──");

    let ages = vec![5u32, 3, 8, 10, 6, 2];

    // any: 하나라도 조건 만족
    let has_senior = ages.iter().any(|&a| a >= 10);
    println!("  10살 이상 있음: {}", has_senior);

    // all: 모두 조건 만족
    let all_adult = ages.iter().all(|&a| a >= 5);
    println!("  모두 5살 이상: {}", all_adult);

    // count: 조건 만족 개수
    let adult_count = ages.iter().filter(|&&a| a >= 5).count();
    println!("  5살 이상 수: {}", adult_count);

    // find: 첫 번째 만족 요소
    let first_senior = ages.iter().find(|&&a| a >= 8);
    println!("  첫 8살 이상: {:?}", first_senior);

    // position: 첫 번째 만족 인덱스
    let pos = ages.iter().position(|&a| a >= 8);
    println!("  첫 8살 이상 위치: {:?}", pos);

    // min / max
    println!("  min: {:?}, max: {:?}", ages.iter().min(), ages.iter().max());

    // min_by_key / max_by_key
    let animals = vec![("Simba", 190.0f64), ("Donald", 2.5), ("Dumbo", 4000.0)];
    let lightest = animals.iter().min_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
    let heaviest = animals.iter().max_by(|a, b| a.1.partial_cmp(&b.1).unwrap());
    println!("  가장 가벼움: {:?}", lightest);
    println!("  가장 무거움: {:?}", heaviest);
}

fn demo_partition() {
    println!("\n  ── partition / unzip ──");

    let ages = vec![5u32, 3, 8, 10, 6, 2, 7];

    // partition: 조건에 따라 두 Vec으로 분리
    let (adults, juveniles): (Vec<u32>, Vec<u32>) =
        ages.iter().partition(|&&a| a >= 5);
    println!("  성체(5↑): {:?}", adults);
    println!("  새끼(5↓): {:?}", juveniles);

    // unzip: 쌍의 이터레이터를 두 Vec으로 분리
    let pairs = vec![("Simba", 5u32), ("Donald", 3), ("Nagini", 8)];
    let (names, age_list): (Vec<&str>, Vec<u32>) = pairs.into_iter().unzip();
    println!("  이름: {:?}", names);
    println!("  나이: {:?}", age_list);

    // for_each: 각 요소에 부작용(side effect)
    println!("  for_each 출력:");
    vec!["사자", "오리", "뱀"]
        .iter()
        .enumerate()
        .for_each(|(i, name)| println!("    {}. {}", i + 1, name));
}
