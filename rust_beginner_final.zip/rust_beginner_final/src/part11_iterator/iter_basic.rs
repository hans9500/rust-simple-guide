// ┌─────────────────────────────────────────────────────────────────────┐
// │  Iterator 트레이트 구조                                              │
// │                                                                     │
// │  trait Iterator {                                                   │
// │      type Item;                          ← 연관 타입                │
// │      fn next(&mut self) -> Option<Item>; ← 핵심 메서드              │
// │  }                                                                  │
// │                                                                     │
// │  동작 흐름:                                                          │
// │  vec![1,2,3].iter()                                                 │
// │       │                                                             │
// │       ▼                                                             │
// │  [next()] → Some(&1)                                                │
// │  [next()] → Some(&2)                                                │
// │  [next()] → Some(&3)                                                │
// │  [next()] → None  ← 소진                                           │
// │                                                                     │
// │  iter()      → &T  (불변 참조)                                      │
// │  iter_mut()  → &mut T (가변 참조)                                   │
// │  into_iter() → T   (소유권 이동)                                    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 11-1: Iterator 기초
// │
// │ 공식 문서: std::iter::Iterator trait
// │
// │ Iterator trait:
// │   trait Iterator {
// │       type Item;
// │       fn next(&mut self) -> Option<Self::Item>;
// │       // 나머지 메서드는 next()를 기반으로 기본 구현됨
// │   }
// │
// │ 세 가지 이터레이터 생성:
// │   iter()      → &T     (불변 참조)
// │   iter_mut()  → &mut T (가변 참조)
// │   into_iter() → T      (소유권 이동)
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [11-1: Iterator 기초]");
    demo_three_iterators();
    demo_next();
    demo_for_loop();
}

fn demo_three_iterators() {
    println!("\n  ── iter / iter_mut / into_iter ──");

    let animals = vec!["사자", "오리", "뱀"];

    // iter(): &T — 원본 유지
    let upper: Vec<String> = animals.iter()
        .map(|s| s.to_uppercase())
        .collect();
    println!("  iter() 후 원본 유효: {:?}", animals);
    println!("  대문자: {:?}", upper);

    // iter_mut(): &mut T — 원본 수정
    let mut weights = vec![190.0f64, 2.5, 15.0];
    weights.iter_mut().for_each(|w| *w *= 1.1);  // 10% 증가
    println!("  iter_mut() 체중 +10%%: {:?}", weights);

    // into_iter(): T — 소유권 이동, 원본 소비
    let names = vec![
        String::from("Simba"),
        String::from("Donald"),
        String::from("Nagini"),
    ];
    let lengths: Vec<usize> = names.into_iter()
        .map(|n| n.len())
        .collect();
    // names는 이미 소비됨
    println!("  into_iter() 이름 길이: {:?}", lengths);
}

fn demo_next() {
    println!("\n  ── next() 직접 호출 ──");

    // Iterator는 next()를 반복 호출하는 것
    let mut iter = vec![1u32, 2, 3].into_iter();

    println!("  next(): {:?}", iter.next());  // Some(1)
    println!("  next(): {:?}", iter.next());  // Some(2)
    println!("  next(): {:?}", iter.next());  // Some(3)
    println!("  next(): {:?}", iter.next());  // None — 소진

    // for 루프는 into_iter() + loop { match next() } 의 sugar
    // Rust Reference: for x in v { body } 는
    //   let mut iter = v.into_iter();
    //   loop { match iter.next() { Some(x) => { body } None => break } }
    // 와 동일
}

fn demo_for_loop() {
    println!("\n  ── for 루프와 Iterator ──");

    let scores = vec![85u32, 92, 78, 95, 60];

    // enumerate(): (index, &value)
    for (i, score) in scores.iter().enumerate() {
        let grade = match score {
            90..=100 => "A",
            80..=89  => "B",
            70..=79  => "C",
            _        => "F",
        };
        println!("  [{}] {} 점 → {}", i + 1, score, grade);
    }

    // zip(): 두 이터레이터를 묶음
    let names  = ["Simba", "Donald", "Nagini"];
    let ages   = [5u32, 3, 8];
    for (name, age) in names.iter().zip(ages.iter()) {
        println!("  {} — {}살", name, age);
    }
}
