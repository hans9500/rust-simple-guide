// ┌─────────────────────────────────────────────────────────────────────┐
// │  커스텀 Iterator 구현 구조                                           │
// │                                                                     │
// │  struct MyIter { data: Vec<i32>, pos: usize }                       │
// │                                                                     │
// │  impl Iterator for MyIter {                                         │
// │      type Item = i32;                                               │
// │      fn next(&mut self) -> Option<i32> {                            │
// │          if self.pos < self.data.len() {                            │
// │              let val = self.data[self.pos];                         │
// │              self.pos += 1;                                         │
// │              Some(val)   ← 다음 값 반환                             │
// │          } else {                                                   │
// │              None        ← 소진                                     │
// │          }                                                          │
// │      }                                                              │
// │  }                                                                  │
// │                                                                     │
// │  next() 하나만 구현하면 map/filter/collect 등 전부 자동 사용 가능    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 11-4: 커스텀 Iterator 구현
// │
// │ Iterator trait을 직접 구현하면
// │ map, filter, collect 등 모든 어댑터/소비자를 무료로 얻는다.
// │
// │ 필수 구현: type Item, fn next()
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [11-4: 커스텀 Iterator]");
    demo_counter();
    demo_zoo_iter();
    demo_infinite_iter();
}

// ── 단순 카운터 Iterator ──────────────────────────────────────────
struct Counter {
    count: u32,
    max:   u32,
}

impl Counter {
    fn new(max: u32) -> Self {
        Counter { count: 0, max }
    }
}

impl Iterator for Counter {
    type Item = u32;

    fn next(&mut self) -> Option<Self::Item> {
        if self.count < self.max {
            self.count += 1;
            Some(self.count)
        } else {
            None
        }
    }
}

fn demo_counter() {
    println!("\n  ── Counter Iterator ──");

    let counter = Counter::new(5);
    let values: Vec<u32> = counter.collect();
    println!("  Counter(5): {:?}", values);

    // Iterator 어댑터 사용 가능
    let sum: u32 = Counter::new(5).sum();
    println!("  합계: {}", sum);

    // zip + map
    let pairs: Vec<u32> = Counter::new(5)
        .zip(Counter::new(5).skip(1))
        .map(|(a, b)| a * b)
        .collect();
    println!("  인접 쌍 곱: {:?}", pairs);  // [1*2, 2*3, 3*4, 4*5]
}

// ── 동물원 이터레이터 ─────────────────────────────────────────────
#[derive(Debug, Clone)]
struct Animal {
    name:    String,
    species: String,
    age:     u32,
}

impl Animal {
    fn new(name: &str, species: &str, age: u32) -> Self {
        Animal {
            name:    name.to_string(),
            species: species.to_string(),
            age,
        }
    }
}

struct ZooIter {
    animals: Vec<Animal>,
    index:   usize,
    // 필터: None이면 전체, Some이면 해당 종만
    filter_species: Option<String>,
}

impl ZooIter {
    fn all(animals: Vec<Animal>) -> Self {
        ZooIter { animals, index: 0, filter_species: None }
    }

    fn by_species(animals: Vec<Animal>, species: &str) -> Self {
        ZooIter {
            animals,
            index: 0,
            filter_species: Some(species.to_string()),
        }
    }
}

impl Iterator for ZooIter {
    type Item = Animal;

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            if self.index >= self.animals.len() {
                return None;
            }
            let animal = self.animals[self.index].clone();
            self.index += 1;

            // 필터 적용
            if let Some(ref species) = self.filter_species {
                if &animal.species != species {
                    continue;  // 다음으로
                }
            }
            return Some(animal);
        }
    }
}

fn demo_zoo_iter() {
    println!("\n  ── Zoo Iterator ──");

    let animals = vec![
        Animal::new("Simba",   "사자",   5),
        Animal::new("Nala",    "사자",   4),
        Animal::new("Donald",  "오리",   3),
        Animal::new("Daisy",   "오리",   2),
        Animal::new("Nagini",  "뱀",     8),
    ];

    // 전체 순회
    let all_names: Vec<String> = ZooIter::all(animals.clone())
        .map(|a| a.name)
        .collect();
    println!("  전체: {:?}", all_names);

    // 종별 필터
    let lions: Vec<String> = ZooIter::by_species(animals.clone(), "사자")
        .map(|a| format!("{} ({}살)", a.name, a.age))
        .collect();
    println!("  사자: {:?}", lions);

    // Iterator 메서드 체인
    let oldest_duck = ZooIter::by_species(animals.clone(), "오리")
        .max_by_key(|a| a.age);
    if let Some(duck) = oldest_duck {
        println!("  최고령 오리: {} ({}살)", duck.name, duck.age);
    }
}

// ── 무한 Iterator ─────────────────────────────────────────────────
struct FeedSchedule {
    current_hour: u32,
}

impl FeedSchedule {
    fn new() -> Self {
        FeedSchedule { current_hour: 0 }
    }
}

impl Iterator for FeedSchedule {
    type Item = (u32, &'static str);  // (시각, 동물)

    fn next(&mut self) -> Option<Self::Item> {
        // 무한 이터레이터 — None을 반환하지 않음
        let animals = ["사자", "오리", "뱀", "코끼리"];
        let animal = animals[self.current_hour as usize % animals.len()];
        let hour = self.current_hour;
        self.current_hour = (self.current_hour + 1) % 24;
        Some((hour, animal))
    }
}

fn demo_infinite_iter() {
    println!("\n  ── 무한 Iterator + take ──");

    // take()로 원하는 만큼만 소비
    let schedule: Vec<(u32, &str)> = FeedSchedule::new()
        .take(8)
        .collect();
    println!("  8회 먹이 일정:");
    for (hour, animal) in &schedule {
        println!("    {}시: {}", hour, animal);
    }

    // std 무한 이터레이터
    // iter::repeat: 같은 값 무한 반복
    let _repeated: Vec<&str> = std::iter::repeat("먹이")
        .take(3)
        .collect();

    // iter::successors: 이전 값으로 다음 값 생성
    let growth: Vec<f64> = std::iter::successors(Some(1.0f64), |&w| {
        if w < 100.0 { Some(w * 1.5) } else { None }
    }).collect();
    println!("  성장 추이(1.5배씩): {:?}",
        growth.iter().map(|w| format!("{:.1}", w)).collect::<Vec<_>>());
}
