// ┌───────────────────────────────────────────────────────────────────────┐
// │  부록. 컴파일러 동작 의사코드                                            │
// │                                                                       │
// │  실제 컴파일러 코드가 아니라 "개념적으로 이런 일이 일어난다"는 설명이다.  │
// │  MIR(Mid-level Intermediate Representation) 수준의 개념적 표현.        │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 부록A: 단형화(Monomorphization) ─────────────────────────────────────
//
//  작성한 코드:
//    fn inspect<T: Sound>(animal: &T) { animal.make_sound(); }
//
//  컴파일러가 생성하는 코드 (개념적, 이름 맹글링 포함):
//    // inspect(&simba) 호출 → T=Lion
//    fn _ZN...inspect_Lion(animal: *const Lion) {
//        Lion::make_sound(animal);   // 직접 연결, 인라인 가능
//    }
//    // inspect(&donald) 호출 → T=Duck
//    fn _ZN...inspect_Duck(animal: *const Duck) {
//        Duck::make_sound(animal);
//    }
//    // 런타임에 타입 확인 없음 → C 수준 성능
//    // 단점: 타입마다 코드 생성 → 바이너리 크기 증가 가능

// ─── 부록B: vtable 생성 ───────────────────────────────────────────────────
//
//  &dyn Sound 를 만들 때 컴파일러가 Lion용 vtable 생성:
//
//  // 컴파일러가 생성하는 static (프로그램 내내 존재)
//  static LION_SOUND_VTABLE: VTable = VTable {
//      size:        32,                       // size_of::<Lion>()
//      align:       8,                        // align_of::<Lion>()
//      drop_fn:     drop_in_place::<Lion>,    // Lion의 소멸자
//      make_sound:  Lion::make_sound,         // 함수 포인터
//      loud_sound:  Lion::loud_sound,         // 함수 포인터
//  };
//
//  &dyn Sound 생성:
//  let dyn_ref: &dyn Sound = &simba;
//  → 컴파일러:
//     FatPtr { data: &simba as *const (), vtable: &LION_SOUND_VTABLE }
//
//  dyn_ref.make_sound() 호출:
//  → (vtable.make_sound)(data)
//  → LION_SOUND_VTABLE.make_sound(&simba)
//  → Lion::make_sound(&simba)

// ─── 부록C: Drop과 MIR ────────────────────────────────────────────────────
//
//  작성한 코드:
//  fn example() {
//      let gate = ZooGate { gate_id: 1, .. };
//      println!("{:?}", gate);
//  }
//
//  MIR에서 컴파일러가 자동 삽입:
//  fn example() {
//      let gate = ZooGate { gate_id: 1, .. };
//      println!("{:?}", gate);
//      drop_in_place(&mut gate);   // 컴파일러 자동 삽입
//      // → ZooGate::drop(&mut gate) 호출 → println!("[Drop] ...")
//      // → gate.is_locked (bool): drop 불필요 (Copy)
//      // → gate.gate_id   (u32):  drop 불필요 (Copy)
//  }

// ─── 부록D: NLL (Non-Lexical Lifetimes) ──────────────────────────────────
//
//  Rust 2018+ — 빌림이 "마지막 사용 시점" 이후 즉시 해제.
//
//  Rust 2015 (Lexical Lifetimes):
//  ──────────────────────────── 시간 ──▶
//  let r = &s;     빌림 시작
//  use(r);
//  s.push_str()    ← 에러: r의 빌림이 중괄호 끝까지 유지됨
//  }               빌림 끝
//
//  Rust 2018+ (NLL):
//  ──────────────────────────── 시간 ──▶
//  let r = &s;     빌림 시작
//  use(r);         ← r의 마지막 사용 → 여기서 빌림 끝
//  s.push_str()    ← OK: r 빌림이 이미 끝남
//  }

// ─── 부록E: 이름 맹글링 (Name Mangling) ──────────────────────────────────
//
//  작성한 코드:
//  impl Sound for Lion {
//      fn make_sound(&self) -> String { ... }
//  }
//
//  컴파일러 내부 심볼 이름 (개념적):
//  _ZN10rust_guide5Lion10make_soundE  (Itanium ABI 형식)
//   ↑   ↑crate    ↑타입 ↑메서드
//
//  목적: Lion::make_sound 와 Duck::make_sound 가
//        링커(linker) 수준에서 충돌하지 않도록 유일한 이름을 부여.

use crate::part2_patterns::animals::{Lion, Duck, Snake};
use crate::part2_patterns::pattern2_trait::Sound;
use crate::part3_std_traits::pattern8_default_drop::ZooGate;

fn inspect_impl(animal: &impl Sound) {
    println!("    단형화: {}", animal.make_sound());
}

pub fn run() {
    println!("\n─── 부록: 컴파일러 동작 확인 ───");

    // 단형화 — 같은 함수 이름, 타입별 별도 코드 생성
    let simba  = Lion::new("Simba", 5);
    let donald = Duck::new("Donald", 3);
    inspect_impl(&simba);   // 컴파일러: inspect_impl__Lion 생성
    inspect_impl(&donald);  // 컴파일러: inspect_impl__Duck 생성

    // vtable — dyn 사용 시 fat pointer + vtable 생성
    let animals: Vec<Box<dyn Sound>> = vec![
        Box::new(Lion::new("Scar",  9)),
        Box::new(Duck::new("Daffy", 4)),
        Box::new(Snake::new("Kaa", 12, false)),
    ];
    for a in &animals {
        println!("    vtable 호출: {}", a.make_sound());
    }

    // Drop 순서 — 선언의 역순
    {
        let _g1 = ZooGate { gate_id: 1, is_locked: true };
        let _g2 = ZooGate { gate_id: 2, is_locked: true };
        let _g3 = ZooGate { gate_id: 3, is_locked: true };
        println!("    g1, g2, g3 선언 완료");
    }   // drop(_g3) → drop(_g2) → drop(_g1) 순서로 출력
}
