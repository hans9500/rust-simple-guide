// ┌─────────────────────────────────────────────────────────────────────┐
// │  모듈 트리 구조                                                      │
// │                                                                     │
// │  crate (루트)                                                        │
// │    └── main.rs                                                      │
// │          ├── pub mod part0_ownership;  → src/part0_ownership/       │
// │          │         ├── mod.rs          ← 진입점                     │
// │          │         ├── ownership.rs                                 │
// │          │         └── borrowing.rs                                 │
// │          └── pub mod part1_lifetime;  → src/part1_lifetime/         │
// │                    └── ...                                          │
// │                                                                     │
// │  경로 접근:                                                          │
// │    crate::part0_ownership::ownership::run()  ← 절대 경로            │
// │    super::borrowing::run()                   ← 상대 경로            │
// │    self::run_ownership()                     ← 현재 모듈            │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 14-1: 모듈 기초
// │
// │ mod 키워드: 모듈 선언
// │   1. 인라인: mod name { ... }
// │   2. 파일:   mod name;  →  src/name.rs 또는 src/name/mod.rs
// │
// │ 경로:
// │   절대 경로: crate::module::item
// │   상대 경로: self::item, super::item
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [14-1: 모듈 기초]");
    demo_inline_module();
    demo_paths();
    demo_nested();
}

// ── 인라인 모듈 ───────────────────────────────────────────────────
mod zoo {
    pub struct Animal {
        pub name:    String,
        pub species: String,
    }

    impl Animal {
        pub fn new(name: &str, species: &str) -> Self {
            Animal {
                name:    name.to_string(),
                species: species.to_string(),
            }
        }
        pub fn describe(&self) -> String {
            format!("{} ({})", self.name, self.species)
        }
    }

    pub mod carnivore {
        // super:: 로 부모 모듈 접근
        pub fn is_carnivore(species: &str) -> bool {
            matches!(species, "사자" | "호랑이" | "뱀")
        }

        pub fn feed_carnivore(animal: &super::Animal) -> String {
            format!("{} 에게 고기를 줍니다", animal.name)
        }
    }

    pub mod herbivore {
        pub fn feed_herbivore(name: &str) -> String {
            format!("{} 에게 풀을 줍니다", name)
        }
    }
}

fn demo_inline_module() {
    println!("\n  ── 인라인 모듈 ──");

    // 절대 경로로 접근
    let lion = zoo::Animal::new("Simba", "사자");
    println!("  {}", lion.describe());

    // 중첩 모듈 접근
    let is_meat_eater = zoo::carnivore::is_carnivore("사자");
    println!("  사자는 육식동물: {}", is_meat_eater);

    let feed_msg = zoo::carnivore::feed_carnivore(&lion);
    println!("  {}", feed_msg);

    let duck = zoo::Animal::new("Donald", "오리");
    let feed_msg2 = zoo::herbivore::feed_herbivore(&duck.name);
    println!("  {}", feed_msg2);
}

fn demo_paths() {
    println!("\n  ── 경로 (절대/상대) ──");

    // 절대 경로: crate:: 로 시작
    // (이 파일 내에서 zoo 모듈 접근)
    let snake = zoo::Animal::new("Nagini", "뱀");
    println!("  절대경로 생성: {}", snake.describe());

    // 모듈 내에서의 경로 규칙:
    // - self::  현재 모듈
    // - super:: 부모 모듈
    // - crate:: 크레이트 루트
    println!("  경로 규칙:");
    println!("    crate:: → 크레이트 루트 (main.rs/lib.rs)");
    println!("    self::  → 현재 모듈");
    println!("    super:: → 부모 모듈");
}

mod department {
    pub mod africa {
        pub fn section() -> &'static str { "아프리카관" }

        pub mod lion_zone {
            pub fn zone_name() -> String {
                // super:: 로 부모(africa) 접근
                format!("{} - 사자 구역", super::section())
            }
        }
    }

    pub mod asia {
        pub fn section() -> &'static str { "아시아관" }
    }
}

fn demo_nested() {
    println!("\n  ── 중첩 모듈 ──");
    println!("  {}", department::africa::lion_zone::zone_name());
    println!("  {}", department::asia::section());
}
