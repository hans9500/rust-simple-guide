// ┌─────────────────────────────────────────────────────────────────────┐
// │  mod.rs vs 파일 모듈                                                 │
// │                                                                     │
// │  방식 1: mod.rs (전통적)                                             │
// │    src/zoo/mod.rs        ← zoo 모듈 진입점                          │
// │    src/zoo/lion.rs       ← zoo::lion 서브모듈                       │
// │                                                                     │
// │  방식 2: 파일명 (Rust 2018+)                                         │
// │    src/zoo.rs            ← zoo 모듈 진입점                          │
// │    src/zoo/lion.rs       ← zoo::lion 서브모듈                       │
// │                                                                     │
// │  선언 없으면 파일이 있어도 컴파일러가 무시:                           │
// │    // mod.rs에 선언 없으면:                                          │
// │    use crate::zoo::lion::Lion;  → 컴파일 에러!                      │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 14-4: 모듈 심화
// │
// │ - 파일 기반 모듈 구조 설명
// │ - 모듈과 테스트
// │ - 외부 크레이트 사용
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [14-4: 모듈 심화]");
    demo_file_structure();
    demo_test_module();
    demo_prelude_pattern();
}

fn demo_file_structure() {
    println!("\n  ── 파일 기반 모듈 구조 ──");
    println!(r#"
  이 프로젝트의 모듈 트리:
  crate (main.rs)
  ├── part0_ownership/
  │   ├── mod.rs          ← pub mod ownership; pub mod borrowing; ...
  │   ├── ownership.rs    ← mod part0_ownership::ownership
  │   └── borrowing.rs
  ├── part10_closure/
  │   ├── mod.rs
  │   └── closure_basic.rs
  └── ...

  선언 규칙:
    mod name;         →  src/name.rs  또는  src/name/mod.rs
    mod name {{ ... }}  →  인라인 모듈

  Rust 2018+: mod.rs 대신 name.rs 파일로도 가능
    src/part10_closure.rs  (단일 파일 모듈)
    src/part10_closure/    (디렉토리 모듈)
    └── mod.rs             (또는 없으면 부모에서 선언)
    "#);
}

// ── 테스트 모듈 ───────────────────────────────────────────────────
// #[cfg(test)]: 테스트 빌드에서만 컴파일
// tests 모듈은 관례상 같은 파일 하단에 위치
fn add_animals(a: u32, b: u32) -> u32 { a + b }
fn is_adult(age: u32) -> bool { age >= 5 }

fn validate_weight(weight: f64) -> Result<f64, String> {
    if weight <= 0.0 {
        Err(format!("체중 {}는 유효하지 않음", weight))
    } else {
        Ok(weight)
    }
}

#[cfg(test)]
mod tests {
    // super::*로 부모 모듈의 모든 공개 아이템 가져오기
    use super::*;

    #[test]
    fn test_add_animals() {
        assert_eq!(add_animals(3, 2), 5);
        assert_eq!(add_animals(0, 0), 0);
    }

    #[test]
    fn test_is_adult() {
        assert!(is_adult(5));
        assert!(is_adult(10));
        assert!(!is_adult(4));
        assert!(!is_adult(0));
    }

    #[test]
    fn test_validate_weight_ok() {
        assert_eq!(validate_weight(190.5), Ok(190.5));
    }

    #[test]
    fn test_validate_weight_err() {
        assert!(validate_weight(-1.0).is_err());
        assert!(validate_weight(0.0).is_err());
    }
}

fn demo_test_module() {
    println!("\n  ── 테스트 모듈 ──");
    println!("  #[cfg(test)] 모듈이 이 파일 하단에 정의됨");
    println!("  cargo test 로 실행");
    println!("  테스트: test_add_animals, test_is_adult, test_validate_weight");

    // 함수들이 실제로 동작함을 확인
    println!("  add_animals(3,2) = {}", add_animals(3, 2));
    println!("  is_adult(5) = {}", is_adult(5));
    println!("  validate_weight(190.5) = {:?}", validate_weight(190.5));
    println!("  validate_weight(-1.0) = {:?}", validate_weight(-1.0));
}

// ── Prelude 패턴 ─────────────────────────────────────────────────
mod zoo_prelude {
    // 자주 쓰는 타입들을 prelude로 모아서
    // use crate::zoo_prelude::*; 한 줄로 임포트 가능하게
    pub use std::collections::HashMap;

    pub type ZooResult<T> = Result<T, ZooError>;

    #[derive(Debug)]
    pub enum ZooError {
        NotFound(String),
        Capacity,
    }

    impl std::fmt::Display for ZooError {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            match self {
                Self::NotFound(s) => write!(f, "찾을 수 없음: {}", s),
                Self::Capacity    => write!(f, "수용 한계 초과"),
            }
        }
    }

    impl std::error::Error for ZooError {}
}

fn demo_prelude_pattern() {
    println!("\n  ── Prelude 패턴 ──");
    use zoo_prelude::*;

    let mut registry: HashMap<&str, u32> = HashMap::new();
    registry.insert("사자", 5);
    registry.insert("오리", 3);

    let result: ZooResult<u32> = registry
        .get("사자")
        .copied()
        .ok_or_else(|| ZooError::NotFound("사자".to_string()));

    println!("  사자 나이: {:?}", result);

    let missing: ZooResult<u32> = registry
        .get("호랑이")
        .copied()
        .ok_or_else(|| ZooError::NotFound("호랑이".to_string()));
    println!("  호랑이: {:?}", missing);

    // Capacity variant 사용
    let full: ZooResult<u32> = Err(ZooError::Capacity);
    println!("  수용초과: {}", full.unwrap_err());
}
