// ┌──────────────────────────────────────────────────────────────────
// │ Part 14: 모듈 시스템
// │
// │ 공식 문서: Rust Book Ch.7
// │
// │ Rust 모듈 시스템:
// │   - 패키지(Package): Cargo.toml + 크레이트들
// │   - 크레이트(Crate): 컴파일 단위 (lib 또는 bin)
// │   - 모듈(Module): mod 키워드로 코드 조직화
// │   - 경로(Path): 모듈 트리에서 아이템 위치
// └──────────────────────────────────────────────────────────────────

pub mod module_basic;
pub mod module_visibility;
pub mod module_use;
pub mod module_advanced;
pub mod module_declaration;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 14: 모듈 시스템");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    module_basic::run();
    module_visibility::run();
    module_use::run();
    module_advanced::run();
    module_declaration::run();
}
