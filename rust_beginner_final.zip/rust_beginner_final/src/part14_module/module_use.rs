// ┌──────────────────────────────────────────────────────────────────
// │ Part 14-3: use 키워드
// │
// │ use: 모듈 경로를 현재 스코프로 가져옴
// │   - 긴 경로를 짧게
// │   - as로 별칭
// │   - 중첩 경로로 한 줄에 여러 개
// │   - pub use로 재내보내기
// └──────────────────────────────────────────────────────────────────

// 표준 라이브러리 use
use std::collections::HashMap;
use std::collections::HashSet;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  use 경로 패턴                                                       │
// │                                                                     │
// │  use std::collections::HashMap;         ← 단일 항목                 │
// │  use std::collections::{HashMap, BTreeMap}; ← 복수                 │
// │  use std::collections::*;               ← glob (신중히)             │
// │                                                                     │
// │  use std::fmt::Display as Disp;         ← 별칭                     │
// │                                                                     │
// │  pub use crate::zoo::Animal;            ← 재내보내기                │
// │    → 외부에서 이 모듈을 통해 Animal 접근 가능                        │
// │                                                                     │
// │  중첩 경로:                                                          │
// │  use std::{fmt, io, collections::HashMap};                          │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [14-3: use 키워드]");
    demo_use_basic();
    demo_use_as();
    demo_use_nested();
    demo_pub_use();
}

fn demo_use_basic() {
    println!("\n  ── use 기본 ──");

    // use 없이: std::collections::HashMap::new()
    // use 있으면: HashMap::new()
    let mut animal_ages: HashMap<&str, u32> = HashMap::new();
    animal_ages.insert("Simba", 5);
    animal_ages.insert("Donald", 3);
    animal_ages.insert("Nagini", 8);
    println!("  HashMap: {:?}", animal_ages);

    // 관례: 타입은 부모 모듈까지만 use
    // HashMap ← O (타입 자체)
    // use std::collections; → collections::HashMap ← 이것도 OK
    //
    // 함수는 부모 모듈까지 use
    // use std::mem; → mem::size_of::<u32>()  ← 관례

    let set: HashSet<&str> = ["사자", "오리", "사자"].iter().copied().collect();
    let mut sorted: Vec<&&str> = set.iter().collect();
    sorted.sort();
    println!("  HashSet: {:?}", sorted);
}

fn demo_use_as() {
    println!("\n  ── as 별칭 ──");

    // 이름 충돌 해결
    use std::fmt::Result as FmtResult;
    use std::io::Result as IoResult;

    fn fmt_ok() -> FmtResult { Ok(()) }
    fn io_ok() -> IoResult<()> { Ok(()) }

    println!("  fmt: {:?}", fmt_ok());
    println!("  io: {:?}", io_ok());
}

fn demo_use_nested() {
    println!("\n  ── 중첩 경로 ──");

    // 한 줄에 여러 경로
    use std::collections::{BTreeMap, BTreeSet};

    // self로 부모도 포함
    // use std::io::{self, Write};  // std::io 와 std::io::Write 동시

    let mut map: BTreeMap<&str, u32> = BTreeMap::new();
    map.insert("뱀", 8);
    map.insert("사자", 5);
    map.insert("오리", 3);
    // BTreeMap은 키 순서 유지
    println!("  BTreeMap(정렬): {:?}", map);

    let set: BTreeSet<&str> = ["사자", "오리", "뱀"].iter().copied().collect();
    println!("  BTreeSet(정렬): {:?}", set);

    // 와일드카드: use module::*  (테스트에서 주로 사용)
    // use std::collections::*;  // 모든 공개 아이템
}

fn demo_pub_use() {
    println!("\n  ── pub use: 재내보내기(re-export) ──");

    // pub use를 사용하면 외부에서 더 짧은 경로로 접근 가능
    // 예: 라이브러리에서 내부 구조를 숨기고 공개 API만 노출

    mod internal {
        pub struct ZooConfig {
            pub max_animals: u32,
            pub name: String,
        }
        impl ZooConfig {
            pub fn new(name: &str, max: u32) -> Self {
                ZooConfig { max_animals: max, name: name.to_string() }
            }
        }
    }

    // pub use로 재내보내기
    pub use internal::ZooConfig;

    let config = ZooConfig::new("서울 동물원", 100);
    println!("  ZooConfig: {} (최대 {}마리)", config.name, config.max_animals);
    println!("  pub use로 internal::ZooConfig를 현재 모듈에서 노출");
}
