// ┌─────────────────────────────────────────────────────────────────────┐
// │  가시성 범위 비교                                                     │
// │                                                                     │
// │                 같은   부모   크레이트  외부                          │
// │                 모듈   모듈   전체      크레이트                      │
// │  private         ✅     ❌     ❌        ❌                           │
// │  pub(self)       ✅     ❌     ❌        ❌                           │
// │  pub(super)      ✅     ✅     ❌        ❌                           │
// │  pub(crate)      ✅     ✅     ✅        ❌                           │
// │  pub             ✅     ✅     ✅        ✅                           │
// │                                                                     │
// │  struct 필드는 struct와 별개로 가시성 설정 가능:                      │
// │    pub struct Foo {                                                  │
// │        pub name: String,    ← 공개                                  │
// │        age: u32,            ← 비공개 (같은 모듈에서만)               │
// │    }                                                                │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 14-2: 가시성(Visibility)
// │
// │ 공식 문서: Rust Reference "Visibility and Privacy"
// │
// │ 기본: private (같은 모듈 + 자식 모듈만 접근)
// │ pub:          공개
// │ pub(crate):   같은 크레이트 내에서만 공개
// │ pub(super):   부모 모듈까지만 공개
// │ pub(in path): 특정 경로까지만 공개
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [14-2: 가시성]");
    demo_visibility_levels();
    demo_struct_field_visibility();
}

mod outer {
    // pub: 어디서나 접근 가능
    pub fn public_fn() -> &'static str { "public" }

    // pub(crate): 같은 크레이트 내에서만
    pub(crate) fn crate_fn() -> &'static str { "crate-visible" }

    // pub(super): 부모 모듈(outer의 부모 = module_visibility)까지
    pub(super) fn super_fn() -> &'static str { "super-visible" }

    // 기본 private: 같은 모듈(outer) + 자식 모듈만
    fn private_fn() -> &'static str { "private" }

    pub mod inner {
        pub fn call_parent() {
            // private_fn은 부모 모듈이므로 접근 가능
            println!("    inner에서 private_fn: {}", super::private_fn());
            println!("    inner에서 super_fn: {}", super::super_fn());
        }
    }
}

fn demo_visibility_levels() {
    println!("\n  ── 가시성 수준 ──");

    println!("  public_fn: {}", outer::public_fn());
    println!("  crate_fn: {}", outer::crate_fn());
    println!("  super_fn: {}", outer::super_fn());
    // outer::private_fn()  // 에러: private

    outer::inner::call_parent();
}

mod animal_module {
    // 구조체는 pub이어도 필드는 별도로 pub 지정해야 함
    pub struct Animal {
        pub name:      String,     // pub: 외부 접근 가능
        pub species:   String,     // pub
        age:           u32,        // private: 외부 접근 불가
        health_score:  f64,        // private
    }

    impl Animal {
        // 생성자: private 필드를 초기화하는 유일한 방법
        pub fn new(name: &str, species: &str, age: u32) -> Self {
            Animal {
                name:         name.to_string(),
                species:      species.to_string(),
                age,
                health_score: 100.0,
            }
        }

        // getter: private 필드 읽기
        pub fn age(&self) -> u32 { self.age }
        pub fn health(&self) -> f64 { self.health_score }

        // 내부 로직: private
        fn calculate_health(&self) -> f64 {
            // 나이에 따른 건강 점수 감소
            (100.0 - self.age as f64 * 2.0).max(0.0)
        }

        pub fn annual_checkup(&mut self) {
            self.age += 1;
            self.health_score = self.calculate_health();
        }
    }
}

fn demo_struct_field_visibility() {
    println!("\n  ── 구조체 필드 가시성 ──");

    let mut lion = animal_module::Animal::new("Simba", "사자", 5);

    // pub 필드: 직접 접근
    println!("  이름: {}", lion.name);
    println!("  종: {}", lion.species);

    // private 필드: getter로만
    println!("  나이: {}살", lion.age());
    println!("  건강: {:.0}점", lion.health());

    // lion.age = 10;  // 에러: private 필드 직접 수정 불가

    lion.annual_checkup();
    println!("  1년 후 나이: {}살, 건강: {:.0}점",
             lion.age(), lion.health());
}
