// ┌──────────────────────────────────────────────────────────────────
// │ Part 14 보강: mod 선언 규칙 완전 정리
// │
// │ 공식 문서: Rust Reference "Modules", Rust Book Ch.7
// │
// │ 핵심 규칙:
// │   파일이 존재해도 mod 선언이 없으면 컴파일러가 완전히 무시한다.
// │   mod 선언 = "이 파일을 모듈 트리에 등록하겠다"는 명시적 선언
// │
// │ mod.rs 의 역할:
// │   디렉토리 모듈의 진입점(entry point)
// │   src/foo/ 디렉토리가 모듈이 되려면 src/foo/mod.rs 필요
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [Part 14 보강: mod 선언 규칙]");
    demo_file_ignored_without_mod();
    demo_pub_mod_vs_mod();
    demo_mod_rs_role();
    demo_reexport();
}

// ── 1. mod 선언 없으면 파일이 무시된다 ───────────────────────────
fn demo_file_ignored_without_mod() {
    println!("\n  ── 규칙1: mod 선언 없으면 파일 무시 ──");

    // src/
    // ├── main.rs
    // └── part0_ownership/
    //     ├── mod.rs
    //     ├── ownership.rs       ← pub mod ownership; 선언 있음 → 사용 가능
    //     └── secret.rs          ← 선언 없음 → 컴파일러가 완전히 무시
    //
    // mod.rs 에서:
    //   pub mod ownership;   // ✅ ownership.rs 모듈 트리에 등록
    //   // mod secret;       // ← 이 줄이 없으면 secret.rs는 없는 것과 같음
    //
    // 결과:
    //   use crate::part0_ownership::ownership::Foo;  // ✅ 컴파일 OK
    //   use crate::part0_ownership::secret::Bar;     // ❌ 컴파일 에러
    //     → error[E0432]: unresolved import
    //
    // 이것이 Rust가 명시적 모듈 선언을 요구하는 이유:
    //   - 어떤 파일이 컴파일에 포함되는지 명확하게 알 수 있음
    //   - 실수로 파일을 빠뜨려도 컴파일 에러로 즉시 알 수 있음
    //   - Python(자동 임포트)과 달리 의도적 선택 강제

    println!("  파일 존재 + mod 선언 없음 → 컴파일러가 완전히 무시");
    println!("  파일 존재 + pub mod 선언   → 외부에서 접근 가능");
    println!("  파일 존재 + mod 선언(pub 없음) → 같은 모듈 안에서만 접근");
}

// ── 2. pub mod vs mod ────────────────────────────────────────────
mod internal {
    // 이 모듈은 module_declaration.rs 안에서만 접근 가능
    pub fn secret_fn() -> &'static str {
        "내부 전용 함수"
    }
}

pub mod exported {
    // 이 모듈은 외부에서도 접근 가능
    pub fn public_fn() -> &'static str {
        "외부 공개 함수"
    }
}

fn demo_pub_mod_vs_mod() {
    println!("\n  ── pub mod vs mod ──");

    // mod internal   → 이 파일 안에서만 접근 가능
    println!("  mod internal: {}", internal::secret_fn());

    // pub mod exported → 외부에서도 접근 가능
    println!("  pub mod exported: {}", exported::public_fn());

    // 외부 파일에서:
    //   use crate::part14_module::module_declaration::exported; // ✅
    //   use crate::part14_module::module_declaration::internal; // ❌ 비공개

    println!("\n  pub mod: 외부 공개 (main.rs, 다른 파트에서 접근 가능)");
    println!("  mod:     내부 전용 (같은 파일/모듈 안에서만)");
    println!("  차이: 가시성만 다름, 둘 다 파일을 모듈 트리에 등록함");
}

// ── 3. mod.rs 의 역할 ─────────────────────────────────────────────
fn demo_mod_rs_role() {
    println!("\n  ── mod.rs: 디렉토리 모듈의 진입점 ──");

    println!(r#"
  디렉토리 모듈 구조:
  src/
  ├── main.rs              ← pub mod part14_module;
  └── part14_module/
      ├── mod.rs           ← 진입점: pub mod module_basic; 등 선언
      ├── module_basic.rs
      ├── module_visibility.rs
      ├── module_use.rs
      ├── module_advanced.rs
      └── module_declaration.rs  ← 이 파일

  mod.rs 없으면?
    src/part14_module/ 디렉토리가 있어도
    main.rs 의 pub mod part14_module; 이 에러남
    → error[E0583]: file not found for module `part14_module`

  Rust 2018+ 대안:
    mod.rs 대신 부모 디렉토리에 같은 이름의 .rs 파일
    src/part14_module.rs  (단일 파일 모듈)
    src/part14_module/    (디렉토리 모듈, mod.rs 필요)
    "#);

    println!("  mod.rs 역할:");
    println!("    1. 디렉토리를 모듈로 인식시키는 진입점");
    println!("    2. 하위 파일들을 pub mod / mod 로 등록");
    println!("    3. 모듈 수준 pub use 로 API 재구성");
}

// ── 4. pub use 재내보내기 ─────────────────────────────────────────
mod animals {
    pub struct Lion { pub name: String }
    pub struct Duck { pub name: String }

    impl Lion {
        pub fn new(name: &str) -> Self { Lion { name: name.to_string() } }
    }
    impl Duck {
        pub fn new(name: &str) -> Self { Duck { name: name.to_string() } }
    }
}

// pub use: animals 모듈 내부를 이 모듈 수준으로 끌어올림
// 외부에서 module_declaration::Lion 으로 직접 접근 가능
pub use animals::Lion;
pub use animals::Duck;

fn demo_reexport() {
    println!("\n  ── pub use: 재내보내기(re-export) ──");

    // pub use 없이 접근:
    //   crate::part14_module::module_declaration::animals::Lion
    //
    // pub use 후 접근:
    //   crate::part14_module::module_declaration::Lion  ← 더 짧음

    let lion = Lion::new("Simba");
    let duck = Duck::new("Donald");
    println!("  pub use Lion: {}", lion.name);
    println!("  pub use Duck: {}", duck.name);

    println!("\n  pub use 활용 사례:");
    println!("  1. 내부 구조를 숨기고 공개 API만 노출");
    println!("     mod internal {{ pub struct Foo; }}");
    println!("     pub use internal::Foo;  // internal은 숨기고 Foo만 공개");
    println!("  2. 긴 경로를 짧게");
    println!("     pub use crate::a::b::c::Foo;  // 최상위에서 바로 접근");
    println!("  3. 이름 변경");
    println!("     pub use ownership::run as run_ownership;");

    println!("\n  ── 정리 ──");
    println!("  mod name;          파일을 모듈 트리에 등록 (비공개)");
    println!("  pub mod name;      파일을 모듈 트리에 등록 (공개)");
    println!("  pub use a::b::Foo; Foo를 현재 모듈 수준으로 재내보내기");
    println!("  선언 없음          파일이 존재해도 컴파일러가 무시");
}
