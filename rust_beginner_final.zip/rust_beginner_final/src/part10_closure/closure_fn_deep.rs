// ┌─────────────────────────────────────────────────────────────────────┐
// │  트레이트 자동 구현 규칙                                              │
// │                                                                     │
// │  클로저가 캡처한 값을...                                              │
// │                                                                     │
// │  읽기만(&T)       ──▶  Fn + FnMut + FnOnce  모두 구현               │
// │  수정(&mut T)     ──▶  FnMut + FnOnce       구현                    │
// │  소비(drop/move)  ──▶  FnOnce               만 구현                 │
// │                                                                     │
// │  move 키워드: 캡처 방식이 아닌 소유권만 이동                          │
// │    move || println!("{}", name)  → name을 소유하지만 읽기만 → Fn    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  함수 인자 바운드 선택 기준                                           │
// │                                                                     │
// │  fn f<F: Fn()>(f: F)     → 가장 제한적. 반복 호출 안전.             │
// │  fn f<F: FnMut()>(f: F)  → 수정 가능. map/sort에서 사용.            │
// │  fn f<F: FnOnce()>(f: F) → 1회만. spawn/한번만 실행.                │
// │                                                                     │
// │  느슨할수록 더 많은 클로저 수용 가능:                                 │
// │    FnOnce ──수용──▶ Fn, FnMut, FnOnce 모두                         │
// │    FnMut  ──수용──▶ Fn, FnMut                                       │
// │    Fn     ──수용──▶ Fn 만                                           │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Fn/FnMut/FnOnce 심화 — 실전 예제와 선택 기준                        │
// └─────────────────────────────────────────────────────────────────────┘

pub fn run() {
    println!("\n  [Fn/FnMut/FnOnce 심화]");
    demo_fn_examples();
    demo_fnmut_examples();
    demo_fnonce_examples();
    demo_move_keyword();
    demo_practical();
}

fn demo_fn_examples() {
    println!("\n  ── Fn: 읽기 전용, 여러 번 호출 ──");

    let prefix = "동물원";

    // Fn — prefix를 읽기만 함
    let announce = |name: &str| format!("[{}] {} 입장!", prefix, name);

    // 여러 번 호출 가능
    println!("  {}", announce("Simba"));
    println!("  {}", announce("Donald"));
    println!("  {}", announce("Nagini"));
    println!("  prefix 여전히 유효: {}", prefix);

    // Fn을 받는 함수
    fn call_twice<F: Fn(&str) -> String>(f: F, name: &str) {
        println!("  1회: {}", f(name));
        println!("  2회: {}", f(name));
    }
    call_twice(announce, "Dumbo");
}

fn demo_fnmut_examples() {
    println!("\n  ── FnMut: 수정 가능, 여러 번 호출 ──");

    let mut log: Vec<String> = Vec::new();

    // FnMut — log를 수정함
    let mut record = |msg: &str| {
        log.push(format!("[LOG] {}", msg));
    };

    record("사자 입장");
    record("오리 퇴장");
    record("뱀 검진");
    drop(record);  // 빌림 해제
    println!("  기록 수: {}개", log.len());
    for entry in &log { println!("  {}", entry); }

    // FnMut를 받는 함수 — mut 선언 필요
    fn apply_n_times<F: FnMut(i32) -> i32>(mut f: F, x: i32, n: u32) -> i32 {
        let mut result = x;
        for _ in 0..n { result = f(result); }
        result
    }
    let result = apply_n_times(|x| x + 3, 0, 5);
    println!("  0에 +3 다섯 번: {}", result);
}

fn demo_fnonce_examples() {
    println!("\n  ── FnOnce: 소유권 소비, 1회만 ──");

    let greeting = String::from("환영합니다!");

    // FnOnce — greeting 소비
    let welcome = move || {
        println!("  {}", greeting);
        drop(greeting);  // 명시적 소비 (move로 인해 소유)
    };

    welcome();  // OK
    // welcome();  // 컴파일 에러: use of moved value

    // FnOnce를 받는 함수
    fn run_once<F: FnOnce() -> String>(f: F) -> String {
        f()
    }
    let name = String::from("Simba");
    let result = run_once(move || format!("안녕, {}!", name));
    println!("  {}", result);

    // thread::spawn — FnOnce 필요
    let data = vec![1, 2, 3];
    let handle = std::thread::spawn(move || {
        println!("  스레드 데이터: {:?}", data);
    });
    handle.join().unwrap();
}

fn demo_move_keyword() {
    println!("\n  ── move 키워드 — 소유권 이동, 트레이트는 별개 ──");

    let name = "Simba";  // &str — Copy

    // move여도 읽기만 하면 Fn
    let greet = move || println!("  안녕, {}!", name);
    greet();  // 여러 번 호출 가능 — Fn
    greet();

    // 스레드에서 move 필수
    let animals = vec!["사자", "오리", "뱀"];
    let handle = std::thread::spawn(move || {
        for a in &animals { print!("  {} ", a); }
        println!();
    });
    handle.join().unwrap();
}

fn demo_practical() {
    println!("\n  ── 실전: 이터레이터와 클로저 ──");

    let animals = vec![
        ("Simba",   "사자",   5u32),
        ("Donald",  "오리",   3),
        ("Nagini",  "뱀",     8),
        ("Dumbo",   "코끼리", 10),
    ];

    // map — Fn
    let names: Vec<&str> = animals.iter().map(|(name, _, _)| *name).collect();
    println!("  이름들: {:?}", names);

    // filter — Fn
    let adults: Vec<_> = animals.iter()
        .filter(|(_, _, age)| *age >= 5)
        .collect();
    println!("  성체(5살↑): {}마리", adults.len());

    // sort_by — FnMut
    let mut sorted = animals.clone();
    sorted.sort_by(|a, b| a.2.cmp(&b.2));
    println!("  나이순: {:?}", sorted.iter().map(|(n,_,a)| format!("{}({})", n, a)).collect::<Vec<_>>());

    // fold — FnMut (누적)
    let total_age: u32 = animals.iter().fold(0, |acc, (_, _, age)| acc + age);
    println!("  총 나이: {}", total_age);
}
