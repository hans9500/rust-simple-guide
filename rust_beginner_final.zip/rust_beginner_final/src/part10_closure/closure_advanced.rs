// ┌─────────────────────────────────────────────────────────────────────┐
// │  고차 함수(Higher-Order Function) 흐름                               │
// │                                                                     │
// │  fn apply<F: Fn(i32) -> i32>(f: F, x: i32) -> i32                  │
// │                                                                     │
// │  호출 흐름:                                                          │
// │  apply(|x| x*2, 5)                                                 │
// │    │                                                                │
// │    ├── F = |x| x*2  (클로저, Fn 구현)                               │
// │    ├── x = 5                                                        │
// │    └── 반환: f(x) = 10                                              │
// │                                                                     │
// │  클로저를 반환하는 함수:                                              │
// │  fn make_adder(n: i32) -> impl Fn(i32) -> i32                       │
// │    └──▶ move |x| x + n    ← n을 캡처해서 반환                       │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  fn 포인터 vs 클로저                                                 │
// │                                                                     │
// │  fn double(x: i32) -> i32 { x * 2 }   ← fn 포인터 (환경 없음)      │
// │  let triple = |x| x * 3;               ← 클로저 (환경 캡처 가능)    │
// │                                                                     │
// │  fn 포인터는 Fn + FnMut + FnOnce 모두 구현                           │
// │  → fn이 필요한 자리에 클로저 사용 가능                               │
// │  → 클로저가 필요한 자리에 fn 포인터도 사용 가능 (환경 없을 때)        │
// │                                                                     │
// │  타입 비교:                                                          │
// │    fn 포인터: fn(i32) -> i32          (크기 고정: 포인터 8B)         │
// │    클로저:    impl Fn(i32) -> i32     (크기 가변: 캡처 환경 포함)    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 10-4: 클로저 심화
// │
// │ - 클로저와 제네릭 결합
// │ - 고차 함수(Higher-Order Functions)
// │ - 클로저 vs 함수 포인터(fn)
// │ - 실전 패턴: 지연 평가, 메모이제이션 개념
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [10-4: 클로저 심화]");
    demo_higher_order();
    demo_fn_pointer();
    demo_lazy_evaluation();
    demo_closure_composition();
}

fn demo_higher_order() {
    println!("\n  ── 고차 함수 ──");

    // 함수를 인자로 받고 함수를 반환하는 함수
    let animals = vec![
        ("Simba", 5u32, 190.0f64),   // (이름, 나이, 체중kg)
        ("Donald", 3, 2.5),
        ("Nagini", 8, 15.0),
        ("Dumbo", 10, 4000.0),
        ("Giraffe", 6, 800.0),
    ];

    // 정렬 기준을 클로저로 전달
    let mut by_age = animals.clone();
    by_age.sort_by_key(|a| a.1);
    println!("  나이순: {:?}", by_age.iter().map(|a| a.0).collect::<Vec<_>>());

    let mut by_weight = animals.clone();
    by_weight.sort_by(|a, b| a.2.partial_cmp(&b.2).unwrap());
    println!("  체중순: {:?}", by_weight.iter().map(|a| a.0).collect::<Vec<_>>());

    // 조건 조합
    let heavy_adults: Vec<_> = animals.iter()
        .filter(|a| a.1 >= 5)       // 5살 이상
        .filter(|a| a.2 >= 100.0)   // 100kg 이상
        .map(|a| a.0)
        .collect();
    println!("  성체 대형 동물: {:?}", heavy_adults);
}

fn demo_fn_pointer() {
    println!("\n  ── 클로저 vs 함수 포인터(fn) ──");

    // fn 타입: 함수 포인터, 환경 캡처 불가
    // Fn 타입: 클로저 트레이트, 환경 캡처 가능
    //
    // fn은 Fn을 구현하므로 Fn이 필요한 곳에 fn 전달 가능
    // 반대(Fn → fn)는 불가

    fn double(x: i32) -> i32 { x * 2 }
    fn triple(x: i32) -> i32 { x * 3 }

    // fn 포인터 배열
    let ops: [fn(i32) -> i32; 2] = [double, triple];
    let val = 5;
    for op in &ops {
        println!("  fn 포인터 적용: {} → {}", val, op(val));
    }

    // fn은 Fn bound를 만족함
    let doubled = apply_fn(double, 7);
    println!("  fn을 Fn으로: {}", doubled);

    // 클로저는 fn 타입 변수에 저장 불가 (환경 캡처 없으면 가능)
    // 환경 캡처 없는 클로저 → fn 포인터로 강제 변환 가능
    let no_capture: fn(i32) -> i32 = |x| x + 1;
    println!("  캡처 없는 클로저를 fn으로: {}", no_capture(10));
}

fn apply_fn<F: Fn(i32) -> i32>(f: F, x: i32) -> i32 {
    f(x)
}

fn demo_lazy_evaluation() {
    println!("\n  ── 지연 평가 패턴 ──");

    // unwrap_or_else: 값이 필요할 때만 클로저 실행
    let maybe_animal: Option<&str> = None;
    let animal = maybe_animal.unwrap_or_else(|| {
        println!("  기본 동물 생성 중...");  // None일 때만 실행
        "기본 동물"
    });
    println!("  동물: {}", animal);

    // ok_or_else: Result 변환도 지연 평가
    let name: Option<String> = Some(String::from("Simba"));
    let result: Result<String, String> = name.ok_or_else(|| {
        "이름 없음".to_string()  // Some이면 실행 안 됨
    });
    println!("  Result: {:?}", result);

    // 직접 구현: 캐시가 없을 때만 계산
    struct Cache<T, F: Fn() -> T> {
        calc: F,
        value: Option<T>,
    }

    impl<T: std::fmt::Debug, F: Fn() -> T> Cache<T, F> {
        fn new(f: F) -> Self {
            Cache { calc: f, value: None }
        }
        fn get(&mut self) -> &T {
            if self.value.is_none() {
                println!("  캐시 미스 — 계산 실행");
                self.value = Some((self.calc)());
            } else {
                println!("  캐시 히트");
            }
            self.value.as_ref().unwrap()
        }
    }

    let mut cache = Cache::new(|| {
        // 비용이 큰 계산을 흉내
        "동물원 관람객 집계 완료".to_string()
    });

    println!("  첫 접근: {}", cache.get());
    println!("  재접근: {}", cache.get());
}

fn demo_closure_composition() {
    println!("\n  ── 클로저 합성 ──");

    // 두 클로저를 합성하는 함수
    fn compose<A, B, C, F, G>(f: F, g: G) -> impl Fn(A) -> C
    where
        F: Fn(A) -> B,
        G: Fn(B) -> C,
    {
        move |x| g(f(x))
    }

    let to_uppercase = |s: &str| s.to_uppercase();
    let add_prefix   = |s: String| format!("[동물] {}", s);

    let format_name = compose(to_uppercase, add_prefix);

    println!("  {}", format_name("simba"));
    println!("  {}", format_name("donald"));
    println!("  {}", format_name("nagini"));

    // 파이프라인 패턴
    let pipeline: Vec<Box<dyn Fn(f64) -> f64>> = vec![
        Box::new(|x| x * 1.1),   // 10% 증가
        Box::new(|x| x + 5.0),   // 5 추가
        Box::new(|x| x.round()), // 반올림
    ];

    let weight = 190.0f64;
    let result = pipeline.iter().fold(weight, |acc, f| f(acc));
    println!("  체중 {} → 파이프라인 결과: {}", weight, result);
}
