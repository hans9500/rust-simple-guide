// ┌─────────────────────────────────────────────────────────────────────┐
// │  Fn / FnMut / FnOnce 포함 관계                                      │
// │                                                                     │
// │  ╔═══════════════════════════════════════════════════╗              │
// │  ║  FnOnce  (모든 클로저의 기반, 1회 호출)            ║              │
// │  ║  ┌─────────────────────────────────────────────┐  ║              │
// │  ║  │  FnMut  (여러 번 호출, 캡처값 수정 가능)      │  ║              │
// │  ║  │  ┌───────────────────────────────────────┐  │  ║              │
// │  ║  │  │  Fn  (여러 번 호출, 캡처값 읽기만)     │  │  ║              │
// │  ║  │  └───────────────────────────────────────┘  │  ║              │
// │  ║  └─────────────────────────────────────────────┘  ║              │
// │  ╚═══════════════════════════════════════════════════╝              │
// │                                                                     │
// │  Fn 구현 → FnMut, FnOnce 자동 구현                                  │
// │  FnMut 구현 → FnOnce 자동 구현                                      │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  캡처 방식 → 트레이트 연결                                           │
// │                                                                     │
// │  캡처값 읽기(&T)     ──▶  Fn + FnMut + FnOnce  구현                 │
// │  캡처값 수정(&mut T) ──▶  FnMut + FnOnce       구현                 │
// │  캡처값 소비(drop)   ──▶  FnOnce               만 구현              │
// │                                                                     │
// │  함수 인자 바운드 선택:                                               │
// │    fn f<F: Fn()>    ← 가장 제한적, Fn만 수용                        │
// │    fn f<F: FnMut()> ← Fn + FnMut 수용                              │
// │    fn f<F: FnOnce()>← 모든 클로저 수용, 1회만                       │
// │                                                                     │
// │  → 가능한 한 Fn 사용, 필요 시 FnMut, 불가피할 때 FnOnce             │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 10-3: Fn / FnMut / FnOnce 트레이트
// │
// │ 공식 문서: std::ops::{Fn, FnMut, FnOnce}
// │
// │ 세 트레이트의 관계 (상속):
// │   FnOnce — 한 번만 호출 가능, 캡처한 값을 소비(move out)
// │     └── FnMut — 여러 번 호출 가능, 캡처한 값 수정
// │           └── Fn — 여러 번 호출 가능, 캡처한 값 불변 참조
// │
// │ 컴파일러가 자동으로 구현:
// │   - 캡처한 값을 소비 → FnOnce만 구현
// │   - 캡처한 값을 수정 → FnMut + FnOnce 구현
// │   - 캡처한 값을 읽기만 → Fn + FnMut + FnOnce 구현
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [10-3: Fn / FnMut / FnOnce]");
    demo_fn();
    demo_fn_mut();
    demo_fn_once();
    demo_as_parameter();
    demo_return_closure();
}

fn demo_fn() {
    println!("\n  ── Fn: 불변 참조, 여러 번 호출 ──");

    let prefix = String::from("동물원");

    // 읽기만 → Fn 구현
    let announce = |name: &str| {
        println!("  {}: {} 입장!", prefix, name);
    };

    // Fn은 여러 번 호출 가능
    announce("사자 Simba");
    announce("오리 Donald");
    announce("뱀 Nagini");

    // prefix 여전히 유효 (불변 참조 캡처)
    println!("  prefix 유효: {}", prefix);

    // 함수 인자로: Fn bound
    call_twice(&announce, "테스트");
}

fn call_twice<F: Fn(&str)>(f: &F, name: &str) {
    f(name);
    f(name);
}

fn demo_fn_mut() {
    println!("\n  ── FnMut: 가변 참조, 여러 번 호출 ──");

    let mut visitor_count = 0u32;

    // 수정 → FnMut 구현
    let mut record_visit = |animal: &str| {
        visitor_count += 1;
        println!("  방문 #{}: {}", visitor_count, animal);
    };

    record_visit("사자");
    record_visit("오리");
    record_visit("뱀");

    drop(record_visit);
    println!("  총 방문 기록: {}건", visitor_count);

    // FnMut를 받는 함수
    let mut log: Vec<String> = Vec::new();
    apply_three_times(|s: &str| log.push(s.to_string()), "동물원 방문");
    println!("  로그: {:?}", log);
}

fn apply_three_times<F: FnMut(&str)>(mut f: F, s: &str) {
    f(s); f(s); f(s);
}

fn demo_fn_once() {
    println!("\n  ── FnOnce: 소유권 소비, 한 번만 호출 ──");

    let lion_name = String::from("Simba");

    // 소유권 이동(move out) → FnOnce만 구현
    let retire = || {
        // lion_name을 소비(move out)하는 클로저
        println!("  {} 은(는) 은퇴했습니다.", lion_name);
        lion_name  // 소유권 반환 → FnOnce
    };

    let name = retire();  // 한 번만 호출 가능
    // retire();  // 에러: cannot be called more than once

    println!("  은퇴한 동물: {}", name);

    // FnOnce를 받는 함수 — consume_once
    let greeting = String::from("안녕하세요");
    consume_once(|| {
        println!("  인사: {}", greeting);
        // greeting 소비
        drop(greeting);
    });
}

fn consume_once<F: FnOnce()>(f: F) {
    f();  // 한 번만 호출
}

fn demo_as_parameter() {
    println!("\n  ── 함수 파라미터로 사용 ──");

    let animals = vec!["사자", "오리", "뱀", "코끼리", "기린"];

    // Fn — 조건 클로저
    let large_animals = filter_animals(&animals, |a| a.len() >= 3);
    println!("  이름 3자 이상: {:?}", large_animals);

    // FnMut — 변환 클로저
    let mut result = Vec::new();
    transform_animals(&animals, |a| result.push(format!("[{}]", a)));
    println!("  변환 결과: {:?}", result);
}

fn filter_animals<'a, F: Fn(&&str) -> bool>(
    animals: &'a [&str],
    predicate: F,
) -> Vec<&'a str> {
    animals.iter().filter(|a| predicate(a)).copied().collect()
}

fn transform_animals<F: FnMut(&str)>(animals: &[&str], mut f: F) {
    for a in animals { f(a); }
}

fn demo_return_closure() {
    println!("\n  ── 클로저 반환 (impl Fn) ──");

    // 클로저 반환: impl Fn 사용 (Rust 1.26+)
    // Box<dyn Fn> 없이 반환 가능
    let add_n = make_adder(10);
    println!("  make_adder(10)(5) = {}", add_n(5));
    println!("  make_adder(10)(20) = {}", add_n(20));

    let greet = make_greeter("동물원");
    println!("  {}", greet("사자"));
    println!("  {}", greet("오리"));
}

fn make_adder(n: i32) -> impl Fn(i32) -> i32 {
    move |x| x + n
}

fn make_greeter(place: &str) -> impl Fn(&str) -> String + '_ {
    move |animal| format!("{} 에 {} 입장!", place, animal)
}
