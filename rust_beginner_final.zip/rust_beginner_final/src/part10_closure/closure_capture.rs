// ┌─────────────────────────────────────────────────────────────────────┐
// │  캡처 방식 결정 트리 (컴파일러 자동 선택)                             │
// │                                                                     │
// │  클로저가 변수를 어떻게 사용하는가?                                   │
// │                                                                     │
// │       읽기만 한다                                                    │
// │       │  └──────────────────────────────▶  &T  (불변 참조)          │
// │       │                                                             │
// │       수정한다                                                       │
// │       │  └──────────────────────────────▶  &mut T (가변 참조)       │
// │       │                                                             │
// │       소비한다 (drop/move out)                                       │
// │          └──────────────────────────────▶  T  (소유권 이동)         │
// │                                                                     │
// │  move 키워드: 위 규칙 무시하고 강제로 T (소유권 이동)                 │
// │    → 스레드, 반환 클로저에서 필수                                     │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  캡처 방식별 메모리 구조                                              │
// │                                                                     │
// │  ① 불변 참조 (&T)                                                   │
// │  스택: [name: "Simba"] ◀── [클로저: &name]                          │
// │        원본 유지, 동시에 여러 클로저 가능                             │
// │                                                                     │
// │  ② 가변 참조 (&mut T)                                               │
// │  스택: [count: 0] ◀─── [클로저: &mut count]                         │
// │        클로저 살아있는 동안 다른 접근 불가                            │
// │                                                                     │
// │  ③ 소유권 이동 (move)                                               │
// │  스택: [name: 무효] ──move──▶ [클로저: name 소유]                   │
// │        원본 무효, 클로저가 단독 소유                                  │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 10-2: 클로저 캡처 방식
// │
// │ 공식 문서: Rust Reference "Closure expressions"
// │
// │ Rust 컴파일러는 캡처 방식을 자동으로 결정한다:
// │   1. 불변 참조 (&T)   — 가장 제한적, 가능하면 이것
// │   2. 가변 참조 (&mut T)
// │   3. 소유권 이동 (T)  — move 키워드 또는 필요 시
// │
// │ move 키워드: 클로저가 스레드/반환값으로 사용될 때
// │   강제로 소유권을 이동시킨다.
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [10-2: 클로저 캡처 방식]");
    demo_immutable_borrow();
    demo_mutable_borrow();
    demo_move_ownership();
    demo_move_thread();
}

fn demo_immutable_borrow() {
    println!("\n  ── 불변 참조 캡처 ──");

    let lion_name = String::from("Simba");

    // 읽기만 하면 불변 참조(&T)로 캡처
    let greet = || println!("  안녕, {}!", lion_name);

    greet();
    greet();  // 여러 번 호출 가능
    println!("  클로저 호출 후 lion_name: {}", lion_name);  // 여전히 유효
}

fn demo_mutable_borrow() {
    println!("\n  ── 가변 참조 캡처 ──");

    let mut feed_count = 0u32;

    // 수정하면 가변 참조(&mut T)로 캡처
    let mut feed_lion = || {
        feed_count += 1;
        println!("  먹이 {} 회 제공", feed_count);
    };

    feed_lion();
    feed_lion();
    feed_lion();

    // 가변 참조 클로저가 살아있는 동안 feed_count 직접 접근 불가
    drop(feed_lion);  // 클로저 drop → 가변 참조 해제

    println!("  최종 먹이 횟수: {}", feed_count);  // 이제 접근 가능
}

fn demo_move_ownership() {
    println!("\n  ── move 키워드: 소유권 이동 ──");

    let zoo_name = String::from("서울 동물원");

    // move: zoo_name 소유권을 클로저로 이동
    let get_zoo = move || {
        println!("  동물원: {}", zoo_name);
        zoo_name.len()  // 소유권이 있으므로 메서드 사용 가능
    };

    // zoo_name은 이미 이동됨
    // println!("{}", zoo_name);  // 에러: use of moved value

    let len = get_zoo();
    println!("  동물원 이름 길이: {}", len);

    // Copy 타입은 move가 복사처럼 동작
    let capacity = 100u32;
    let is_full = move |count: u32| count >= capacity;  // capacity 복사
    println!("  50마리: {}", is_full(50));
    println!("  100마리: {}", is_full(100));
    println!("  capacity 원본: {}", capacity);  // Copy이므로 여전히 유효
}

fn demo_move_thread() {
    println!("\n  ── move + 스레드 ──");
    use std::thread;

    let animals = vec!["사자", "오리", "뱀"];

    // 스레드에 전달하려면 반드시 move — 스레드가 원본보다 오래 살 수 있기 때문
    let handle = thread::spawn(move || {
        println!("  스레드에서 동물 목록:");
        for animal in &animals {
            println!("    - {}", animal);
        }
        animals.len()  // 소유권 있으므로 반환 가능
    });

    let count = handle.join().unwrap();
    println!("  스레드 결과: 동물 {} 마리", count);
}
