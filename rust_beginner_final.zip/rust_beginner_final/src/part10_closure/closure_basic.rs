// ┌──────────────────────────────────────────────────────────────────
// │ Part 10-1: 클로저 기초
// │
// │ 공식 문서: Rust Book Ch.13.1 "Closures: Anonymous Functions
// │            that Capture Their Environment"
// │
// │ 클로저 문법:
// │   |params| expression
// │   |params| { block }
// │   || expression          (파라미터 없음)
// │
// │ 함수와의 차이:
// │   - 타입 명시 선택적 (추론 가능)
// │   - 주변 변수 캡처 가능
// │   - 변수에 저장 가능
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [10-1: 클로저 기초]");
    demo_syntax();
    demo_type_inference();
    demo_vs_function();
}

fn demo_syntax() {
    println!("\n  ── 클로저 문법 ──");

    // 기본 클로저: |파라미터| 표현식
    let add_one = |x: i32| x + 1;
    println!("  add_one(5) = {}", add_one(5));

    // 블록 형태: 여러 줄
    let describe_animal = |name: &str, age: u32| {
        let status = if age >= 5 { "성체" } else { "새끼" };
        format!("{} ({}살, {})", name, age, status)
    };
    println!("  {}", describe_animal("Simba", 5));
    println!("  {}", describe_animal("Nala", 2));

    // 파라미터 없는 클로저
    let zoo_greeting = || println!("  서울 동물원에 오신 것을 환영합니다!");
    zoo_greeting();
}

fn demo_type_inference() {
    println!("\n  ── 타입 추론 ──");

    // 클로저는 타입을 생략할 수 있다 — 첫 호출 시 타입이 고정됨
    let make_sound = |sound| format!("동물 울음: {}", sound);

    let lion_sound  = make_sound("으르렁");
    let duck_sound  = make_sound("꽥꽥");
    println!("  {}", lion_sound);
    println!("  {}", duck_sound);

    // 명시적 타입도 가능
    let weight_kg = |w: f64| -> String {
        format!("{:.1}kg", w)
    };
    println!("  사자 체중: {}", weight_kg(190.5));

    // 주의: 첫 호출로 타입이 고정됨
    // let ambiguous = |x| x;
    // ambiguous(5);
    // ambiguous("str");  // 에러: 이미 i32로 고정됨
}


// ┌─────────────────────────────────────────────────────────────────────┐
// │  함수(fn) vs 클로저(closure) 비교                                    │
// │                                                                     │
// │  fn double(x: i32) -> i32 { x * 2 }                                │
// │  ┌──────────────────────────────────────────────────────────┐       │
// │  │ 이름 있음 │ 타입 명시 필수 │ 환경 캡처 불가               │       │
// │  └──────────────────────────────────────────────────────────┘       │
// │                                                                     │
// │  let double = |x| x * 2;                                           │
// │  ┌──────────────────────────────────────────────────────────┐       │
// │  │ 이름 없음 │ 타입 추론 가능 │ 주변 변수 캡처 가능           │       │
// │  └──────────────────────────────────────────────────────────┘       │
// │                                                                     │
// │  클로저 문법 형태:                                                   │
// │    |x: i32| -> i32 { x + 1 }   ← 완전한 형태                       │
// │    |x: i32| x + 1               ← 반환 타입 생략                    │
// │    |x| x + 1                    ← 타입 생략 (추론)                  │
// │    || 42                         ← 파라미터 없음                    │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  환경 캡처 — 클로저만의 능력                                         │
// │                                                                     │
// │  let factor = 3;                                                    │
// │  let multiply = |x| x * factor;  ← factor 캡처!                   │
// │                                                                     │
// │  스택 구조:                                                          │
// │  ┌──────────┐    ┌─────────────────────┐                           │
// │  │ factor:3 │◀───│ multiply (클로저)    │                           │
// │  └──────────┘    │  캡처: &factor       │                           │
// │                  └─────────────────────┘                           │
// └─────────────────────────────────────────────────────────────────────┘
fn demo_vs_function() {
    println!("\n  ── 함수 vs 클로저 ──");

    // 함수: 환경 캡처 불가
    fn double_fn(x: i32) -> i32 { x * 2 }

    // 클로저: 환경 캡처 가능
    let multiplier = 3;  // 주변 변수
    let triple_cl = |x: i32| x * multiplier;  // multiplier 캡처

    let values = vec![1, 2, 3, 4, 5];
    let doubled: Vec<i32> = values.iter().map(|&x| double_fn(x)).collect();
    let tripled: Vec<i32> = values.iter().map(|&x| triple_cl(x)).collect();

    println!("  원본:    {:?}", values);
    println!("  2배(fn): {:?}", doubled);
    println!("  3배(cl): {:?}", tripled);

    // 클로저를 변수에 저장 — impl Fn(i32) -> i32 타입
    let operations: Vec<Box<dyn Fn(i32) -> i32>> = vec![
        Box::new(|x| x + 10),
        Box::new(|x| x * 2),
        Box::new(|x| x - 1),
    ];
    let mut result = 5;
    for op in &operations {
        result = op(result);
    }
    // 5 → +10=15 → *2=30 → -1=29
    println!("  5에 연산 적용 결과: {}", result);
}
