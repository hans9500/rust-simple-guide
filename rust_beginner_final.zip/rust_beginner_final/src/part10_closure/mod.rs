// ┌──────────────────────────────────────────────────────────────────
// │ Part 10: 클로저(Closure)
// │
// │ 클로저는 주변 환경(enclosing scope)의 변수를 캡처할 수 있는
// │ 익명 함수다. Rust Book Ch.13 기반.
// └──────────────────────────────────────────────────────────────────

pub mod closure_basic;
pub mod closure_capture;
pub mod closure_traits;
pub mod closure_advanced;
pub mod closure_fn_deep;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 10: 클로저(Closure)");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    closure_basic::run();
    closure_capture::run();
    closure_traits::run();
    closure_advanced::run();
    closure_fn_deep::run();
}
