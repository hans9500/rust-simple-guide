// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 8 심화.  문장/표현식 고급 — 실수 패턴과 컴파일 에러 해부           │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::Lion;

// ─── 심화 1: 세미콜론 실수 패턴 ───────────────────────────────────────────
//
//  가장 흔한 실수: 반환값 뒤에 세미콜론
//
//  fn get_age(lion: &Lion) -> u32 {
//      lion.age();   // ← 에러! ; 로 인해 () 반환
//  }
//  // 에러: mismatched types
//  // expected `u32`, found `()`
//  // note: consider removing this semicolon
//
//  반대 실수: 필요한 곳에 세미콜론 없음
//
//  fn side_effect(lion: &mut Lion) {
//      lion.feed()   // OK: () 반환이므로 세미콜론 없어도 됨
//  }
//  // 단, 코딩 컨벤션상 void 함수 끝엔 ; 권장

fn correct_age(lion: &Lion) -> u32 {
    lion.age()    // 세미콜론 없음 → u32 반환
}

// fn wrong_age(lion: &Lion) -> u32 {
//     lion.age(); // ← 에러: expected u32, found ()
// }

fn demo_semicolon_mistakes() {
    println!("\n  [심화1: 세미콜론 실수]");

    let lion = Lion::new("Simba", 7);

    // 정상
    println!("  correct_age: {}", correct_age(&lion));

    // 블록 표현식에서의 세미콜론
    let with_semi:    () = { lion.age(); };    // () 반환
    let without_semi: u32 = { lion.age() };   // u32 반환
    println!("  with_semi type: () → {:?}", with_semi);
    println!("  without_semi: {}", without_semi);

    // 함수 호출이 표현식 — 결과를 변수에 할당 가능
    let status: String = {
        let mut l = Lion::new("Mufasa", 10);
        l.feed();           // side effect
        l.status()          // 블록의 값 — 이 String이 status에 할당
    };
    println!("  block result: {}", status);
}

// ─── 심화 2: if/match 표현식 타입 불일치 ─────────────────────────────────
//
//  if 표현식의 모든 분기는 같은 타입을 반환해야 한다.
//
//  실수 1: 타입 불일치
//  let x = if true { 1i32 } else { "문자열" };
//  // 에러: if and else have incompatible types
//  // expected `i32`, found `&str`
//
//  실수 2: else 없이 non-() 타입 반환
//  let x = if true { 1i32 };
//  // 에러: mismatched types
//  // expected `()`, found `i32`
//  // note: `if` expressions without `else` evaluate to `()`
//
//  이유:
//    else 없는 if는 조건이 false일 때 () 를 반환
//    then 분기가 i32를 반환하면 () 와 i32가 충돌
//
//  해결:
//  if condition { side_effect(); }  // () 반환 → else 없어도 OK
//  let x = if condition { 1 } else { 0 };  // else 추가

fn demo_if_type_mismatch() {
    println!("\n  [심화2: if/match 타입 불일치]");

    let lion = Lion::new("Simba", 5);

    // 올바른 패턴
    let status: &str = if lion.is_hungry() { "배고픔" } else { "배부름" };
    println!("  if 표현식: {}", status);

    // else 없어도 되는 경우: () 반환
    if lion.age() > 10 {
        println!("  노년 사자");
    }  // else 없음 → () 반환 → OK

    // match의 모든 arm이 같은 타입
    let age_desc: String = match lion.age() {
        0..=2  => "아기".to_string(),
        3..=10 => format!("{}살 성체", lion.age()),
        _      => "노년".to_string(),
    };
    println!("  match: {}", age_desc);

    // ! (never 타입) — 어떤 타입과도 호환
    fn get_or_panic(opt: Option<i32>) -> i32 {
        if let Some(v) = opt {
            v
        } else {
            panic!("없음!")  // ! 타입 → i32와 호환
        }
    }
    println!("  never타입: {}", get_or_panic(Some(42)));
}

// ─── 심화 3: loop의 값 반환 활용 ─────────────────────────────────────────
//
//  공식 Book: loop는 break VALUE로 값을 반환할 수 있다.
//  for와 while은 항상 () 반환.
//
//  유용한 패턴:
//
//  1. 재시도 루프:
//  let result = loop {
//      match try_operation() {
//          Ok(v)  => break v,    // 성공 → 값 반환
//          Err(e) => println!("재시도: {}", e),
//      }
//  };
//
//  2. 입력 받기 (실제 I/O에서):
//  let valid_input = loop {
//      let input = read_line();
//      if is_valid(&input) { break input; }
//      println!("잘못된 입력");
//  };

fn demo_loop_value() {
    println!("\n  [심화3: loop 값 반환]");

    // loop로 처음 소수 찾기
    let mut n = 2u32;
    let first_prime_above_10 = loop {
        if n > 10 && is_prime(n) {
            break n;  // n을 반환
        }
        n += 1;
    };
    println!("  10보다 큰 첫 소수: {}", first_prime_above_10);

    // loop 반환값의 타입
    let result: u32 = loop {
        break 42;
    };
    println!("  loop 반환: {}", result);

    // for/while은 () 반환 — 할당 불가
    let _: () = for _ in 0..3 {};   // for는 ()
    let _: () = while false {};      // while은 ()
    println!("  for/while 반환: ()");
}

fn is_prime(n: u32) -> bool {
    if n < 2 { return false; }
    for i in 2..=(n as f64).sqrt() as u32 {
        if n % i == 0 { return false; }
    }
    true
}

// ─── 심화 4: 표현식 스타일 vs 명령형 스타일 ─────────────────────────────
//
//  Rust는 표현식 언어이므로 표현식 스타일이 더 관용적(idiomatic)이다.
//
//  명령형 스타일:
//  let mut result;
//  if condition { result = a; } else { result = b; }
//
//  표현식 스타일 (더 관용적):
//  let result = if condition { a } else { b };
//
//  명령형 스타일:
//  let mut category = String::new();
//  match age {
//      0..=5  => category = "young".to_string(),
//      6..=12 => category = "adult".to_string(),
//      _      => category = "old".to_string(),
//  }
//
//  표현식 스타일 (더 관용적):
//  let category = match age {
//      0..=5  => "young",
//      6..=12 => "adult",
//      _      => "old",
//  };

fn demo_expression_style() {
    println!("\n  [심화4: 표현식 스타일 (idiomatic)]");

    let lions = vec![
        Lion::new("Simba",  5),
        Lion::new("Mufasa", 14),
        Lion::new("Nala",   3),
    ];

    // 표현식 스타일 — 이터레이터 체이닝
    let hungry_names: Vec<&str> = lions.iter()
        .filter(|l| l.is_hungry())
        .map(|l| l.name())
        .collect();
    println!("  배고픈 사자: {:?}", hungry_names);

    // 표현식으로 초기화
    let total_age: u32 = lions.iter().map(|l| l.age()).sum();
    println!("  총 나이 합계: {}", total_age);

    // 복잡한 초기화도 블록 표현식으로
    let summary: String = {
        let count = lions.len();
        let avg = total_age / count as u32;
        format!("{}마리, 평균 {}살", count, avg)
    };
    println!("  요약: {}", summary);
}

pub fn run() {
    println!("\n══════ Part 8 심화: 문장/표현식 고급 ══════");
    demo_semicolon_mistakes();
    demo_if_type_mismatch();
    demo_loop_value();
    demo_expression_style();
}
