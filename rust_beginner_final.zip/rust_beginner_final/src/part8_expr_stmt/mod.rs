// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 8.  문장(Statement)과 표현식(Expression)                         ║
// ║                                                                       ║
// ║  공식 레퍼런스:                                                         ║
// ║  "Rust is primarily an expression language. Most forms of             ║
// ║   value-producing or effect-causing evaluation are directed by        ║
// ║   the uniform syntax category of expressions."                        ║
// ║                                                                       ║
// ║  expr8_basics  — 표현식 vs 문장, 세미콜론의 역할                        ║
// ║  expr8_blocks  — 블록, if/match 표현식, loop 값 반환                   ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod expr8_basics;
pub mod expr8_blocks;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 8: 문장(Statement)과 표현식(Expression)");
    println!("══════════════════════════════════════════════════════════");
    expr8_basics::run();
    expr8_blocks::run();
    expr_advanced::run();
    expr8_stmt_deep::run();
}
pub mod expr_advanced;
pub mod expr8_stmt_deep;
