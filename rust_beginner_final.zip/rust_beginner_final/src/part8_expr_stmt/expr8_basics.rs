// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 8-1.  표현식(Expression)과 문장(Statement)                       │
// │                                                                       │
// │  표현식(expression): 값을 생성(produce)한다.                            │
// │  문장(statement):   값을 생성하지 않는다. 효과(effect)만 일으킨다.       │
// │                                                                       │
// │  공식 레퍼런스 (두 종류의 문장):                                         │
// │    선언 문장(declaration statement): let, item 선언                    │
// │    표현식 문장(expression statement): 표현식 + ; → () 반환             │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 세미콜론(;)의 정확한 역할 ───────────────────────────────────────────
//
//  ;는 표현식을 표현식 문장(expression statement)으로 바꾼다.
//  결과 타입이 () 가 된다.
//
//  5 + 3        →  표현식. 값 8(i32) 을 생성.
//  5 + 3;       →  표현식 문장. 값 8 을 버린다. () 를 "반환".
//
//  fn add(x: i32, y: i32) -> i32 {
//      x + y        // 표현식 — 값을 반환 (세미콜론 없음)
//  }
//
//  fn add_stmt(x: i32, y: i32) -> i32 {
//      x + y;       // 표현식 문장 — () 반환. i32 기대 → 컴파일 에러!
//  }
//
// ─── for 루프의 () 반환 — 공식 레퍼런스 desugaring ─────────────────────
//
//  공식 레퍼런스가 보여주는 for 루프의 내부 표현:
//
//  for PATTERN in EXPR { BODY }
//
//  →  {
//         let result = match IntoIterator::into_iter(EXPR) {
//             mut iter => 'label: loop {
//                 let mut next;
//                 match Iterator::next(&mut iter) {
//                     Option::Some(val) => next = val,
//                     Option::None      => break,
//                 };
//                 let PATTERN = next;
//                 let () = { BODY };   // ← BODY가 () 타입이어야 함
//             },
//         };
//         result                       // ← result = ()
//     }
//
//  핵심: let () = { BODY };
//  루프 바디의 각 반복은 반드시 () 를 반환해야 한다.
//  println!() 는 () 를 반환하므로 OK.
//  어떤 값을 반환하면 컴파일 에러.
//
// ─── while / for / loop 반환값 ───────────────────────────────────────────
//
//  for   루프: 항상 () 반환
//  while 루프: 항상 () 반환
//  loop  루프: break VALUE 로 값 반환 가능 (유일하게 () 아닐 수 있음)

pub fn run() {
    println!("\n─── Part 8-1: 표현식 vs 문장, 세미콜론 ───");

    // ── 표현식 — 값 생성 ──────────────────────────────────────────────────
    println!("\n  [표현식 — 값 생성]");

    let a = 5;           // let 문장. 오른쪽 5는 표현식.
    let b = a + 3;       // a + 3 은 표현식. 값 8.
    let c = {            // 블록도 표현식. 마지막 줄이 값.
        let x = b * 2;
        x + 1            // 세미콜론 없음 → 이 값(17)이 블록의 값
    };
    println!("  a={}, b={}, c={}", a, b, c);

    // ── 세미콜론 — 표현식 → 표현식 문장 ──────────────────────────────────
    println!("\n  [세미콜론의 역할]");
    let _expr  = { 42 };       // 블록의 값 = 42 (i32)
    let _stmt  = { 42; };      // 42; 는 표현식 문장 → 블록의 값 = ()
    // 위 두 줄은 타입이 다르다: i32 vs ()

    // 함수에서의 반환
    fn with_semicolon(x: i32) -> () {
        let _ = x * 2; // 표현식 문장 — () 반환. 반환 타입 () 이므로 OK.
    }
    fn without_semicolon(x: i32) -> i32 {
        x * 2        // 표현식 — 값 반환. 반환 타입 i32 이므로 OK.
    }
    // fn wrong(x: i32) -> i32 {
    //     x * 2;   // 표현식 문장 → () 반환. i32 기대 → 컴파일 에러!
    // }
    with_semicolon(5);
    println!("  without_semicolon(5) = {}", without_semicolon(5));

    // ── for 루프 — 항상 () ────────────────────────────────────────────────
    println!("\n  [for 루프 — 항상 () 반환]");
    let animals = vec!["사자", "오리", "뱀"];

    // for 루프의 반환값은 ()
    let loop_result: () = for animal in &animals {
        print!("  {} ", animal);
        // 만약 여기서 return 5; 하려 해도, 루프 바디는 () 기대
        // return Some(animal); // 컴파일 에러: expected (), found Option<&&str>
    };
    println!();
    println!("  for 루프 반환: {:?}", loop_result); // ()

    // 각 루프 바디 줄이 () 를 기대한다는 증거:
    // println!() 의 반환값은 ()
    // .push() 의 반환값은 ()
    // 값을 반환하는 표현식을 마지막에 쓰면 컴파일 에러
    let mut collected: Vec<i32> = Vec::new();
    for i in 0..5 {
        collected.push(i * 2);  // push()는 () 반환 → OK
        // i * 2                // 이렇게만 쓰면: expected (), found i32
    }
    println!("  collected: {:?}", collected);

    // ── while 루프 — 항상 () ──────────────────────────────────────────────
    println!("\n  [while 루프 — 항상 () 반환]");
    let mut n = 0;
    let while_result: () = while n < 3 {
        n += 1;
    };
    println!("  while 루프 반환: {:?}", while_result);
    println!("  n = {}", n);

    // ── loop — break로 값 반환 가능 ───────────────────────────────────────
    println!("\n  [loop — break VALUE 로 값 반환]");
    let mut counter = 0;
    let loop_val: i32 = loop {
        counter += 1;
        if counter == 5 {
            break counter * 2;  // 10 반환
        }
    };
    println!("  loop 반환값: {} (counter={})", loop_val, counter);

    // ── return 표현식 ────────────────────────────────────────────────────
    // return은 표현식이지만 발산(diverge)한다 — ! 타입
    // 공식 Book: "return is treated as having the value unit, or ()"
    // 즉 return 이후 코드는 dead code.
    fn early_return(x: i32) -> i32 {
        if x < 0 { return 0; }  // return은 함수를 즉시 종료
        x * 2                   // return이 없으면 이 값 반환
    }
    println!("\n  [return 표현식]");
    println!("  early_return(-1) = {}", early_return(-1));
    println!("  early_return(5)  = {}", early_return(5));
}
