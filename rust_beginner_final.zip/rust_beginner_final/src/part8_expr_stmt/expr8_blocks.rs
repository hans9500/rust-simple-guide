// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 8-2.  블록, if/match 표현식, 함수 반환                            │
// │                                                                       │
// │  블록 { }:   마지막 표현식이 블록의 값. ; 가 있으면 ().                  │
// │  if 표현식:  then/else 양쪽의 타입이 같아야 한다.                        │
// │  match 표현식: 모든 arm의 타입이 같아야 한다.                            │
// └───────────────────────────────────────────────────────────────────────┘

// ─── ExpressionWithBlock 규칙 ─────────────────────────────────────────────
//
//  공식 레퍼런스:
//  "The type of ExpressionWithBlock expressions when used as statements
//   must be the unit type."
//
//  ExpressionWithBlock에는 if, match, loop, while, for, block({}) 이 있다.
//  이것들이 "문장으로 사용"될 때 (즉, 값이 버려질 때) 타입이 () 이어야 한다.
//  단, 세미콜론을 붙이면 명시적으로 값을 버리므로 어떤 타입이든 OK.
//
//  예:
//  if true { 1 }           // ExpressionWithBlock as statement → 에러
//                          // (else 없어서 None arm은 (), then arm은 i32 → 불일치)
//  if true { 1 } else { 2 };  // ; 붙이면 OK (값 버림)
//  if true { 1 } else { 2 }   // 값을 사용하면 OK (표현식)

use crate::part2_patterns::animals::Lion;

pub fn run() {
    println!("\n─── Part 8-2: 블록·if·match 표현식 ───");

    // ── 블록은 표현식 ─────────────────────────────────────────────────────
    println!("\n  [블록 = 표현식]");
    let lion_name: &str = {
        // 블록 안에서 복잡한 계산 가능
        let candidates = vec!["Simba", "Nala", "Mufasa"];
        // 마지막 표현식이 블록의 값 — 세미콜론 없음
        candidates[0]
    };
    println!("  블록 결과: {}", lion_name);

    // 중첩 블록
    let result = {
        let a = { 10 };      // 내부 블록 = 표현식
        let b = { 20 };
        a + b                // 외부 블록의 값
    };
    println!("  중첩 블록: {}", result);

    // ── if는 표현식 ──────────────────────────────────────────────────────
    println!("\n  [if = 표현식]");
    let lion = Lion::new("Simba", 5);

    // if 표현식 — then/else 타입이 같아야 함
    let status: &str = if lion.is_hungry() { "배고픔" } else { "배부름" };
    println!("  if 표현식: {}", status);

    // if/else if/else 체인도 표현식
    let age_group: &str = if lion.age() < 2 {
        "아기"
    } else if lion.age() < 8 {
        "청년"
    } else {
        "노년"
    };
    println!("  나이 그룹: {}", age_group);

    // else 없이 if만 쓰면 () 타입이어야 함
    // let x: i32 = if true { 1 };  // 컴파일 에러: mismatched types
    // else가 없으면 None 경우는 () 반환 → i32 기대와 불일치

    // ── match는 표현식 ────────────────────────────────────────────────────
    println!("\n  [match = 표현식]");
    let pride = vec![
        Lion::new("Simba",  5),
        Lion::new("Mufasa", 14),
        Lion::new("Scar",   9),
    ];

    // match의 모든 arm 타입이 같아야 함 (여기서는 String)
    for lion in &pride {
        let desc: String = match lion.age() {
            0..=5   => format!("{}: 새끼 사자", lion.name()),
            6..=12  => format!("{}: 성인 사자", lion.name()),
            _       => format!("{}: 노년 사자", lion.name()),
        };
        println!("  {}", desc);
    }

    // ── 함수의 마지막 표현식 = 반환값 ────────────────────────────────────
    println!("\n  [함수 반환 — 마지막 표현식]");

    fn classify_lion(lion: &Lion) -> &'static str {
        // 마지막 표현식이 반환값 (return 키워드 불필요)
        match lion.age() {
            0..=5  => "새끼",
            6..=12 => "성인",
            _      => "노년",
        }
        // ; 를 붙이면 () 반환 → &'static str 기대 → 컴파일 에러
    }

    fn lion_info(lion: &Lion) -> String {
        // 조기 반환 (early return)
        if lion.age() == 0 {
            return "신생아".to_string();
        }
        // 정상 경로 — 마지막 표현식 반환
        format!("{} ({}살, {})",
            lion.name(),
            lion.age(),
            classify_lion(lion))
    }

    for lion in &pride {
        println!("  {}", lion_info(lion));
    }

    // ── 발산 표현식(diverging expression) — ! 타입 ───────────────────────
    println!("\n  [발산 표현식 — ! 타입]");
    // panic!, return, break, continue 는 ! 타입을 가진다.
    // ! 는 어떤 타입과도 일치 — 타입 불일치 해결에 사용된다.
    //
    //  let x: i32 = if condition {
    //      42
    //  } else {
    //      panic!("불가능")  // ! 타입 → i32 와 일치
    //  };
    //
    //  let y: String = match opt {
    //      Some(s) => s,
    //      None    => return,  // ! 타입 → String 과 일치
    //  };

    fn safe_divide(a: i32, b: i32) -> i32 {
        if b == 0 {
            panic!("0으로 나눌 수 없음"); // ! 타입 → i32 arm과 일치
        }
        a / b  // i32
    }

    println!("  10 / 2 = {}", safe_divide(10, 2));
    // safe_divide(5, 0) → panic

    // ── 요약 도식 ────────────────────────────────────────────────────────
    println!("\n  [요약]");
    println!("  표현식:  5+3, 블록{{}}, if, match, loop{{ break v }} → 값 반환");
    println!("  문장:    let x=5;, 5+3;, for, while         → () 반환");
    println!("  세미콜론: 표현식 뒤에 ; → 표현식 문장 → () 로 바꿈");
    println!("  for/while: 항상 () 반환 (loop만 break VALUE 가능)");
}
