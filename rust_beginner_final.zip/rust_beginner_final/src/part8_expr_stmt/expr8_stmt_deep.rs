// ┌─────────────────────────────────────────────────────────────────────┐
// │  표현식과 문장 심화 — 실전 패턴과 흔한 실수                           │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  블록이 표현식인 이유 — 값 흐름                                       │
// │                                                                     │
// │  let result = {          ← 블록 시작                                │
// │      let x = compute();  ← 문장 (let)                               │
// │      let y = x * 2;      ← 문장 (let)                               │
// │      x + y               ← 표현식! 세미콜론 없음 → 블록의 값        │
// │  };                      ← result = x + y                          │
// │                                                                     │
// │  ; 하나의 차이:                                                      │
// │    x + y    →  블록 값 = x+y  (i32)                                │
// │    x + y;   →  블록 값 = ()   (unit)                               │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  if / match / loop — 모두 표현식                                     │
// │                                                                     │
// │  ┌─────────────────────────────────────────────────────────┐        │
// │  │  if 표현식         match 표현식       loop 표현식        │        │
// │  │                                                          │        │
// │  │  let x =           let y =           let z =            │        │
// │  │    if b { 1 }         match n {         loop {           │        │
// │  │    else { 2 };          0 => "영",         if done {     │        │
// │  │                         _ => "기타"           break 42;  │        │
// │  │                       };                   }             │        │
// │  │                                          };              │        │
// │  └─────────────────────────────────────────────────────────┘        │
// │                                                                     │
// │  공통: 세미콜론 없는 마지막 줄이 표현식의 값                          │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  함수 반환값 — 표현식 규칙 적용                                       │
// │                                                                     │
// │  fn max(a: i32, b: i32) -> i32 {                                    │
// │      if a > b { a }    ← a가 반환값 (세미콜론 없음)                  │
// │      else    { b }     ← b가 반환값 (세미콜론 없음)                  │
// │  }                                                                  │
// │                                                                     │
// │  return 키워드는 조기 반환 시:                                        │
// │  fn find(v: &[i32], target: i32) -> Option<usize> {                 │
// │      for (i, &x) in v.iter().enumerate() {                          │
// │          if x == target { return Some(i); }  ← 조기 반환            │
// │      }                                                              │
// │      None   ← 마지막 표현식                                          │
// │  }                                                                  │
// └─────────────────────────────────────────────────────────────────────┘

pub fn run() {
    println!("\n  [표현식과 문장 심화]");
    demo_block_as_expression();
    demo_if_match_loop();
    demo_return_patterns();
    demo_common_mistakes();
}

fn demo_block_as_expression() {
    println!("\n  ── 블록 표현식 ──");

    // 블록이 값을 반환
    let description = {
        let name = "Simba";
        let age  = 5u32;
        let status = if age >= 5 { "성체" } else { "새끼" };
        format!("{} ({}살, {})", name, age, status)  // 세미콜론 없음
    };
    println!("  블록 결과: {}", description);

    // 중첩 블록
    let total = {
        let lions = { let a = 3; let b = 2; a + b };  // 5
        let ducks = { let a = 10; let b = 3; a - b }; // 7
        lions + ducks  // 12
    };
    println!("  중첩 블록 합계: {}", total);

    // 블록으로 임시 스코프 생성
    let result = {
        let temp = vec![1, 2, 3, 4, 5];
        let sum: i32 = temp.iter().sum();
        let avg = sum as f64 / temp.len() as f64;
        avg  // temp는 여기서 drop, avg만 반환
    };
    println!("  평균: {:.1} (temp 이미 drop됨)", result);
}

fn demo_if_match_loop() {
    println!("\n  ── if/match/loop 표현식 ──");

    let score = 85u32;

    // if 표현식 — 삼항 연산자 역할
    let grade = if score >= 90 { "A" }
                else if score >= 80 { "B" }
                else if score >= 70 { "C" }
                else { "F" };
    println!("  점수 {} → 등급: {}", score, grade);

    // match 표현식
    let desc = match score / 10 {
        10 | 9 => "최우수",
        8      => "우수",
        7      => "보통",
        _      => "미흡",
    };
    println!("  match 결과: {}", desc);

    // loop + break 값 반환
    let mut count = 0u32;
    let found = loop {
        count += 1;
        if count * count > 50 {
            break count;  // count가 loop의 값
        }
    };
    println!("  loop 결과: {}² > 50, count={}", found, found);

    // while은 값 반환 불가 — 항상 ()
    // for도 값 반환 불가 — 항상 ()
}

fn demo_return_patterns() {
    println!("\n  ── 함수 반환 패턴 ──");

    fn classify_age(age: u32) -> &'static str {
        if age < 1  { return "신생아"; }  // 조기 반환
        if age < 5  { return "새끼"; }
        if age < 10 { return "청소년"; }
        "성체"  // 마지막 표현식 — return 불필요
    }

    for age in [0, 2, 7, 15] {
        println!("  {}살: {}", age, classify_age(age));
    }

    // 여러 값 반환 — 튜플 표현식
    fn min_max(v: &[i32]) -> (i32, i32) {
        let min = *v.iter().min().unwrap();
        let max = *v.iter().max().unwrap();
        (min, max)  // 튜플이 표현식
    }
    let (min, max) = min_max(&[3, 1, 4, 1, 5, 9]);
    println!("  min={}, max={}", min, max);
}

fn demo_common_mistakes() {
    println!("\n  ── 흔한 실수 ──");

    // 실수 1: if-else 타입 불일치
    // let x = if true { 1 } else { "문자" }; // 에러!
    println!("  if-else 양쪽 타입이 같아야 함");

    // 실수 2: 세미콜론 실수
    fn wrong_return() -> i32 {
        let x = 5;
        x + 1  // 세미콜론 없어야 반환됨
    }
    println!("  세미콜론 없는 마지막 표현식이 반환값: {}", wrong_return());

    // 실수 3: match arm 타입 불일치
    let n = 1u32;
    let _result = match n {
        0 => 0i32,
        _ => 42i32,  // 모든 arm이 i32
    };
    println!("  match arm 타입 통일 필요");
}
