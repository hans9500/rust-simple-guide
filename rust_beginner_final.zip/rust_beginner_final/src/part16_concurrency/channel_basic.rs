// ┌──────────────────────────────────────────────────────────────────
// │ Part 16-1: 채널(mpsc) 기초
// │
// │ 공식 문서: Rust Book Ch.16.2
// │            std::sync::mpsc (multiple producer, single consumer)
// │
// │ mpsc: 여러 송신자(tx) → 하나의 수신자(rx)
// │
// │ Rust 채널의 특성:
// │   - 송신(tx)은 Clone 가능 → 여러 스레드에서 공유
// │   - 수신(rx)은 하나만 — 단일 소비자
// │   - 채널로 전달하는 값은 Send를 구현해야
// │   - tx drop 시 rx.recv()는 Err 반환 (채널 닫힘)
// └──────────────────────────────────────────────────────────────────

use std::sync::mpsc;
use std::thread;
use std::time::Duration;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  mpsc 채널 구조 (multiple producer, single consumer)                │
// │                                                                     │
// │  let (tx, rx) = mpsc::channel();                                    │
// │                                                                     │
// │  스레드1 ──tx.send()──┐                                             │
// │  스레드2 ──tx.send()──┼──▶ [ 채널 버퍼 ] ──▶ rx.recv() ── 수신자   │
// │  스레드3 ──tx.send()──┘                                             │
// │                                                                     │
// │  tx: Clone 가능 → 여러 송신자                                        │
// │  rx: Clone 불가 → 단일 수신자                                        │
// │                                                                     │
// │  tx 모두 drop → rx.recv() → Err(RecvError) (채널 닫힘)              │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [16-1: 채널(mpsc) 기초]");
    demo_basic_channel();
    demo_multiple_values();
    demo_multiple_senders();
}

fn demo_basic_channel() {
    println!("\n  ── 기본 채널 ──");

    // mpsc::channel() → (Sender<T>, Receiver<T>)
    let (tx, rx) = mpsc::channel::<String>();

    // 스레드에서 송신
    thread::spawn(move || {
        let messages = vec!["사자 입장", "오리 입장", "뱀 퇴장"];
        for msg in messages {
            tx.send(msg.to_string()).expect("송신 실패");
            thread::sleep(Duration::from_millis(10));
        }
        // tx drop → 채널 닫힘 → rx.recv()가 Err 반환
    });

    // 메인 스레드에서 수신
    // recv(): 블로킹 — 메시지 올 때까지 대기
    // 채널 닫히면 Err(RecvError) 반환
    while let Ok(msg) = rx.recv() {
        println!("  수신: {}", msg);
    }
    println!("  채널 닫힘 (tx drop됨)");
}

fn demo_multiple_values() {
    println!("\n  ── 수신자를 이터레이터로 ──");

    let (tx, rx) = mpsc::channel();

    thread::spawn(move || {
        for animal in ["사자", "오리", "뱀", "코끼리"] {
            tx.send(animal).unwrap();
        }
        // tx drop → for 루프 종료
    });

    // rx를 이터레이터처럼 사용
    // 채널이 닫힐 때까지 반복
    let received: Vec<&str> = rx.iter().collect();
    println!("  받은 목록: {:?}", received);
}

fn demo_multiple_senders() {
    println!("\n  ── 복수 송신자 (mpsc 핵심) ──");

    let (tx, rx) = mpsc::channel::<(usize, String)>();

    // tx를 clone해서 여러 스레드에 배포
    let mut handles = vec![];
    for i in 0..4 {
        let tx_clone = tx.clone();
        let handle = thread::spawn(move || {
            let animal = ["사자", "오리", "뱀", "코끼리"][i];
            tx_clone.send((i, format!("스레드{}: {} 완료", i, animal)))
                .expect("송신 실패");
        });
        handles.push(handle);
    }

    // 원본 tx drop — 모든 clone도 drop돼야 채널 닫힘
    drop(tx);

    for handle in handles {
        handle.join().unwrap();
    }

    // 순서는 비결정적
    let mut results: Vec<(usize, String)> = rx.iter().collect();
    results.sort_by_key(|(i, _)| *i);  // 정렬해서 출력
    for (_, msg) in results {
        println!("  {}", msg);
    }

    println!("\n  ── try_recv: 비블로킹 수신 ──");
    let (tx2, rx2) = mpsc::channel::<u32>();
    tx2.send(42).unwrap();
    drop(tx2);

    loop {
        match rx2.try_recv() {
            Ok(v)                           => println!("  즉시 수신: {}", v),
            Err(mpsc::TryRecvError::Empty)  => { println!("  아직 없음"); break; }
            Err(mpsc::TryRecvError::Disconnected) => { println!("  채널 닫힘"); break; }
        }
    }
}
