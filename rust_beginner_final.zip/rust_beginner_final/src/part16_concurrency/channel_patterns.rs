// ┌──────────────────────────────────────────────────────────────────
// │ Part 16-2: 채널 실전 패턴
// │
// │ - 생산자/소비자 패턴
// │ - sync_channel: 버퍼 크기 제한
// │ - 채널로 Result 전달
// └──────────────────────────────────────────────────────────────────

use std::sync::mpsc;
use std::thread;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  생산자/소비자 패턴                                                   │
// │                                                                     │
// │  ┌──────────┐  tx.send()   ┌──────────┐  rx.recv()  ┌──────────┐  │
// │  │ 생산자   │ ──────────▶  │  채널    │ ──────────▶ │ 소비자   │  │
// │  │ (스레드) │              │  버퍼    │             │ (스레드) │  │
// │  └──────────┘              └──────────┘             └──────────┘  │
// │                                                                     │
// │  sync_channel(n): 버퍼 n개 제한                                      │
// │    버퍼 가득 참 → tx.send() 블로킹 → 배압(backpressure) 효과        │
// │                                                                     │
// │  채널로 Result 전달:                                                  │
// │    tx.send(Ok(value))  /  tx.send(Err(ZooError::...))               │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [16-2: 채널 실전 패턴]");
    demo_producer_consumer();
    demo_sync_channel();
    demo_result_channel();
}

fn demo_producer_consumer() {
    println!("\n  ── 생산자/소비자 패턴 ──");

    #[derive(Debug)]
    struct AnimalData {
        name:    String,
        species: String,
        age:     u32,
    }

    let (tx, rx) = mpsc::channel::<AnimalData>();

    // 생산자: 데이터 생성 후 채널로 전송
    let producer = thread::spawn(move || {
        let raw = vec![
            ("Simba",   "사자",   5u32),
            ("Donald",  "오리",   3),
            ("Nagini",  "뱀",     8),
            ("Dumbo",   "코끼리", 10),
        ];
        for (name, species, age) in raw {
            tx.send(AnimalData {
                name:    name.to_string(),
                species: species.to_string(),
                age,
            }).unwrap();
        }
        println!("  생산자: 완료");
    });

    // 소비자: 채널에서 받아 처리
    let consumer = thread::spawn(move || {
        let mut total_age = 0u32;
        let mut count = 0;
        for data in rx {
            println!("  소비: {} ({}) {}살", data.name, data.species, data.age);
            total_age += data.age;
            count += 1;
        }
        println!("  평균 나이: {:.1}살", total_age as f64 / count as f64);
    });

    producer.join().unwrap();
    consumer.join().unwrap();
}

fn demo_sync_channel() {
    println!("\n  ── sync_channel: 버퍼 크기 제한 ──");

    // sync_channel(n): 버퍼 n개. 버퍼 가득 차면 송신 블로킹
    // channel()은 버퍼 무제한 (메모리 허용 한도)
    let (tx, rx) = mpsc::sync_channel::<u32>(2);  // 버퍼 2개

    let sender = thread::spawn(move || {
        for i in 0..5 {
            println!("  송신 시도: {}", i);
            tx.send(i).unwrap();  // 버퍼 가득 차면 여기서 블로킹
            println!("  송신 완료: {}", i);
        }
    });

    // 조금 늦게 수신 — 버퍼 흐름 관찰
    thread::sleep(std::time::Duration::from_millis(20));
    for v in rx {
        println!("  수신: {}", v);
    }

    sender.join().unwrap();
}

fn demo_result_channel() {
    println!("\n  ── 채널로 Result 전달 ──");

    #[derive(Debug)]
    enum ZooError { ParseError(String), InvalidAge(u32) }

    let (tx, rx) = mpsc::channel::<Result<(String, u32), ZooError>>();

    let raw_data = vec!["Simba,5", "Donald,abc", "Nagini,150", "Dumbo,10"];

    let sender = thread::spawn(move || {
        for line in raw_data {
            let parts: Vec<&str> = line.split(',').collect();
            let result = if parts.len() == 2 {
                match parts[1].parse::<u32>() {
                    Ok(age) if age > 100 =>
                        Err(ZooError::InvalidAge(age)),
                    Ok(age) =>
                        Ok((parts[0].to_string(), age)),
                    Err(_) =>
                        Err(ZooError::ParseError(parts[1].to_string())),
                }
            } else {
                Err(ZooError::ParseError(line.to_string()))
            };
            tx.send(result).unwrap();
        }
    });

    sender.join().unwrap();

    let mut ok_count = 0;
    let mut err_count = 0;
    for result in rx {
        match result {
            Ok((name, age)) => {
                println!("  OK: {} {}살", name, age);
                ok_count += 1;
            }
            Err(ZooError::ParseError(s)) => {
                println!("  ParseError: '{}'", s);
                err_count += 1;
            }
            Err(ZooError::InvalidAge(age)) => {
                println!("  InvalidAge: {}살", age);
                err_count += 1;
            }
        }
    }
    println!("  성공: {}, 실패: {}", ok_count, err_count);
}
