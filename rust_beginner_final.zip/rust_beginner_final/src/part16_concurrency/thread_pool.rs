// ┌──────────────────────────────────────────────────────────────────
// │ Part 16-3: 스레드 풀 패턴 (채널 활용)
// │
// │ 채널 + 스레드로 간단한 작업 분산 처리
// └──────────────────────────────────────────────────────────────────

use std::sync::{mpsc, Arc, Mutex};
use std::thread;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  채널 기반 스레드 풀 구조                                             │
// │                                                                     │
// │          ┌─────────────────────────────┐                           │
// │  작업 →  │  Arc<Mutex<Receiver<Job>>>  │                           │
// │          └──────┬──────────────────────┘                           │
// │                 │                                                   │
// │          ┌──────┴──────┐                                           │
// │        워커0           워커1   (여러 스레드가 같은 rx 공유)          │
// │          │               │                                          │
// │      job.run()        job.run()                                     │
// │                                                                     │
// │  Arc: 여러 스레드가 rx 공유                                          │
// │  Mutex: 한 번에 하나의 워커만 작업 가져감                            │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [16-3: 스레드 풀 패턴]");
    demo_simple_pool();
    demo_work_stealing();
}

fn demo_simple_pool() {
    println!("\n  ── 간단한 작업 분산 ──");

    let num_workers = 3;
    let (tx, rx) = mpsc::channel::<(usize, String)>();

    // rx를 Arc<Mutex>로 감싸서 여러 스레드가 공유
    let rx = Arc::new(Mutex::new(rx));
    let mut handles = vec![];

    for worker_id in 0..num_workers {
        let rx = Arc::clone(&rx);
        let handle = thread::spawn(move || {
            loop {
                // Mutex로 rx 잠금 후 작업 가져오기
                let msg = {
                    let rx = rx.lock().unwrap();
                    rx.try_recv()
                };
                match msg {
                    Ok((job_id, task)) => {
                        println!("  워커{}: job{} '{}' 처리 중",
                            worker_id, job_id, task);
                        thread::sleep(std::time::Duration::from_millis(5));
                    }
                    Err(mpsc::TryRecvError::Empty) => {
                        thread::sleep(std::time::Duration::from_millis(1));
                    }
                    Err(mpsc::TryRecvError::Disconnected) => break,
                }
            }
        });
        handles.push(handle);
    }

    // 작업 전송
    let tasks = ["사자 먹이", "오리 관리", "뱀 검진", "코끼리 목욕", "기린 측정"];
    for (i, task) in tasks.iter().enumerate() {
        tx.send((i, task.to_string())).unwrap();
    }
    drop(tx);  // 모든 작업 전송 완료 → 채널 닫기

    for h in handles { h.join().unwrap(); }
    println!("  모든 작업 완료");
}

fn demo_work_stealing() {
    println!("\n  ── 결과 수집 패턴 ──");

    // 작업 채널 + 결과 채널
    let (job_tx, job_rx) = mpsc::channel::<(usize, u32)>();
    let (res_tx, res_rx) = mpsc::channel::<(usize, u64)>();

    let job_rx = Arc::new(Mutex::new(job_rx));

    // 워커 2개
    for _ in 0..2 {
        let job_rx  = Arc::clone(&job_rx);
        let res_tx  = res_tx.clone();
        thread::spawn(move || {
            loop {
                let job = { job_rx.lock().unwrap().try_recv() };
                match job {
                    Ok((id, n)) => {
                        // 피보나치 계산 (예시 작업)
                        let result = fibonacci(n);
                        res_tx.send((id, result)).unwrap();
                    }
                    Err(mpsc::TryRecvError::Empty) => {
                        thread::sleep(std::time::Duration::from_millis(1));
                    }
                    Err(mpsc::TryRecvError::Disconnected) => break,
                }
            }
        });
    }
    drop(res_tx);  // 원본 res_tx drop

    // 작업 전송
    let jobs = vec![(0u32, 10u32), (1, 20), (2, 15), (3, 25), (4, 5)];
    let job_count = jobs.len();
    for (id, n) in jobs {
        job_tx.send((id as usize, n)).unwrap();
    }
    drop(job_tx);

    // 결과 수집
    let mut results: Vec<(usize, u64)> = res_rx.iter().take(job_count).collect();
    results.sort_by_key(|(id, _)| *id);
    for (id, result) in results {
        println!("  job{}: fib 결과 = {}", id, result);
    }
}

fn fibonacci(n: u32) -> u64 {
    match n {
        0 => 0,
        1 => 1,
        _ => {
            let mut a = 0u64;
            let mut b = 1u64;
            for _ in 2..=n {
                let c = a + b;
                a = b;
                b = c;
            }
            b
        }
    }
}
