// ┌──────────────────────────────────────────────────────────────────
// │ Part 16-4: Send / Sync / 동시성 안전 패턴
// │
// │ 공식 문서: Rust Book Ch.16.4
// │
// │ Send:  값을 다른 스레드로 이동(move) 가능
// │ Sync:  &T를 다른 스레드로 공유 가능 (T: Sync ↔ &T: Send)
// │
// │ 대부분 타입은 자동으로 Send + Sync
// │ 예외: Rc<T>(→ Arc), RefCell<T>(→ Mutex), raw pointer
// └──────────────────────────────────────────────────────────────────

use std::sync::{Arc, Mutex, RwLock};
use std::thread;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  Send / Sync 관계도                                                  │
// │                                                                     │
// │  T: Send  → 값을 다른 스레드로 이동(move) 가능                       │
// │  T: Sync  → &T를 다른 스레드로 공유 가능                             │
// │           → T: Sync  ↔  &T: Send                                  │
// │                                                                     │
// │  타입별:                                                             │
// │    i32, String, Vec<T>       → Send ✅  Sync ✅                    │
// │    Arc<T>  (T:Send+Sync)     → Send ✅  Sync ✅                    │
// │    Mutex<T>(T:Send)          → Send ✅  Sync ✅                    │
// │    Rc<T>                     → Send ❌  Sync ❌                    │
// │    RefCell<T>                → Send ✅  Sync ❌                    │
// │    *mut T (raw ptr)          → Send ❌  Sync ❌                    │
// │                                                                     │
// │  컴파일러가 자동으로 구현 (unsafe 없이 직접 구현 불가)               │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [16-4: Send/Sync & 동시성 안전 패턴]");
    demo_send_sync();
    demo_mutex_patterns();
    demo_rwlock_pattern();
    demo_deadlock_avoidance();
}

fn demo_send_sync() {
    println!("\n  ── Send / Sync 개념 ──");

    // Send: 스레드 간 이동 가능
    // String, Vec, Arc, Mutex<T> 등 대부분의 타입
    let name = String::from("Simba");  // String: Send
    let handle = thread::spawn(move || {
        println!("  다른 스레드: {}", name);  // name이 이동됨
    });
    handle.join().unwrap();

    // Rc<T>는 Send 아님 → 스레드 간 이동 불가
    // Arc<T>를 사용해야 함
    let count = Arc::new(Mutex::new(0u32));
    let count2 = Arc::clone(&count);
    thread::spawn(move || {
        *count2.lock().unwrap() += 1;
    }).join().unwrap();
    println!("  Arc<Mutex> count: {}", count.lock().unwrap());

    println!("\n  Send/Sync 요약:");
    println!("  String, Vec, i32 등 → Send + Sync ✅");
    println!("  Arc<T>              → Send + Sync (T: Send+Sync 이면) ✅");
    println!("  Mutex<T>            → Send + Sync (T: Send 이면) ✅");
    println!("  Rc<T>               → Send ❌ Sync ❌");
    println!("  RefCell<T>          → Send ✅ Sync ❌");
    println!("  *mut T (raw ptr)    → Send ❌ Sync ❌");
}

fn demo_mutex_patterns() {
    println!("\n  ── Mutex 패턴 ──");

    // 여러 스레드에서 공유 상태 수정
    let zoo = Arc::new(Mutex::new(vec![
        "사자".to_string(),
        "오리".to_string(),
    ]));

    let mut handles = vec![];
    for animal in ["뱀", "코끼리", "기린"] {
        let zoo = Arc::clone(&zoo);
        let handle = thread::spawn(move || {
            let mut list = zoo.lock().unwrap();
            list.push(animal.to_string());
        });
        handles.push(handle);
    }

    for h in handles { h.join().unwrap(); }

    let mut final_list = zoo.lock().unwrap().clone();
    final_list.sort();
    println!("  최종 동물 목록: {:?}", final_list);

    // Mutex 잠금 오염(poisoning) — 개념 설명
    // 실제 panic!으로 오염시키면 Windows 디버거가 crash로 인식하므로
    // 개념만 설명하고 is_poisoned() API를 보여줌
    let normal = Arc::new(Mutex::new(42u32));
    println!("  오염 여부 (정상): {}", normal.is_poisoned());

    // 오염이 발생하는 상황:
    // thread::spawn(move || {
    //     let _guard = mutex.lock().unwrap();
    //     panic!(...);  // ← 여기서 Mutex가 오염됨
    // }).join();
    // 이후 mutex.lock() → Err(PoisonError)
    // 복구: mutex.lock().unwrap_or_else(|e| e.into_inner())

    println!("  [poisoning 개념]");
    println!("  스레드가 Mutex 잠금 중 패닉 → Mutex 오염(poisoned)");
    println!("  이후 lock() → Err(PoisonError<Guard>)");
    println!("  복구: .unwrap_or_else(|e| e.into_inner()) 로 값 접근 가능");
    println!("  방지: 잠금 범위를 최소화, panic! 지점을 잠금 밖으로");
}

fn demo_rwlock_pattern() {
    println!("\n  ── RwLock: 읽기 다수, 쓰기 단수 ──");

    let config = Arc::new(RwLock::new(vec![
        ("zoo_name", "서울 동물원"),
        ("capacity", "500"),
    ]));

    // 여러 읽기 스레드 동시 실행
    let mut read_handles = vec![];
    for i in 0..3 {
        let cfg = Arc::clone(&config);
        read_handles.push(thread::spawn(move || {
            let data = cfg.read().unwrap();  // 읽기 잠금 — 동시 가능
            println!("  읽기 스레드{}: {} 항목", i, data.len());
        }));
    }
    for h in read_handles { h.join().unwrap(); }

    // 쓰기 스레드 — 단독 접근
    {
        let mut data = config.write().unwrap();
        data.push(("updated", "true"));
        println!("  쓰기 후: {} 항목", data.len());
    }

    println!("  Mutex vs RwLock:");
    println!("  Mutex:  모든 접근 단독 — 단순, 안전");
    println!("  RwLock: 읽기 동시 가능 — 읽기 많을 때 성능 유리");
}

fn demo_deadlock_avoidance() {
    println!("\n  ── 데드락 방지 패턴 ──");

    // 데드락: A가 lock1을 잡고 lock2를 기다리고
    //         B가 lock2를 잡고 lock1을 기다리면 → 영원히 대기
    // 방지: 항상 같은 순서로 잠금

    let lock1 = Arc::new(Mutex::new("먹이"));
    let lock2 = Arc::new(Mutex::new("물"));

    let l1a = Arc::clone(&lock1);
    let l2a = Arc::clone(&lock2);
    let h1 = thread::spawn(move || {
        let _a = l1a.lock().unwrap();  // 항상 lock1 먼저
        let _b = l2a.lock().unwrap();  // 그 다음 lock2
        println!("  스레드1: 먹이와 물 획득");
    });

    let l1b = Arc::clone(&lock1);
    let l2b = Arc::clone(&lock2);
    let h2 = thread::spawn(move || {
        let _a = l1b.lock().unwrap();  // 같은 순서: lock1 먼저
        let _b = l2b.lock().unwrap();
        println!("  스레드2: 먹이와 물 획득");
    });

    h1.join().unwrap();
    h2.join().unwrap();

    println!("\n  데드락 방지 규칙:");
    println!("  1. 잠금 순서를 항상 일정하게 유지");
    println!("  2. 잠금 유지 시간을 최소화 (블록 범위 줄이기)");
    println!("  3. try_lock()으로 타임아웃 처리");
    println!("  4. 가능하면 채널로 대체 (채널 = 데드락 위험 없음)");
}
