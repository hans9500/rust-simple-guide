// ┌──────────────────────────────────────────────────────────────────
// │ Part 16: 동시성 — 채널 & 스레드 간 통신
// │ 공식 문서: Rust Book Ch.16
// └──────────────────────────────────────────────────────────────────
pub mod channel_basic;
pub mod channel_patterns;
pub mod thread_pool;
pub mod concurrency_advanced;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 16: 동시성 — 채널 & 스레드 간 통신");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    channel_basic::run();
    channel_patterns::run();
    thread_pool::run();
    concurrency_advanced::run();
}
