// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴12: 라이프타임 + impl<'a>                                          │
// │                                                                       │
// │  struct 필드에 참조(&str, &T 등)가 있으면 impl 블록에도 'a 가 필요하다.  │
// │  impl<'a> Keeper<'a>                                                   │
// │   ↑                ↑                                                  │
// │   'a 파라미터 선언   'a 를 사용하는 타입                                 │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 메모리 구조 도식 ─────────────────────────────────────────────────────
//
//  struct Keeper<'a> {
//      name:   &'a str,    // 외부 문자열을 빌림
//      animal: &'a Lion,   // 외부 Lion을 빌림
//  }
//
//  스택 (Keeper)              다른 곳 (소유자)
//  ┌──────────────────┐       ┌─────────────────────┐
//  │ name_ptr  (8바이트)──────▶│ "사육사 김씨" (힙)   │
//  │ name_len  (8바이트)│       └─────────────────────┘
//  │ animal_ptr(8바이트)──────▶│ Lion { ... } (스택)  │
//  └──────────────────┘       └─────────────────────┘
//
//  Keeper는 데이터를 소유하지 않는다. 빌릴 뿐이다.
//  원본 데이터가 살아있는 동안만 Keeper가 유효하다.
//  'a = 원본 데이터의 수명 (name과 animal 중 짧은 쪽)

use crate::part2_patterns::animals::Lion;
use crate::part2_patterns::pattern2_trait::Sound;

pub struct Keeper<'a> {
    pub name:   &'a str,
    pub animal: &'a Lion,
}

impl<'a> Keeper<'a> {
    pub fn new(name: &'a str, animal: &'a Lion) -> Self {
        Keeper { name, animal }
    }

    // 반환값이 'a 수명임을 명시 — self의 수명('b)과 다를 수 있음
    // fn animal_name<'b>(&'b self) -> &'a str  (생략 규칙 3은 'b를 반환하지만
    // 우리는 'a 를 명시해 더 긴 수명을 반환)
    pub fn animal_name(&self) -> &'a str {
        self.animal.name()  // Lion.name()은 &'a str 반환
    }

    pub fn introduce(&self) {
        println!("  사육사 {} → {} 담당",
            self.name, self.animal.name());
    }
}

// 라이프타임 + 제네릭 동시 사용
// 'a: 빌린 keeper_name의 수명
// T: Sound — 소리를 낼 수 있는 동물 (소유)
pub struct ZooBadge<'a, T: Sound> {
    pub keeper_name: &'a str,   // 빌림 — 수명 'a
    pub animal:      T,         // 소유 — 수명은 ZooBadge와 같음
}

impl<'a, T: Sound> ZooBadge<'a, T> {
    pub fn new(keeper_name: &'a str, animal: T) -> Self {
        ZooBadge { keeper_name, animal }
    }
    pub fn show(&self) {
        println!("  배지: {} 담당 → {}",
            self.keeper_name, self.animal.make_sound());
    }
}

pub fn run() {
    println!("\n─── 패턴12: 라이프타임 + impl<'a> ───");

    let simba       = Lion::new("Simba", 5);
    let keeper_name = String::from("사육사 김씨");

    {
        let keeper = Keeper::new(&keeper_name, &simba);
        keeper.introduce();
        // animal_name()은 'a 수명 → simba가 살아있는 동안 유효
        let name: &str = keeper.animal_name();
        println!("  담당 동물: {}", name);
    }   // keeper drop — simba와 keeper_name은 여전히 유효

    // 라이프타임 + 제네릭
    use crate::part2_patterns::animals::Duck;
    let badge = ZooBadge::new("이씨 사육사", Duck::new("Donald", 3));
    badge.show();
}
