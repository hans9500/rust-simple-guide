// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 3.  표준 trait 구현                                              ║
// ║                                                                       ║
// ║  패턴8   Default / Drop                                                ║
// ║  패턴9   From / Into + 고아 규칙 + newtype                             ║
// ║  패턴10  연산자 오버로딩 (PartialEq, Add)                              ║
// ║  패턴11  Iterator 구현                                                 ║
// ║  패턴12  라이프타임 + impl<'a>                                         ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod pattern8_default_drop;
pub mod pattern9_from_into;
pub mod pattern10_operator;
pub mod pattern11_iterator;
pub mod pattern12_lifetime_impl;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 3: 표준 trait 구현");
    println!("══════════════════════════════════════════════════════════");
    pattern8_default_drop::run();
    pattern9_from_into::run();
    pattern10_operator::run();
    pattern11_iterator::run();
    pattern12_lifetime_impl::run();
    std_traits_advanced::run();
    pattern_hash_ord::run();
}
pub mod std_traits_advanced;
pub mod pattern_hash_ord;
