// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 3 심화.  표준 trait 고급 — 실수 패턴과 컴파일 에러 해부            │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::Lion;

// ─── 심화 1: Drop과 Copy는 동시에 구현 불가 ──────────────────────────────
//
//  공식 규칙: Drop을 구현한 타입은 Copy를 구현할 수 없다.
//
//  이유:
//    Copy의 의미: "이 타입은 비트 복사만으로 완전한 복사본이 된다.
//                  drop은 특별한 로직 없이 메모리 해제만 하면 된다."
//    Drop의 의미: "이 타입은 drop될 때 특별한 로직이 필요하다."
//    → 두 의미가 모순. 컴파일러가 거부.
//
//  컴파일 에러:
//  #[derive(Copy, Clone)]
//  struct Handle { id: u32 }
//  impl Drop for Handle {
//      fn drop(&mut self) { ... }
//  }
//  // error[E0184]: the trait `Copy` cannot be implemented for this type;
//  // the type has a destructor
//
//  실제 예: 파일 핸들, 네트워크 소켓 등은 Drop만 구현
//  비트 복사 시 두 핸들이 같은 파일을 가리켜 double-close 위험

#[derive(Debug)]
struct ZooGateHandle {
    gate_id: u32,
}

// Drop을 구현했으므로 Copy 불가
impl Drop for ZooGateHandle {
    fn drop(&mut self) {
        println!("    [ZooGateHandle] 게이트 #{} 닫힘", self.gate_id);
    }
}

// #[derive(Copy)] // ← 에러: the type has a destructor

impl ZooGateHandle {
    fn new(id: u32) -> Self { ZooGateHandle { gate_id: id } }
}

fn demo_drop_copy_conflict() {
    println!("\n  [심화1: Drop과 Copy 동시 구현 불가]");
    {
        let h1 = ZooGateHandle::new(1);
        let h2 = ZooGateHandle::new(2);
        println!("  h1={:?}, h2={:?}", h1, h2);
        // h1과 h2를 복사하려면 Clone을 명시적으로 구현해야 함
        // let h3 = h1; // → h1 moved (Copy 없으므로)
    }
    // drop(h2) → drop(h1) 순서로 Drop 호출
}

// ─── 심화 2: Iterator 실수 — iter() vs into_iter() vs iter_mut() ─────────
//
//  세 가지의 차이:
//
//  .iter()      → &T 반환.   컬렉션을 공유 빌림.  원본 유지.
//  .iter_mut()  → &mut T 반환. 컬렉션을 배타 빌림. 원본 수정 가능.
//  .into_iter() → T 반환.   컬렉션의 소유권을 소비. 원본 무효.
//
//  for 루프에서의 암묵적 변환:
//    for x in &vec       → vec.iter()      (x: &T)
//    for x in &mut vec   → vec.iter_mut()  (x: &mut T)
//    for x in vec        → vec.into_iter() (x: T) → vec 소비
//
//  실수 예:
//  let lions = vec![Lion::new("A",1), Lion::new("B",2)];
//  for lion in lions {              // into_iter → lions 소비
//      println!("{}", lion.name());
//  }
//  println!("{:?}", lions);        // ← 에러: lions moved
//
//  let names: Vec<String> = lions.iter()   // .iter() → &Lion 반환
//      .map(|l| l.name().to_string())      // OK
//      .collect();
//  println!("{:?}", lions);               // lions 여전히 유효

fn demo_iterator_ownership() {
    println!("\n  [심화2: iter() vs into_iter() vs iter_mut()]");

    let lions = vec![
        Lion::new("Simba", 5),
        Lion::new("Nala",  4),
        Lion::new("Scar",  9),
    ];

    // .iter() — &Lion, 원본 유지
    println!("  iter() 결과:");
    let names: Vec<&str> = lions.iter()
        .map(|l| l.name())              // l: &Lion
        .collect();
    println!("  {:?}", names);
    println!("  lions 여전히 유효: {}마리", lions.len()); // 원본 유지

    // .iter_mut() — &mut Lion, 원본 수정
    let mut mut_lions = vec![
        Lion::new("A", 1),
        Lion::new("B", 2),
    ];
    for lion in mut_lions.iter_mut() {  // lion: &mut Lion
        lion.birthday();                // 수정 가능
    }
    println!("  iter_mut 후: {:?}", mut_lions.iter().map(|l| l.age()).collect::<Vec<_>>());

    // .into_iter() — Lion (소유권), 원본 소비
    let to_consume = vec![Lion::new("X", 1), Lion::new("Y", 2)];
    let retired: Vec<String> = to_consume.into_iter()  // Lion 소유권 이동
        .map(|l| l.retire())                            // l: Lion
        .collect();
    println!("  into_iter 결과: {:?}", retired);
    // println!("{:?}", to_consume); // ← 에러: to_consume moved

    // for 루프에서의 차이
    println!("\n  [for 루프 암묵적 변환]");
    let v = vec![1u32, 2, 3];
    for x in &v     { print!("{} ", x); }  // &u32 → x: &u32
    println!("(원본 유지: {:?})", v);

    let mut v2 = vec![1u32, 2, 3];
    for x in &mut v2 { *x *= 2; }         // &mut u32
    println!("  수정 후: {:?}", v2);
}

// ─── 심화 3: From/Into 타입 추론 실패 패턴 ────────────────────────────────
//
//  From<A> for B를 구현하면 Into<B> for A가 자동 생성된다.
//  그러나 .into()를 쓸 때 컴파일러가 타입을 추론하지 못할 수 있다.
//
//  실수:
//  impl From<&str> for Lion { ... }
//
//  let lion = "Simba".into();  // ← 에러: 어떤 타입으로 변환?
//  // 에러: type annotations needed
//  // note: cannot infer type for type parameter `T` in `<str as Into<T>>`
//
//  해결:
//  let lion: Lion = "Simba".into();         // 타입 명시
//  let lion = Lion::from("Simba");           // From 직접 호출 (더 명확)
//  let lion = <Lion as From<&str>>::from("Simba"); // 완전 한정 문법

fn demo_from_into_inference() {
    println!("\n  [심화3: From/Into 타입 추론 실수]");

    // From 직접 호출 — 가장 명확
    let lion1 = Lion::from("Simba");
    println!("  From: {}", lion1.name());

    // Into — 타입 어노테이션 필요
    let lion2: Lion = "Nala".into();     // 타입 명시 → OK
    println!("  Into: {}", lion2.name());

    // let lion3 = "Mufasa".into(); // ← 에러: type annotations needed

    // 완전 한정 문법 (가장 명시적)
    let lion4 = <Lion as From<&str>>::from("Mufasa");
    println!("  완전 한정: {}", lion4.name());

    // 여러 From 구현이 있을 때 — 어느 From을 쓰는지 명확해야 함
    // impl From<u32> for i64 (표준 라이브러리)
    let n: i64 = 42u32.into();           // 타입 명시로 해결
    println!("  u32 → i64: {}", n);
}

// ─── 심화 4: Default와 Option::unwrap_or_default의 차이 ─────────────────
//
//  .unwrap_or(val)         — val을 항상 평가 (즉시 실행)
//  .unwrap_or_else(|| val) — None일 때만 평가 (지연 실행)
//  .unwrap_or_default()    — Default::default()를 None일 때 호출
//
//  성능 차이:
//  let opt: Option<Vec<i32>> = None;
//
//  // 비효율: Some이라도 Vec::new()가 항상 실행됨
//  let v = opt.unwrap_or(Vec::new());
//
//  // 효율적: None일 때만 Vec::new() 실행
//  let v = opt.unwrap_or_else(Vec::new);
//
//  // 더 간결: Default::default() 사용
//  let v = opt.unwrap_or_default();  // Vec::default() = Vec::new()

fn demo_unwrap_or_perf() {
    println!("\n  [심화4: unwrap_or vs unwrap_or_else 차이]");

    let none_lion: Option<Lion> = None;
    let some_lion: Option<Lion> = Some(Lion::new("Simba", 5));

    // unwrap_or: 항상 평가
    // Lion::new("기본", 0) 은 some_lion이 Some이어도 항상 실행됨
    let l1 = some_lion.unwrap_or(Lion::new("기본", 0));
    println!("  unwrap_or (Some): {}", l1.name());

    // unwrap_or_else: 지연 평가
    let l2 = none_lion.unwrap_or_else(|| {
        println!("    (None이라 기본값 생성)");
        Lion::new("기본", 0)
    });
    println!("  unwrap_or_else (None): {}", l2.name());

    // unwrap_or_default: Default 사용
    // Lion이 Default를 구현해야 함
    #[derive(Debug, Default)]
    struct Score { value: u32 }
    let no_score: Option<Score> = None;
    let score = no_score.unwrap_or_default(); // Score { value: 0 }
    println!("  unwrap_or_default: {:?} (value={})", score, score.value); // .value 사용
}

// ─── 심화 5: 라이프타임 + impl<'a> 실수 ─────────────────────────────────
//
//  impl<'a> Struct<'a>에서 가장 흔한 실수:
//
//  1. 반환 수명을 self로 할지 'a로 할지 혼동
//
//  struct Wrapper<'a> { data: &'a str }
//
//  impl<'a> Wrapper<'a> {
//      // 생략 규칙 3: 반환 = self 수명 ('b)
//      fn get_b(&self) -> &str { self.data }
//      // 실제: fn get_b<'b>(&'b self) -> &'b str
//      // → Wrapper가 살아있는 동안만 유효
//
//      // 명시적 'a 반환: data가 사는 동안 유효
//      fn get_a(&self) -> &'a str { self.data }
//      // → Wrapper가 drop돼도 유효 (data('a)가 살아있으면)
//  }
//
//  차이가 중요한 시나리오:
//  let data = "고정된 데이터";
//  let result;
//  {
//      let wrapper = Wrapper { data };
//      result = wrapper.get_a();    // OK: 'a(=data 수명)로 반환
//      // result = wrapper.get_b(); // ← 에러: wrapper drop 후 result 무효
//  }
//  println!("{}", result);          // get_a: OK

struct DataWrapper<'a> {
    data: &'a str,
}

impl<'a> DataWrapper<'a> {
    fn new(data: &'a str) -> Self { DataWrapper { data } }

    // 생략 규칙 3: fn get_self_lifetime<'b>(&'b self) -> &'b str
    fn get_self_lifetime(&self) -> &str {
        self.data
    }

    // 명시적 'a: self가 drop돼도 data가 살아있으면 유효
    fn get_data_lifetime(&self) -> &'a str {
        self.data
    }
}

fn demo_impl_lifetime_mistake() {
    println!("\n  [심화5: impl<'a> 반환 수명 차이]");

    let data = String::from("오래 사는 데이터");

    // get_self_lifetime vs get_data_lifetime 차이 직접 비교
    let wrapper = DataWrapper::new(&data);

    // get_self_lifetime: self('b) 수명 → wrapper가 살아있는 동안만 유효
    let self_result = wrapper.get_self_lifetime();
    println!("  self_lifetime 결과:  {}", self_result); // wrapper 살아있음 → OK

    // get_data_lifetime: 'a 수명 → wrapper drop 후에도 유효
    let data_result = wrapper.get_data_lifetime();
    println!("  data_lifetime 결과:  {}", data_result);

    drop(wrapper); // wrapper 명시적 drop

    // data_result는 data('a)에서 빌림 → wrapper drop 후에도 유효
    println!("  wrapper drop 후에도 data_result 유효: {}", data_result);
    println!("  data 여전히 유효: {}", data);
}

pub fn run() {
    println!("\n══════ Part 3 심화: 표준 trait 고급 ══════");
    demo_drop_copy_conflict();
    demo_iterator_ownership();
    demo_from_into_inference();
    demo_unwrap_or_perf();
    demo_impl_lifetime_mistake();
}
