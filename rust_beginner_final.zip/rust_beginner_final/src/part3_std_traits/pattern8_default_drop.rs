// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴8: Default / Drop                                                 │
// │                                                                       │
// │  Default — 타입의 "기본값"을 정의한다.                                  │
// │    #[derive(Default)]: 모든 필드가 Default이면 자동 구현 가능.           │
// │    수동 구현: 필드 기본값을 직접 지정할 때.                               │
// │    활용: Option::unwrap_or_default(), struct update syntax, 초기화.    │
// │                                                                       │
// │  Drop — 값이 스코프를 벗어날 때 자동 호출된다.                           │
// │    소유권 소비(self)의 마지막 단계가 바로 Drop이다.                       │
// │    파일 핸들, 네트워크 연결, 잠금(lock) 해제에 활용.                     │
// │    주의: Drop과 Copy는 동시에 구현할 수 없다.                            │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Drop 동작 도식 ───────────────────────────────────────────────────────
//
//  {
//      let g1 = ZooGate { gate_id: 1, .. };
//      let g2 = ZooGate { gate_id: 2, .. };
//      let g3 = ZooGate { gate_id: 3, .. };
//  }   ← 스코프 끝. 컴파일러가 자동 삽입:
//        drop(g3) → ZooGate::drop(&mut g3) 호출 → "정문 #3 닫힘"
//        drop(g2) → ZooGate::drop(&mut g2) 호출 → "정문 #2 닫힘"
//        drop(g1) → ZooGate::drop(&mut g1) 호출 → "정문 #1 닫힘"
//
//  drop 순서: 선언의 역순 (LIFO — Last In, First Out)
//  이유: 나중에 만들어진 것이 먼저 정리되어야 의존 관계가 깨지지 않음.

#[derive(Debug, Clone)]
pub struct ZooGate {
    pub gate_id:   u32,
    pub is_locked: bool,
}

// 수동 Default 구현 — 기본 상태를 명시적으로 지정
impl Default for ZooGate {
    fn default() -> Self {
        ZooGate { gate_id: 0, is_locked: true }
    }
}

// Drop 구현 — 스코프 끝에서 자동 호출
impl Drop for ZooGate {
    fn drop(&mut self) {
        // 실제 활용: 파일 닫기, 연결 해제, 잠금 해제 등
        println!("    [Drop] 정문 #{} 닫힘 (자동 잠금).", self.gate_id);
    }
}

pub fn run() {
    println!("\n─── 패턴8: Default / Drop ───");

    // Default::default()
    let gate1 = ZooGate::default();
    println!("  기본 게이트: {:?}", gate1);

    // Option::unwrap_or_default — None이면 Default::default() 반환
    let maybe: Option<ZooGate> = None;
    let gate2 = maybe.unwrap_or_default();
    println!("  unwrap_or_default: {:?}", gate2);

    // struct update syntax — 일부 필드만 변경, 나머지는 default()에서
    let gate3 = ZooGate { gate_id: 5, ..ZooGate::default() };
    println!("  update syntax: {:?}", gate3);

    // Drop 순서 확인 — 선언 역순
    {
        let _g1 = ZooGate { gate_id: 1, is_locked: true };
        let _g2 = ZooGate { gate_id: 2, is_locked: true };
        let _g3 = ZooGate { gate_id: 3, is_locked: true };
        println!("  g1, g2, g3 선언 완료");
        // 스코프 끝 → drop(_g3) → drop(_g2) → drop(_g1) 순서
    }
    println!("  (스코프 끝, drop 완료)");

    // gate1, gate2, gate3 도 여기서 drop됨
}
