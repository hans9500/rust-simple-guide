// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴10: 연산자 오버로딩 (Operator Overloading)                         │
// │                                                                       │
// │  Rust의 연산자는 모두 std::ops 의 trait으로 정의되어 있다.               │
// │  해당 trait을 구현하면 연산자를 쓸 수 있다.                              │
// │                                                                       │
// │  PartialEq: == , !=  연산자                                            │
// │  Eq:        PartialEq + 반사성(a==a 항상 true) 보장 marker trait        │
// │  Add:       +  연산자  (연관 타입 Output 포함 — 패턴6)                  │
// │                                                                       │
// │  PartialEq vs Eq:                                                     │
// │    f64는 Eq를 구현하지 않는다. 이유: NaN != NaN (반사성 위반)           │
// │    정수(i32, u32 등)는 Eq를 구현한다. NaN이 없으므로 반사성 보장됨.      │
// │    커스텀 구현 시: PartialEq만 있어도 ==, != 가능.                       │
// │                    Eq는 "이 타입은 완전한 동등성을 보장한다"는 선언.      │
// └───────────────────────────────────────────────────────────────────────┘
use std::fmt;
use std::ops::Add;

#[derive(Debug, Clone)]
pub struct AnimalCount {
    pub lions:  u32,
    pub ducks:  u32,
    pub snakes: u32,
}

impl AnimalCount {
    pub fn new(lions: u32, ducks: u32, snakes: u32) -> Self {
        AnimalCount { lions, ducks, snakes }
    }
    pub fn total(&self) -> u32 { self.lions + self.ducks + self.snakes }
}

// PartialEq — == 연산자
// #[derive(PartialEq)]로도 가능하지만 커스텀 로직을 넣을 때는 수동 구현
impl PartialEq for AnimalCount {
    fn eq(&self, other: &Self) -> bool {
        // 커스텀: 마릿수 합계가 같으면 "같다"고 정의
        self.total() == other.total()
    }
    // ne()는 기본 구현: !self.eq(other)
}

// Eq — "이 타입은 완전한 동등성을 보장한다" 선언 (marker trait, 본문 없음)
// AnimalCount는 NaN 같은 예외 없이 항상 a==a 이므로 Eq 구현 가능
impl Eq for AnimalCount {}

// Add — + 연산자
// Add trait 구조:
//   trait Add<Rhs = Self> {
//       type Output;          // 연관 타입 (패턴6)
//       fn add(self, rhs: Rhs) -> Self::Output;
//   }
impl Add for AnimalCount {
    type Output = AnimalCount;  // + 결과 타입

    fn add(self, rhs: AnimalCount) -> AnimalCount {
        AnimalCount {
            lions:  self.lions  + rhs.lions,
            ducks:  self.ducks  + rhs.ducks,
            snakes: self.snakes + rhs.snakes,
        }
    }
}

impl fmt::Display for AnimalCount {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "사자:{} 오리:{} 뱀:{} (합계:{})",
            self.lions, self.ducks, self.snakes, self.total())
    }
}

pub fn run() {
    println!("\n─── 패턴10: 연산자 오버로딩 ───");

    let a = AnimalCount::new(3, 5, 2);  // total=10
    let b = AnimalCount::new(1, 7, 2);  // total=10
    let c = AnimalCount::new(5, 3, 3);  // total=11

    // PartialEq — total이 같으면 true (커스텀 정의)
    println!("  a == b (total 10==10): {}", a == b);  // true
    println!("  a == c (total 10==11): {}", a == c);  // false
    println!("  a != c: {}", a != c);                  // true

    // Add — + 연산자
    let combined = a.clone() + b.clone();
    println!("  a + b = {}", combined);

    // NaN 예시 — f64는 PartialEq만 구현, Eq 미구현
    //
    //  f64::NAN == f64::NAN 은 항상 false (IEEE 754 표준).
    //  컴파일러 경고 방지: nan == nan 직접 비교 대신 is_nan() 사용.
    //  단, 교육 목적으로 is_nan()의 반환값을 통해 동일한 사실을 보여준다.
    let nan = f64::NAN;
    // nan == nan 직접 비교 → 컴파일러 warning (항상 false임을 알기 때문)
    // 대신 is_nan() 사용 + 직접 비교를 피하는 관용 표현
    let nan_is_not_equal_to_itself = !nan.is_nan() || nan != nan; // 항상 true: NaN ≠ NaN
    println!("  NaN은 자기 자신과 같지 않음: {} (반사성 위반 → Eq 구현 불가)", nan_is_not_equal_to_itself);
    println!("  f64::NAN.is_nan(): {}", nan.is_nan());
    // IEEE 754: NaN 비교는 항상 false (==, <, >, <= 모두)
    // 따라서 f64는 PartialEq는 구현하지만 Eq(완전 동등성)는 구현 불가
}
