// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴11: Iterator 구현                                                  │
// │                                                                       │
// │  Iterator trait은 next() 하나만 구현하면 된다.                          │
// │  map, filter, take, collect 등 수십 개의 메서드가 자동으로 생긴다.       │
// │  → 블랭킷 구현(패턴7)의 가장 강력한 실제 사례                           │
// │                                                                       │
// │  IntoIterator:                                                         │
// │    for 루프는 실제로 IntoIterator를 통해 동작한다.                       │
// │    Iterator는 IntoIterator를 자동 구현한다 (블랭킷):                    │
// │      impl<I: Iterator> IntoIterator for I { fn into_iter(self) -> I } │
// │    따라서 Iterator를 구현하면 for 루프도 자동으로 동작한다.               │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Iterator trait 구조 ─────────────────────────────────────────────────
//
//  trait Iterator {
//      type Item;                                    // 연관 타입 (패턴6)
//      fn next(&mut self) -> Option<Self::Item>;     // 필수 구현
//
//      // 나머지는 모두 기본 구현 (블랭킷, 패턴7)
//      fn map<B, F>(self, f: F) -> Map<Self, F>      { ... }
//      fn filter<P>(self, p: P) -> Filter<Self, P>   { ... }
//      fn take(self, n: usize) -> Take<Self>         { ... }
//      fn collect<B: FromIterator<Item>>(self) -> B  { ... }
//      fn count(self) -> usize                       { ... }
//      // ... 70개 이상
//  }
//
//  for 루프 동작:
//  for x in iter { ... }
//  →  let mut it = iter.into_iter();    // IntoIterator
//     loop {
//         match it.next() {
//             Some(x) => { ... }
//             None    => break,
//         }
//     }

pub struct ZooIter {
    animals: Vec<String>,
    index:   usize,
}

impl ZooIter {
    pub fn new(animals: Vec<String>) -> Self {
        ZooIter { animals, index: 0 }
    }
}

impl Iterator for ZooIter {
    type Item = String;     // 패턴6: 연관 타입 — 이 Iterator는 String을 yield

    fn next(&mut self) -> Option<String> {
        if self.index < self.animals.len() {
            let item = self.animals[self.index].clone();
            self.index += 1;
            Some(item)
        } else {
            None    // None을 반환하면 반복 종료
        }
    }
    // map, filter, collect 등은 자동으로 생긴다
}

pub fn run() {
    println!("\n─── 패턴11: Iterator 구현 ───");

    let iter = ZooIter::new(vec![
        "Simba".into(), "Nala".into(), "Mufasa".into(),
        "Scar".into(),  "Sarabi".into(),
    ]);

    // next()만 구현했는데 filter + map + collect 모두 동작
    let short: Vec<String> = iter
        .filter(|name| name.len() <= 4)      // 4글자 이하
        .map(|name| name.to_uppercase())     // 대문자
        .collect();
    println!("  짧은 이름 (대문자): {:?}", short);

    // for 루프 — IntoIterator 자동 구현 덕분에 동작
    let iter2 = ZooIter::new(vec!["Donald".into(), "Nagini".into()]);
    for animal in iter2 {   // iter2.into_iter() 자동 호출
        println!("  for 루프: {}", animal);
    }

    // 다양한 어댑터
    let iter3 = ZooIter::new(vec![
        "A".into(), "BB".into(), "CCC".into(), "DDDD".into(), "EEEEE".into(),
    ]);
    let count = iter3.take(3).count();   // 앞 3개만 세기
    println!("  take(3).count(): {}", count);
}
