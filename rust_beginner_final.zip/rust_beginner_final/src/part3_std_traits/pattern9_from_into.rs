// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴9: From / Into + 고아 규칙(Orphan Rule) + newtype 패턴             │
// │                                                                       │
// │  From<T>: "T로부터 Self를 만들 수 있다"  (실패 없는 변환)               │
// │  Into<T>: "Self를 T로 변환할 수 있다"                                   │
// │  TryFrom<T>: 실패 가능한 변환 → Result<Self, Err>                      │
// │  TryInto<T>: 실패 가능한 역방향 변환 → Result<T, Err>                  │
// │                                                                       │
// │  From을 구현하면 Into가 블랭킷(패턴7)으로 자동 생성된다:                 │
// │    std: impl<T, U: From<T>> Into<U> for T                             │
// │                                                                       │
// │  고아 규칙(Orphan Rule):                                               │
// │    impl은 "내 crate의 trait" 이거나 "내 crate의 타입" 이어야 한다.       │
// │    둘 다 외부이면 컴파일 에러 → newtype으로 우회                         │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 고아 규칙 도식 ───────────────────────────────────────────────────────
//
//  내 crate = rust_impl_guide
//
//  ✅ OK: 내 trait + 외부 타입
//    impl Sound for Vec<i32>         Sound는 내 trait
//
//  ✅ OK: 외부 trait + 내 타입
//    impl fmt::Display for Lion      Lion은 내 타입
//
//  ❌ ERROR: 외부 trait + 외부 타입
//    impl fmt::Display for Vec<i32>  Display도 외부, Vec도 외부
//    → 두 외부 crate가 동일 impl을 정의하면 충돌 → Rust가 금지
//
//  ✅ 해결: newtype 패턴
//    struct MyVec(Vec<i32>);         MyVec은 내 타입
//    impl fmt::Display for MyVec     OK

use std::fmt;
use crate::part2_patterns::animals::Lion;

// ── From<&str> for Lion — 단순 변환 ──────────────────────────────────────
impl From<&str> for Lion {
    fn from(name: &str) -> Self {
        Lion::new(name, 0)
    }
}

// ── TryFrom 예시 — 실패 가능한 변환 ──────────────────────────────────────
// "나이가 유효 범위(0~25)인 경우만 Lion 생성"
use std::convert::TryFrom;

impl TryFrom<(&str, u32)> for Lion {
    type Error = String;

    fn try_from((name, age): (&str, u32)) -> Result<Self, Self::Error> {
        if age > Lion::MAX_AGE {
            Err(format!("나이 {} 는 최대치 {} 를 초과합니다.", age, Lion::MAX_AGE))
        } else {
            Ok(Lion::new(name, age))
        }
    }
}

// ── newtype 패턴 — Vec<String>에 Display 구현 (고아 규칙 우회) ───────────
pub struct AnimalNames(pub Vec<String>);

impl fmt::Display for AnimalNames {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "[{}]", self.0.join(", "))
    }
}

impl From<Vec<String>> for AnimalNames {
    fn from(v: Vec<String>) -> Self { AnimalNames(v) }
}

// newtype에 원본 타입 메서드 위임 (Deref 또는 수동)
impl AnimalNames {
    pub fn count(&self) -> usize { self.0.len() }
    pub fn add(&mut self, name: &str) { self.0.push(name.to_string()); }
}

pub fn run() {
    println!("\n─── 패턴9: From / Into + newtype ───");

    // From
    let lion1 = Lion::from("Simba");
    println!("  From<&str>: {}", lion1.name());

    // Into — From을 구현했으므로 자동 생성
    let lion2: Lion = "Nala".into();    println!("  Into:       {}", lion2.name());

    // TryFrom — 실패 가능한 변환
    let ok: Result<Lion, _> = ("Mufasa", 10u32).try_into();
    println!("  TryFrom OK: {}", ok.unwrap().name());

    let err: Result<Lion, _> = ("Ghost", 99u32).try_into();
    println!("  TryFrom Err: {}", err.unwrap_err());

    // newtype
    let mut names = AnimalNames(vec!["Simba".into(), "Nala".into()]);
    names.add("Mufasa");
    println!("  AnimalNames: {} ({}마리)", names, names.count());

    // Vec<String> → AnimalNames via From
    let v = vec!["Scar".to_string(), "Sarabi".to_string()];
    let names2: AnimalNames = v.into();
    println!("  from Vec:   {}", names2);
}
