// ┌───────────────────────────────────────────────────────────────────────┐
// │  Hash / Ord / PartialOrd 구현                                         │
// │                                                                       │
// │  공식 문서: std::hash::Hash, std::cmp::{Ord, PartialOrd}              │
// │                                                                       │
// │  PartialOrd: 부분 순서 (<, >, <=, >=). 비교 불가 쌍이 있을 수 있음     │
// │    (예: f64 — NaN은 어떤 값과도 비교 불가)                              │
// │  Ord: 완전 순서. 모든 쌍이 비교 가능. PartialOrd + Eq 필요              │
// │  Hash: HashMap/HashSet의 키로 사용. Eq와 함께 구현                      │
// │                                                                       │
// │  규칙:                                                                 │
// │    Ord  구현 시 → PartialOrd, Eq, PartialEq 모두 구현해야              │
// │    Hash 구현 시 → Eq(따라서 PartialEq)도 구현해야                      │
// │    k1 == k2 이면 hash(k1) == hash(k2) 반드시 성립해야                  │
// └───────────────────────────────────────────────────────────────────────┘

use std::cmp::Ordering;
use std::collections::{HashMap, HashSet, BTreeMap};
use std::hash::{Hash, Hasher};

// ── 1. derive로 자동 구현 (가장 흔한 방식) ───────────────────────────────
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
struct AnimalId {
    species: String,
    number:  u32,
}

impl AnimalId {
    fn new(species: &str, number: u32) -> Self {
        AnimalId { species: species.to_string(), number }
    }
}

// derive Ord는 필드 선언 순서대로 사전식 비교
// species 먼저, 같으면 number로 비교

// ── 2. 수동 구현 — 커스텀 정렬 기준 ─────────────────────────────────────
#[derive(Debug, Clone)]
struct Animal {
    name:    String,
    age:     u32,
    weight:  f64,   // f64는 Ord 불가 (NaN 때문)
}

impl Animal {
    fn new(name: &str, age: u32, weight: f64) -> Self {
        Animal { name: name.to_string(), age, weight }
    }
}

// PartialEq: 이름으로 동등성 판단
impl PartialEq for Animal {
    fn eq(&self, other: &Self) -> bool {
        self.name == other.name
    }
}

// Eq: PartialEq의 완전 버전 (반사성 보장 — a == a)
impl Eq for Animal {}

// PartialOrd: 나이로 정렬 (weight는 f64라 Ord 불가)
impl PartialOrd for Animal {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

// Ord: 나이 기준 완전 정렬
impl Ord for Animal {
    fn cmp(&self, other: &Self) -> Ordering {
        self.age.cmp(&other.age)
            .then(self.name.cmp(&other.name))  // 나이 같으면 이름으로
    }
}

// Hash: 이름으로 해싱 (PartialEq와 일관성 필수!)
// eq()가 name 기반이므로 hash()도 name 기반
impl Hash for Animal {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.name.hash(state);
    }
}

// ── 3. Hash/Eq 일관성 규칙 ───────────────────────────────────────────────
// 만약 eq()는 name 기반인데 hash()는 age 기반이면?
// → 같은 name인데 다른 hash → HashMap에서 찾을 수 없음 → 버그!

pub fn run() {
    println!("\n  [Hash / Ord / PartialOrd 구현]");

    // derive 자동 구현
    println!("\n  ── derive 자동 구현 ──");
    let mut ids = vec![
        AnimalId::new("사자", 3),
        AnimalId::new("오리", 1),
        AnimalId::new("사자", 1),
        AnimalId::new("뱀",   2),
    ];
    ids.sort();  // Ord 덕분에 sort() 가능
    println!("  정렬(species→number): {:?}", ids);

    // HashSet — Hash + Eq 필요
    let mut id_set: HashSet<AnimalId> = HashSet::new();
    id_set.insert(AnimalId::new("사자", 1));
    id_set.insert(AnimalId::new("사자", 1));  // 중복 → 무시
    id_set.insert(AnimalId::new("오리", 1));
    println!("  HashSet 크기(중복제거): {}", id_set.len());

    // HashMap — Hash + Eq 필요
    let mut registry: HashMap<AnimalId, &str> = HashMap::new();
    registry.insert(AnimalId::new("사자", 1), "Simba");
    registry.insert(AnimalId::new("오리", 1), "Donald");
    println!("  HashMap 조회: {:?}",
        registry.get(&AnimalId::new("사자", 1)));

    // 수동 구현
    println!("\n  ── 수동 Ord/Hash 구현 ──");
    let mut animals = vec![
        Animal::new("Nagini",  8, 15.0),
        Animal::new("Simba",   5, 190.5),
        Animal::new("Donald",  3, 2.5),
        Animal::new("Dumbo",  10, 4000.0),
    ];

    animals.sort();  // Ord(나이 기준)로 정렬
    println!("  나이순 정렬:");
    for a in &animals {
        println!("    {} {}살 {}kg", a.name, a.age, a.weight);
    }

    animals.sort_by(|a, b| {
        a.weight.partial_cmp(&b.weight).unwrap_or(Ordering::Equal)
    });
    println!("  체중순 정렬:");
    for a in &animals {
        println!("    {} {}살 {}kg", a.name, a.age, a.weight);
    }

    // HashSet<Animal> — Hash(name) + Eq(name)
    let mut animal_set: HashSet<Animal> = HashSet::new();
    animal_set.insert(Animal::new("Simba", 5, 190.5));
    animal_set.insert(Animal::new("Simba", 6, 200.0));  // name 같음 → 중복
    println!("  HashSet(name 기준 중복제거): {}", animal_set.len());

    // BTreeMap — Ord 필요 (자동 정렬)
    println!("\n  ── BTreeMap (Ord 필요) ──");
    let mut btree: BTreeMap<AnimalId, &str> = BTreeMap::new();
    btree.insert(AnimalId::new("사자", 2), "Mufasa");
    btree.insert(AnimalId::new("오리", 1), "Donald");
    btree.insert(AnimalId::new("사자", 1), "Simba");
    println!("  BTreeMap(자동정렬):");
    for (id, name) in &btree {
        println!("    {:?} → {}", id, name);
    }

    println!("\n  ── 정리 ──");
    println!("  HashMap/HashSet 키: Hash + Eq 필요");
    println!("  BTreeMap/BTreeSet 키: Ord 필요");
    println!("  sort(): Ord 필요  |  sort_by(): 클로저로 직접 비교");
    println!("  Hash/Eq 일관성: a==b 이면 반드시 hash(a)==hash(b)");
}
