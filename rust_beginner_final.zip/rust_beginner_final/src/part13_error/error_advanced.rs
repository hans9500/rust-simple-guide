// ┌──────────────────────────────────────────────────────────────────
// │ Part 13-4: 에러 처리 심화
// │
// │ - 여러 에러 타입 통합 패턴
// │ - 에러 컨텍스트 추가
// │ - panic vs Result 선택 기준
// └──────────────────────────────────────────────────────────────────

use std::fmt;
use std::num::{ParseIntError, ParseFloatError};


// ┌─────────────────────────────────────────────────────────────────────┐
// │  에러 처리 전략 비교                                                  │
// │                                                                     │
// │  panic!       → 복구 불가한 에러. 즉시 종료.                          │
// │                 버그, 불변조건 위반 시 사용                           │
// │                                                                     │
// │  Result<T,E>  → 복구 가능한 에러. 호출자가 처리.                      │
// │                 파일 I/O, 네트워크, 파싱 등                           │
// │                                                                     │
// │  Box<dyn Error> → 여러 에러 타입을 하나로.                            │
// │                   라이브러리보다 애플리케이션에 적합                   │
// │                                                                     │
// │  thiserror     → 라이브러리용 커스텀 에러 (derive 매크로)             │
// │  anyhow        → 애플리케이션용 에러 처리 간소화                      │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [13-4: 에러 처리 심화]");
    demo_from_conversion();
    demo_context();
    demo_panic_vs_result();
}

// ── From 변환으로 여러 에러 통합 ─────────────────────────────────
#[derive(Debug)]
enum AppError {
    Parse(String),
    Validation(String),
    Io(String),
}

impl fmt::Display for AppError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Parse(msg)      => write!(f, "파싱 오류: {}", msg),
            Self::Validation(msg) => write!(f, "검증 오류: {}", msg),
            Self::Io(msg)         => write!(f, "IO 오류: {}", msg),
        }
    }
}

impl std::error::Error for AppError {}

impl From<ParseIntError> for AppError {
    fn from(e: ParseIntError) -> Self {
        Self::Parse(e.to_string())
    }
}

impl From<ParseFloatError> for AppError {
    fn from(e: ParseFloatError) -> Self {
        Self::Parse(e.to_string())
    }
}

fn load_animal(data: &str) -> Result<(String, u32, f64), AppError> {
    let parts: Vec<&str> = data.split(',').collect();
    if parts.len() != 3 {
        return Err(AppError::Validation(
            format!("필드 3개 필요, {} 개 받음", parts.len())
        ));
    }
    let name   = parts[0].trim().to_string();
    let age: u32   = parts[1].trim().parse()?;   // From<ParseIntError>
    let weight: f64 = parts[2].trim().parse()?;  // From<ParseFloatError>

    if age > 50 {
        return Err(AppError::Validation(format!("나이 {}는 비정상", age)));
    }
    if weight < 0.0 {
        return Err(AppError::Io(format!("체중 데이터 읽기 실패")));
    }
    Ok((name, age, weight))
}

fn demo_from_conversion() {
    println!("\n  ── From 변환으로 에러 통합 ──");
    let inputs = [
        "Simba, 5, 190.5",
        "Donald, 3, 2.5",
        "Nagini, abc, 15.0",
        "Dumbo, 10",
        "Ghost, 100, 50.0",
    ];
    for input in &inputs {
        match load_animal(input) {
            Ok((name, age, w)) =>
                println!("  OK: {} {}살 {}kg", name, age, w),
            Err(e) =>
                println!("  ERR '{}': {}", input.trim(), e),
        }
    }
}

// ── 에러 컨텍스트 추가 ────────────────────────────────────────────
// 에러에 "어디서 발생했는지" 정보를 추가하는 패턴
#[derive(Debug)]
struct ContextError {
    context: String,
    source:  Box<dyn std::error::Error + 'static>,
}

impl fmt::Display for ContextError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.context, self.source)
    }
}

impl std::error::Error for ContextError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.source.as_ref())
    }
}

// Result에 context 메서드를 추가하는 트레이트
trait WithContext<T> {
    fn context(self, msg: &str) -> Result<T, ContextError>;
}

impl<T, E: std::error::Error + 'static> WithContext<T> for Result<T, E> {
    fn context(self, msg: &str) -> Result<T, ContextError> {
        self.map_err(|e| ContextError {
            context: msg.to_string(),
            source:  Box::new(e),
        })
    }
}

fn process_file_line(line: &str, line_num: usize) -> Result<u32, ContextError> {
    line.trim()
        .parse::<u32>()
        .context(&format!("{}번째 줄 파싱 실패", line_num))
}

fn demo_context() {
    println!("\n  ── 에러 컨텍스트 추가 ──");
    let lines = ["42", "abc", "100"];
    for (i, line) in lines.iter().enumerate() {
        match process_file_line(line, i + 1) {
            Ok(n)  => println!("  줄 {}: {}", i + 1, n),
            Err(e) => println!("  오류: {}", e),
        }
    }
}

// ── panic vs Result 선택 기준 ────────────────────────────────────
fn demo_panic_vs_result() {
    println!("\n  ── panic vs Result 선택 기준 ──");

    // panic을 써야 할 때:
    // 1. 버그 — 절대 발생해서는 안 되는 상태
    // 2. 테스트
    // 3. 예제 코드
    // 4. 불변조건(invariant) 위반

    // Result를 써야 할 때:
    // 1. 파일 없음, 네트워크 실패 등 예상 가능한 실패
    // 2. 사용자 입력 검증
    // 3. 라이브러리 코드 (호출자가 결정하도록)

    println!("  panic 적합: 배열 인덱스 초과, 잠금 오염, 버그");
    println!("  Result 적합: 파일 읽기, 네트워크, 파싱, 검증");

    // unwrap/expect: 테스트/프로토타입에서만, 실제 코드는 ?
    let age: u32 = "5".parse().expect("나이는 항상 유효한 숫자 (버그면 panic OK)");
    println!("  expect 사용 예: 나이={}", age);

    // assert!: 불변조건 검증 — 실패하면 panic
    let capacity = 100u32;
    let current  = 50u32;
    assert!(current <= capacity, "수용 초과 — 버그");
    println!("  assert 통과: current({}) <= capacity({})", current, capacity);
}
