// ┌─────────────────────────────────────────────────────────────────────┐
// │  Result / Option 흐름                                               │
// │                                                                     │
// │  Option<T>:                                                         │
// │    Some(T) ──map()──▶ Some(U)                                       │
// │    None    ──map()──▶ None      (변환 생략)                          │
// │                                                                     │
// │  Result<T,E>:                                                       │
// │    Ok(T)  ──map()──▶ Ok(U)                                          │
// │    Err(E) ──map()──▶ Err(E)     (에러 통과)                         │
// │                                                                     │
// │  unwrap 계열:                                                        │
// │    unwrap()         → 값 or panic!                                  │
// │    unwrap_or(def)   → 값 or 기본값                                  │
// │    unwrap_or_else(f)→ 값 or f() 실행                                │
// │    expect("msg")    → 값 or panic!(msg)                             │
// └─────────────────────────────────────────────────────────────────────┘

// ┌──────────────────────────────────────────────────────────────────
// │ Part 13-1: 에러 처리 기초
// │
// │ Rust의 두 가지 에러:
// │   1. 복구 가능(recoverable): Result<T, E>
// │   2. 복구 불가(unrecoverable): panic!
// │
// │ panic!: 프로세스를 종료. 버그, 불변조건 위반.
// │         out-of-bounds, unwrap on None 등.
// │
// │ Result<T, E>: 에러를 값으로 처리. 호출자가 결정.
// └──────────────────────────────────────────────────────────────────

pub fn run() {
    println!("\n  [13-1: 에러 처리 기초]");
    demo_result_basics();
    demo_option_result();
    demo_unwrap_variants();
}

fn demo_result_basics() {
    println!("\n  ── Result<T, E> 기본 ──");

    // Result는 Ok(T) 또는 Err(E)
    let ok: Result<i32, String>  = Ok(42);
    let _err: Result<i32, String> = Err("에러 발생".to_string());

    // match로 처리
    match ok {
        Ok(v)  => println!("  Ok: {}", v),
        Err(e) => println!("  Err: {}", e),
    }

    // 실제 예: 문자열 파싱
    let inputs = ["5", "abc", "190"];
    for input in &inputs {
        match input.parse::<u32>() {
            Ok(n)  => println!("  파싱 성공: {}", n),
            Err(e) => println!("  파싱 실패 '{}': {}", input, e),
        }
    }
}

fn demo_option_result() {
    println!("\n  ── Option vs Result ──");

    // Option: 값이 있거나 없거나 (에러 정보 없음)
    // Result: 성공하거나 실패하거나 (에러 정보 있음)

    let animals = vec!["사자", "오리", "뱀"];

    // Option — find
    let found: Option<&&str> = animals.iter().find(|&&a| a == "오리");
    println!("  Option find: {:?}", found);

    // Option → Result 변환
    let result: Result<&&str, &str> = found.ok_or("동물 없음");
    println!("  ok_or: {:?}", result);

    // Result → Option 변환
    let parsed: Result<u32, _> = "42".parse();
    let opt: Option<u32> = parsed.ok();
    println!("  Result.ok(): {:?}", opt);
}

fn demo_unwrap_variants() {
    println!("\n  ── unwrap 계열 메서드 ──");

    let ok: Result<u32, &str> = Ok(5);
    let err: Result<u32, &str> = Err("실패");

    // unwrap: Ok면 값, Err면 panic
    println!("  unwrap: {}", ok.unwrap());

    // unwrap_or: Err면 기본값
    println!("  unwrap_or: {}", err.unwrap_or(0));

    // unwrap_or_else: Err면 클로저 실행
    println!("  unwrap_or_else: {}",
        err.unwrap_or_else(|e| { println!("    에러: {}", e); 0 }));

    // unwrap_or_default: Err면 Default::default()
    let err2: Result<u32, &str> = Err("x");
    println!("  unwrap_or_default: {}", err2.unwrap_or_default()); // 0

    // expect: unwrap + 메시지
    let age: u32 = "5".parse().expect("나이는 숫자여야 함");
    println!("  expect: {}", age);

    // map: Ok 값 변환, Err는 그대로
    let doubled = ok.map(|v| v * 2);
    println!("  map(×2): {:?}", doubled);

    // map_err: Err 변환, Ok는 그대로
    let mapped_err = err.map_err(|e| format!("변환된 에러: {}", e));
    println!("  map_err: {:?}", mapped_err);

    // and_then: Ok면 클로저, Err면 그대로 (flatMap)
    let chained: Result<String, &str> = ok
        .and_then(|v| Ok(format!("값: {}", v)));
    println!("  and_then: {:?}", chained);
}
