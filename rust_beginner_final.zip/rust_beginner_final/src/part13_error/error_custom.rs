// ┌──────────────────────────────────────────────────────────────────
// │ Part 13-3: 커스텀 에러 타입
// │
// │ std::error::Error trait:
// │   trait Error: Debug + Display {
// │       fn source(&self) -> Option<&(dyn Error + 'static)> { None }
// │   }
// │
// │ 좋은 에러 타입 조건:
// │   1. Debug 구현 (자동 derive)
// │   2. Display 구현 (사람이 읽을 수 있는 메시지)
// │   3. std::error::Error 구현
// │   4. 에러 원인 체인 (source())
// └──────────────────────────────────────────────────────────────────

use std::fmt;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  커스텀 에러 타입 계층 구조                                           │
// │                                                                     │
// │  ZooError (최상위 에러)                                              │
// │    ├── NotFound(String)   ← 동물을 찾을 수 없음                      │
// │    ├── InvalidAge(u32)    ← 잘못된 나이                              │
// │    └── IoError(io::Error) ← 파일 I/O 에러 래핑                      │
// │                                                                     │
// │  구현:                                                               │
// │  impl std::error::Error for ZooError {}                             │
// │  impl fmt::Display for ZooError { ... }                             │
// │  impl From<io::Error> for ZooError { ... }  ← ? 자동 변환           │
// │                                                                     │
// │  From 구현 → ? 연산자가 자동으로 에러 타입 변환                       │
// │    io::Error ──From──▶ ZooError::IoError                            │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [13-3: 커스텀 에러 타입]");
    demo_custom_error();
    demo_error_chain();
    demo_box_dyn_error();
}

// ── 커스텀 에러 열거형 ─────────────────────────────────────────────
#[derive(Debug)]
enum ZooError {
    AnimalNotFound(String),
    CapacityExceeded { max: u32, current: u32 },
    InvalidData(String),
}

impl fmt::Display for ZooError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::AnimalNotFound(name) =>
                write!(f, "동물 '{}' 을 찾을 수 없음", name),
            Self::CapacityExceeded { max, current } =>
                write!(f, "수용 한계 초과: 최대 {}, 현재 {}", max, current),
            Self::InvalidData(msg) =>
                write!(f, "잘못된 데이터: {}", msg),
        }
    }
}

impl std::error::Error for ZooError {}

fn find_animal(_animals: &[&str], name: &str) -> Result<&'static str, ZooError> {
    if name == "사자" { return Ok("사자 발견!"); }
    Err(ZooError::AnimalNotFound(name.to_string()))
}

fn add_animal(current: u32, max: u32) -> Result<u32, ZooError> {
    if current >= max {
        return Err(ZooError::CapacityExceeded { max, current });
    }
    Ok(current + 1)
}

fn parse_species(s: &str) -> Result<&str, ZooError> {
    match s {
        "사자" | "오리" | "뱀" => Ok(s),
        _ => Err(ZooError::InvalidData(format!("알 수 없는 종: {}", s))),
    }
}

fn demo_custom_error() {
    println!("\n  ── 커스텀 에러 ──");

    match find_animal(&[], "사자") {
        Ok(msg)  => println!("  {}", msg),
        Err(e)   => println!("  에러: {}", e),
    }
    match find_animal(&[], "호랑이") {
        Ok(msg)  => println!("  {}", msg),
        Err(e)   => println!("  에러: {}", e),
    }
    match add_animal(10, 10) {
        Ok(n)    => println!("  동물 수: {}", n),
        Err(e)   => println!("  에러: {}", e),
    }
    match parse_species("호랑이") {
        Ok(s)    => println!("  종: {}", s),
        Err(e)   => println!("  에러: {}", e),
    }
    match parse_species("사자") {
        Ok(s)    => println!("  종: {}", s),
        Err(e)   => println!("  에러: {}", e),
    }
}

// ── 에러 체인 (source) ────────────────────────────────────────────
#[derive(Debug)]
struct LoadError {
    path:   String,
    source: Box<dyn std::error::Error + 'static>,
}

impl fmt::Display for LoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "'{}' 로드 실패", self.path)
    }
}

impl std::error::Error for LoadError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.source.as_ref())
    }
}

fn demo_error_chain() {
    use std::error::Error;
    println!("\n  ── 에러 체인 (source) ──");

    // 파싱 에러를 LoadError로 감쌈
    let parse_err = "abc".parse::<u32>().unwrap_err();
    let load_err = LoadError {
        path:   "animals.csv".to_string(),
        source: Box::new(parse_err),
    };

    println!("  에러: {}", load_err);
    if let Some(src) = load_err.source() {
        println!("  원인: {}", src);
    }
}

// ── Box<dyn Error>: 여러 에러 타입 혼용 ──────────────────────────
fn mixed_operations() -> Result<String, Box<dyn std::error::Error>> {
    // 여러 에러 타입을 Box<dyn Error>로 통일
    let age: u32 = "5".parse()?;               // ParseIntError
    let weight: f64 = "190.5".parse()?;        // ParseFloatError
    Ok(format!("나이: {}, 체중: {}", age, weight))
}

fn demo_box_dyn_error() {
    println!("\n  ── Box<dyn Error>: 혼합 에러 ──");
    match mixed_operations() {
        Ok(s)  => println!("  결과: {}", s),
        Err(e) => println!("  에러: {}", e),
    }
    // 주의: Box<dyn Error>는 타입 정보를 잃음
    // 에러 종류를 구분해야 하면 enum 에러 타입 사용
}
