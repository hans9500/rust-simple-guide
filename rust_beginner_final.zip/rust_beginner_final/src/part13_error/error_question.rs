// ┌──────────────────────────────────────────────────────────────────
// │ Part 13-2: ? 연산자
// │
// │ 공식 문서: Rust Reference "The question mark operator"
// │
// │ expr?  는 다음과 동일:
// │   match expr {
// │       Ok(v)  => v,
// │       Err(e) => return Err(e.into()),  // From::from 변환
// │   }
// │
// │ ? 사용 조건:
// │   - Result 또는 Option을 반환하는 함수에서만 사용 가능
// │   - 에러 타입이 From 변환을 구현해야 함
// └──────────────────────────────────────────────────────────────────

use std::num::ParseIntError;
use std::fmt;


// ┌─────────────────────────────────────────────────────────────────────┐
// │  ? 연산자 — 에러 전파 흐름                                           │
// │                                                                     │
// │  fn read_name() -> Result<String, io::Error> {                      │
// │      let f = File::open("name.txt")?;                               │
// │      //                              ↑                              │
// │      //    Ok(f)  → f에 바인딩, 계속 │                              │
// │      //    Err(e) → 즉시 return Err(e)                              │
// │  }                                                                  │
// │                                                                     │
// │  ? 없이 쓰면:                                                        │
// │    match File::open("name.txt") {                                   │
// │        Ok(f)  => f,                                                 │
// │        Err(e) => return Err(e),   ← ? 가 이것을 대신                │
// │    }                                                                │
// │                                                                     │
// │  ? 사용 조건: 함수 반환 타입이 Result 또는 Option이어야 함            │
// └─────────────────────────────────────────────────────────────────────┘
pub fn run() {
    println!("\n  [13-2: ? 연산자]");
    demo_without_question();
    demo_with_question();
    demo_question_chain();
    demo_question_option();
}

// ── ? 없이 ─────────────────────────────────────────────────────────
fn parse_age_verbose(s: &str) -> Result<u32, ParseIntError> {
    let age = match s.parse::<u32>() {
        Ok(v)  => v,
        Err(e) => return Err(e),
    };
    Ok(age)
}

fn demo_without_question() {
    println!("\n  ── ? 없이 (장황함) ──");
    println!("  parse '5': {:?}", parse_age_verbose("5"));
    println!("  parse 'abc': {:?}", parse_age_verbose("abc"));
}

// ── ? 사용 ──────────────────────────────────────────────────────────
fn parse_age(s: &str) -> Result<u32, ParseIntError> {
    let age = s.parse::<u32>()?;  // 실패 시 즉시 return Err(e)
    Ok(age)
}

fn validate_age(s: &str) -> Result<u32, String> {
    // 에러 타입이 다를 때: map_err로 변환
    let age = s.parse::<u32>().map_err(|e| format!("파싱 실패: {}", e))?;
    if age > 100 {
        return Err(format!("나이 {}는 너무 큼", age));
    }
    Ok(age)
}

fn demo_with_question() {
    println!("\n  ── ? 연산자 ──");
    println!("  parse '5': {:?}", parse_age("5"));
    println!("  parse 'abc': {:?}", parse_age("abc"));
    println!("  validate '5': {:?}", validate_age("5"));
    println!("  validate '150': {:?}", validate_age("150"));
    println!("  validate 'xyz': {:?}", validate_age("xyz"));
}

// ── 체이닝 ──────────────────────────────────────────────────────────
#[derive(Debug)]
#[allow(dead_code)]  // Debug 출력에서 사용됨
struct Animal {
    name:    String,
    age:     u32,
    weight:  f64,
}

#[derive(Debug)]
enum ParseAnimalError {
    WrongFieldCount { got: usize, expected: usize },
    InvalidAge(ParseIntError),
    InvalidWeight(std::num::ParseFloatError),
}

impl fmt::Display for ParseAnimalError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::WrongFieldCount { got, expected } =>
                write!(f, "필드 수 오류: {} (예상: {})", got, expected),
            Self::InvalidAge(e) =>
                write!(f, "나이 파싱 오류: {}", e),
            Self::InvalidWeight(e) =>
                write!(f, "체중 파싱 오류: {}", e),
        }
    }
}

impl From<ParseIntError>              for ParseAnimalError {
    fn from(e: ParseIntError) -> Self { Self::InvalidAge(e) }
}
impl From<std::num::ParseFloatError>  for ParseAnimalError {
    fn from(e: std::num::ParseFloatError) -> Self { Self::InvalidWeight(e) }
}

// CSV 한 줄 파싱: "Simba,5,190.5"
fn parse_animal(line: &str) -> Result<Animal, ParseAnimalError> {
    let parts: Vec<&str> = line.split(',').collect();
    if parts.len() != 3 {
        return Err(ParseAnimalError::WrongFieldCount {
            got: parts.len(),
            expected: 3,
        });
    }
    Ok(Animal {
        name:   parts[0].to_string(),
        age:    parts[1].parse()?,   // From<ParseIntError> 자동 변환
        weight: parts[2].parse()?,   // From<ParseFloatError> 자동 변환
    })
}

fn demo_question_chain() {
    println!("\n  ── ? 체이닝 + From 변환 ──");
    let inputs = [
        "Simba,5,190.5",
        "Donald,3,2.5",
        "Nagini,abc,15.0",   // 나이 파싱 실패
        "Dumbo,10",          // 필드 수 오류
        "Giraffe,6,xyz",     // 체중 파싱 실패
    ];
    for input in &inputs {
        match parse_animal(input) {
            Ok(a)  => println!("  OK: {:?}", a),
            Err(e) => println!("  ERR '{}': {}", input, e),
        }
    }
}

// ── Option에서의 ? ────────────────────────────────────────────────
fn first_animal_age(animals: &[(&str, u32)], name: &str) -> Option<u32> {
    // Option을 반환하는 함수에서 ? 사용
    let (_, age) = animals.iter().find(|(n, _)| *n == name)?;
    Some(*age)
}

fn demo_question_option() {
    println!("\n  ── Option에서 ? ──");
    let animals = vec![("Simba", 5u32), ("Donald", 3), ("Nagini", 8)];
    println!("  Simba 나이: {:?}", first_animal_age(&animals, "Simba"));
    println!("  없는 동물: {:?}", first_animal_age(&animals, "없음"));
}
