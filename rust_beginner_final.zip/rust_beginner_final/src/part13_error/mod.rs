// ┌──────────────────────────────────────────────────────────────────
// │ Part 13: 에러 처리 완전 가이드
// │
// │ 공식 문서: Rust Book Ch.9, std::error::Error
// └──────────────────────────────────────────────────────────────────

pub mod error_basic;
pub mod error_question;
pub mod error_custom;
pub mod error_advanced;

pub fn run() {
    println!("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    println!(" Part 13: 에러 처리 완전 가이드");
    println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    error_basic::run();
    error_question::run();
    error_custom::run();
    error_advanced::run();
}
