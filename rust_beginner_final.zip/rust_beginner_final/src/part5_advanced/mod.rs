// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 5.  고급 패턴                                                    ║
// ║                                                                       ║
// ║  패턴14  UFCS (Uniform Function Call Syntax) — 충돌 해결               ║
// ║  패턴15  associated const / type alias                                 ║
// ║  패턴16  pub / 가시성(Visibility)                                      ║
// ║  패턴17  빌더 패턴 (Builder Pattern)                                   ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod pattern14_ufcs;
pub mod pattern15_assoc_items;
pub mod pattern16_visibility;
pub mod pattern17_builder;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 5: 고급 패턴");
    println!("══════════════════════════════════════════════════════════");
    pattern14_ufcs::run();
    pattern15_assoc_items::run();
    pattern16_visibility::run();
    pattern17_builder::run();
}
