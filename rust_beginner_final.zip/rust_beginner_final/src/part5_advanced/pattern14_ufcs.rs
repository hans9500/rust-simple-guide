// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴14: UFCS (Uniform Function Call Syntax)                          │
// │          Fully Qualified Syntax — 메서드 충돌 해결                     │
// │                                                                       │
// │  같은 이름의 메서드가 여러 trait 또는 struct 자체에 존재할 때            │
// │  어느 것을 호출할지 명시하는 문법.                                       │
// │                                                                       │
// │  문법 1: TraitName::method(&value)                                     │
// │  문법 2: <Type as TraitName>::method(&value)  (완전 한정 문법)         │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 충돌 상황 도식 ───────────────────────────────────────────────────────
//
//  Bear::display()          ← struct 자체의 메서드
//  ZooDisplay::display()    ← ZooDisplay trait의 메서드
//  ParkDisplay::display()   ← ParkDisplay trait의 메서드
//
//  bear.display() → 컴파일러: 어느 display인가?
//    → struct 자체의 메서드 우선 (고유 메서드 > trait 메서드)
//
//  명시적 호출:
//    ZooDisplay::display(&bear)        → ZooDisplay 버전
//    <Bear as ParkDisplay>::display(&bear) → ParkDisplay 버전

pub trait ZooDisplay {
    fn display(&self) -> String;
}

pub trait ParkDisplay {
    fn display(&self) -> String;
}

#[derive(Debug)]
pub struct Bear { pub name: String }

impl Bear {
    pub fn new(name: &str) -> Self { Bear { name: name.to_string() } }

    // struct 자체의 display — trait과 무관
    pub fn display(&self) -> String {
        format!("Bear({})", self.name)
    }
}

impl ZooDisplay for Bear {
    fn display(&self) -> String {
        format!("[동물원] 곰: {}", self.name)
    }
}

impl ParkDisplay for Bear {
    fn display(&self) -> String {
        format!("[공원] 곰: {}", self.name)
    }
}

pub fn run() {
    println!("\n─── 패턴14: UFCS (충돌 해결) ───");

    let bear = Bear::new("Baloo");

    // 일반 호출 — struct 자체의 display() 우선
    println!("  기본:         {}", bear.display());

    // UFCS — trait 이름으로 명시
    println!("  ZooDisplay:   {}", ZooDisplay::display(&bear));
    println!("  ParkDisplay:  {}", ParkDisplay::display(&bear));

    // 완전 한정 문법 (Fully Qualified Syntax) — 가장 명시적
    println!("  <Bear as Zoo>:{}", <Bear as ZooDisplay>::display(&bear));
    println!("  <Bear as Park>:{}", <Bear as ParkDisplay>::display(&bear));
}
