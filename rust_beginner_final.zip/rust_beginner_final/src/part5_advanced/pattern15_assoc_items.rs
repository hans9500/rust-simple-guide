// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴15: associated const / associated type alias                      │
// │                                                                       │
// │  impl 블록 안에 const와 type을 선언할 수 있다.                          │
// │  Type::CONST_NAME 으로 접근. 인스턴스 없이 사용 가능.                   │
// └───────────────────────────────────────────────────────────────────────┘
use crate::part2_patterns::animals::Lion;

pub trait HasLimits {
    const MAX_COUNT: u32;       // 연관 상수 — 구현하는 쪽에서 값 확정
    type Id;                    // 연관 타입 — 구현하는 쪽에서 타입 확정

    // 기본 구현에서 연관 상수 사용
    fn is_over_limit(&self, count: u32) -> bool {
        count > Self::MAX_COUNT
    }
}

pub struct ZooSection {
    pub id:   u32,
    pub name: String,
}

impl ZooSection {
    // impl 블록 안의 연관 상수
    pub const DEFAULT_CAPACITY: u32 = 20;

    pub fn new(id: u32, name: &str) -> Self {
        ZooSection { id, name: name.to_string() }
    }
}

impl HasLimits for ZooSection {
    const MAX_COUNT: u32 = 50;  // 이 타입의 최대값 확정
    type Id = u32;              // 이 타입의 Id = u32로 확정
}

pub fn run() {
    println!("\n─── 패턴15: 연관 상수 / 연관 타입 ───");

    // 인스턴스 없이 상수 접근
    println!("  ZooSection::DEFAULT_CAPACITY = {}", ZooSection::DEFAULT_CAPACITY);
    println!("  ZooSection::MAX_COUNT        = {}", ZooSection::MAX_COUNT);
    println!("  Lion::MAX_AGE                = {}", Lion::MAX_AGE);

    let section = ZooSection::new(1, "맹수관");
    println!("  60마리 초과?: {}", section.is_over_limit(60));
    println!("  30마리 초과?: {}", section.is_over_limit(30));
}
