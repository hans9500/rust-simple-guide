// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴17: 빌더 패턴 (Builder Pattern) — Self 반환 체이닝                  │
// │                                                                       │
// │  mut self를 받아 수정 후 self를 반환 → 메서드 체이닝 가능                │
// │  복잡한 struct를 단계적으로 구성할 때 유용하다.                          │
// │                                                                       │
// │  소유권 관점:                                                           │
// │    각 메서드가 self를 소비하고 새 self를 반환한다.                        │
// │    체인의 중간 값은 임시적으로만 존재하고 바로 다음 메서드로 이동한다.     │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 체이닝 소유권 흐름 ──────────────────────────────────────────────────
//
//  ZooBuilder::new("서울")   → builder_1 (소유)
//      .capacity(500)        → builder_1 소비 → builder_2 (소유)
//      .open()               → builder_2 소비 → builder_3 (소유)
//      .add_section("맹수관") → builder_3 소비 → builder_4 (소유)
//      .build()              → builder_4 소비 → String (소유)
//
//  중간 builder들은 모두 임시 — 스택에 생겼다 바로 이동

#[derive(Debug)]
pub struct ZooBuilder {
    name:     String,
    capacity: u32,
    open:     bool,
    sections: Vec<String>,
}

impl ZooBuilder {
    pub fn new(name: &str) -> Self {
        ZooBuilder {
            name:     name.to_string(),
            capacity: 100,
            open:     false,
            sections: Vec::new(),
        }
    }

    // mut self → 수정 → self 반환 (소유권 체이닝)
    pub fn capacity(mut self, cap: u32) -> Self {
        self.capacity = cap;
        self
    }

    pub fn open(mut self) -> Self {
        self.open = true;
        self
    }

    pub fn add_section(mut self, section: &str) -> Self {
        self.sections.push(section.to_string());
        self
    }

    // 마지막 — self를 소비하고 최종 결과물 반환
    pub fn build(self) -> String {
        format!("{} (수용:{}, 개방:{}, 구역:{:?})",
            self.name, self.capacity, self.open, self.sections)
    }
}

pub fn run() {
    println!("\n─── 패턴17: 빌더 패턴 ───");

    // 메서드 체이닝 — 각 메서드가 self를 반환하므로 연속 호출 가능
    let result = ZooBuilder::new("서울 동물원")
        .capacity(500)
        .open()
        .add_section("맹수관")
        .add_section("조류관")
        .add_section("파충류관")
        .build();

    println!("  {}", result);
}
