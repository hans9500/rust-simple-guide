// ┌───────────────────────────────────────────────────────────────────────┐
// │  패턴16: pub / 가시성(Visibility) + impl                               │
// │                                                                       │
// │  가시성 종류:                                                           │
// │    (없음)       같은 모듈 안에서만 접근 가능 (private)                  │
// │    pub          어디서든 접근 가능 (public)                             │
// │    pub(crate)   같은 crate 안에서만 접근 가능                           │
// │    pub(super)   부모 모듈까지 접근 가능                                 │
// │    pub(in path) 지정한 경로의 모듈까지만 접근 가능                       │
// │                                                                       │
// │  캡슐화 원칙:                                                           │
// │    필드를 private으로 두고 pub 메서드로만 접근하게 한다.                 │
// │    불변 조건(invariant)을 impl 안에서 보장할 수 있다.                    │
// └───────────────────────────────────────────────────────────────────────┘

// ── 가시성 예시 모듈 ──────────────────────────────────────────────────────
pub mod zoo_enclosure {
    pub struct PrivateLion {
        name:      String,      // private — 외부 직접 접근 불가
        pub age:   u32,         // pub — 직접 접근 가능
        pub(crate) health: u32, // pub(crate) — 같은 crate 내부에서만
    }

    impl PrivateLion {
        // pub — 어디서든 호출 가능
        pub fn new(name: &str, age: u32) -> Self {
            PrivateLion { name: name.to_string(), age, health: 100 }
        }

        // pub — name의 유일한 공개 접근 방법
        pub fn name(&self) -> &str { &self.name }

        // pub — health의 공개 접근 (검증 포함)
        pub fn set_health(&mut self, h: u32) {
            // 불변 조건 보장: health는 0~100
            self.health = h.min(100);
        }

        // pub(crate) — 같은 crate 안에서만 호출 가능
        pub(crate) fn internal_status(&self) -> String {
            format!("{}(체력:{})", self.name, self.health)
        }

        // private — 이 모듈 안에서만 사용
        fn _secret_data(&self) -> String {
            format!("비밀: {}", self.name)
        }
    }
}

pub fn run() {
    println!("\n─── 패턴16: 가시성(Visibility) ───");

    let mut lion = zoo_enclosure::PrivateLion::new("Simba", 5);

    println!("  pub fn name():  {}", lion.name());   // pub 메서드
    println!("  pub age:        {}", lion.age);       // pub 필드
    // lion.name = "...";   // 컴파일 에러: private 필드
    // lion._secret_data(); // 컴파일 에러: private 메서드

    lion.set_health(150);                             // 내부에서 100으로 클램프
    println!("  health(150→):  {}", lion.health);     // pub(crate) — 같은 crate OK

    // pub(crate) 메서드 — 같은 crate이므로 OK
    println!("  internal:      {}", lion.internal_status());
}
