// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 1-1.  왜 라이프타임이 필요한가 — dangling reference              │
// │                                                                       │
// │  dangling reference(허상 참조):                                        │
// │  이미 해제된 메모리를 가리키는 참조.                                    │
// │  C/C++에서는 런타임 크래시나 보안 취약점의 주원인이다.                   │
// │  Rust는 이를 컴파일 타임에 100% 방지한다.                              │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 도식: dangling reference 문제 ───────────────────────────────────────
//
//  아래 코드는 Rust에서 컴파일 에러가 난다 (의도적으로 보여주는 예):
//
//  fn get_name() -> &str {       // 라이프타임 명시 없음 → 컴파일 에러
//      let name = String::from("Simba");
//      &name                     // name에서 빌린 참조를 반환
//  }   // ← name 스코프 끝 → drop(name) → 힙 해제
//      //   반환된 &str은 해제된 메모리를 가리킴!
//
//  ──────────────────────────────── 시간 흐름 ──▶
//  name 수명:  [──────────────]  함수 안에서만
//  반환 &str:  [──────────────────────▶]  함수 밖에서도 사용
//                               ↑ name보다 오래 살려 함 → 에러!
//
//  Rust 컴파일러 오류 메시지:
//  error[E0106]: missing lifetime specifier
//  또는
//  error[E0515]: cannot return reference to local variable `name`
//
// ─── 올바른 패턴: 외부에서 받은 참조를 반환 ─────────────────────────────
//
//  fn get_first_word(s: &str) -> &str {
//      // s가 살아있는 동안 반환값도 유효 (생략 규칙 적용)
//      ...
//  }
//
//  ──────────────────────────────── 시간 흐름 ──▶
//  s 수명:      [────────────────────────────]  caller가 관리
//  반환 &str:   [────────────────────────────]  s와 같은 수명
//  ∴ dangling 없음

// 올바른 예: 외부에서 받은 참조를 일부 반환
pub fn first_word(sentence: &str) -> &str {
    // sentence: &str 의 라이프타임 = 반환 &str 의 라이프타임 (생략 규칙)
    let bytes = sentence.as_bytes();
    for (i, &byte) in bytes.iter().enumerate() {
        if byte == b' ' {
            return &sentence[..i];
        }
    }
    sentence
}

pub fn run() {
    println!("\n─── Part 1-1: dangling reference 방지 ───");

    // 올바른 패턴 — 외부 데이터에서 슬라이스 반환
    let sentence = String::from("사자 동물원 거주중");
    let word = first_word(&sentence);
    println!("  첫 단어: {}", word);
    // sentence가 살아있으므로 word(슬라이스)도 유효

    // 수명 확인 — sentence가 먼저 drop되면 word는 무효
    {
        let s2 = String::from("오리 날다");
        let w2 = first_word(&s2);
        println!("  s2의 첫 단어: {}", w2); // s2가 살아있으므로 OK
    }   // s2 drop → w2도 여기서 더 이상 쓸 수 없음
    // println!("{}", w2); // ← s2 스코프 밖이므로 컴파일 에러
}
