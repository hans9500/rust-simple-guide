// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 1-5.  라이프타임 바운드 — T: 'a 와 'static                       │
// │                                                                       │
// │  T: 'a  — "T 타입의 값은 'a 동안 유효하다"                              │
// │           T가 참조를 포함한다면, 그 참조들의 수명이 최소 'a 이상이어야.   │
// │                                                                       │
// │  T: 'static — "T는 프로그램 전체 실행 기간 동안 유효하다"                │
// │               'static = 가장 긴 라이프타임                              │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 'static 이 되는 타입들 ──────────────────────────────────────────────
//
//  &'static str    — 문자열 리터럴 ("hello"), 바이너리에 내장
//  u32, i32, bool  — 소유된 primitive, 참조 없음 → 'static
//  String          — 소유된 타입, 참조 없음 → 'static
//  Vec<T>          — T: 'static 이면 Vec<T>: 'static
//
//  &'a str (a ≠ static) — 일시적 참조 → 'static 아님
//  struct Foo<'a> { r: &'a str } — 'a에 의존 → 'static 아님

use std::fmt;

// T: 'static 바운드 — T를 스레드나 장기 저장소에 보낼 때 필요
pub fn store_forever<T: fmt::Display + 'static>(val: T) {
    // T: 'static 이므로 T의 수명이 프로그램 끝까지 보장됨
    // 스레드에 T를 전달하거나 Box에 넣어 장기 보관 가능
    println!("  'static 값 저장: {}", val);
}

// T: 'a 바운드 — T가 최소 'a 동안 살아있어야 함
pub fn use_for_duration<'a, T: fmt::Display + 'a>(_container: &'a (), val: T) {
    println!("  'a 동안 유효: {}", val);
}

pub fn run() {
    println!("\n─── Part 1-5: 라이프타임 바운드 ───");

    // 'static 타입들
    let s: &'static str = "바이너리에 내장된 리터럴";
    store_forever(s);
    store_forever(42u32);
    store_forever(String::from("소유된 String"));

    // &'static str — 프로그램 내내 유효
    let animal_names: &[&'static str] = &["Simba", "Nala", "Mufasa"];
    for name in animal_names {
        println!("  정적 이름: {}", name);
    }

    // T: 'a — 특정 스코프 안에서만 유효
    let container = ();
    let temp_name = String::from("임시 사자");
    use_for_duration(&container, &temp_name);
}
