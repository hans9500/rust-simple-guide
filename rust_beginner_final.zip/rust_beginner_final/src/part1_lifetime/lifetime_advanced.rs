// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 1 심화.  라이프타임 고급 패턴과 컴파일 에러 해부                   │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 심화 1: 'a 이름이 같을 때의 정확한 의미 ─────────────────────────────
//
//  fn longer<'a>(x: &'a str, y: &'a str) -> &'a str
//
//  'a 가 두 인자에 동일하게 붙은 의미:
//    "x와 y 모두 최소 'a 동안 유효해야 한다."
//    컴파일러는 'a를 두 수명의 교집합(intersection)으로 결정한다.
//    즉, 'a = min(수명_x, 수명_y)
//
//  ─── 시간 흐름 도식 ──────────────────────────────────────────────────
//
//  case 1: s1이 더 긴 경우
//  s1 수명: [────────────────────────────────]  (더 긺)
//  s2 수명: [──────────────]                    (더 짧음)
//  'a     = [──────────────]  ← min = s2의 수명
//  반환값:  최대 'a 까지만 유효
//
//  따라서 s2가 drop된 후 반환값을 사용하면 컴파일 에러:
//
//  let s1 = String::from("긴 문자열");
//  let result;
//  {
//      let s2 = String::from("짧");
//      result = longer(&s1, &s2);   // 'a = s2의 수명
//  }   // s2 drop → 'a 끝
//  println!("{}", result);          // ← 에러: result의 수명('a)이 여기서 끝남
//
//  컴파일러 메시지:
//    error[E0597]: `s2` does not live long enough
//    note: `s2` is borrowed here (longer 호출 줄)
//    note: `s2` dropped here while still borrowed
//
//  왜 에러인가:
//    longer는 x 또는 y를 반환할 수 있다.
//    컴파일러는 반환값이 s2에서 온 것인지 s1에서 온 것인지 모른다.
//    최악의 경우(s2에서 반환)를 가정 → 'a = s2의 수명으로 제한.
//
//  case 2: 반환이 항상 x에서 온다면 다른 라이프타임을 쓸 수 있다:
//
//  fn always_x<'a>(x: &'a str, _y: &str) -> &'a str { x }
//  // y의 수명과 반환값 수명이 무관 → _y에 별도 라이프타임 불필요

fn longer<'a>(x: &'a str, y: &'a str) -> &'a str {
    if x.len() >= y.len() { x } else { y }
}

fn always_x<'a>(x: &'a str, _y: &str) -> &'a str {
    x   // y의 수명은 반환값에 영향 없음
}

fn demo_lifetime_intersection() {
    println!("\n  [심화1: 'a = min(수명_x, 수명_y)]");

    let s1 = String::from("긴 문자열입니다");

    // OK: s2와 result가 같은 스코프
    {
        let s2 = String::from("짧음");
        let result = longer(&s1, &s2);
        println!("  result(스코프 안): {}", result);
    }   // s2 drop → result 사용 불가

    // always_x: y의 수명과 무관
    let result2;
    {
        let temp = String::from("임시값");
        result2 = always_x(&s1, &temp); // temp 수명 무관
    }   // temp drop. result2는 s1에서 빌림 → 여전히 유효
    println!("  always_x 결과: {}", result2);

    // 두 파라미터가 다른 수명이 필요한 경우
    // fn first<'a, 'b>(x: &'a str, y: &'b str) -> &'a str { x }
    // → x와 y가 서로 다른 수명을 가져도 되는 경우
    fn first<'a, 'b>(x: &'a str, _y: &'b str) -> &'a str { x }

    let long_lived = String::from("오래 사는 값");
    let result3;
    {
        let short_lived = String::from("짧은 값");
        result3 = first(&long_lived, &short_lived); // short_lived 수명 무관
    }
    println!("  first 결과: {}", result3); // OK: long_lived 여전히 유효
}

// ─── 심화 2: 반환 라이프타임 허용 vs 불허 ────────────────────────────────
//
//  허용되는 경우: 반환값이 입력에서 온 참조
//
//  fn get_name<'a>(animal: &'a Animal) -> &'a str {
//      &animal.name    // animal이 살아있는 동안 유효
//  }
//
//  불허되는 경우: 함수 내부에서 만든 값의 참조
//
//  fn make_name() -> &str {            // ← 어떤 수명? 컴파일 에러
//      let name = String::from("Simba");
//      &name                           // name은 함수 끝에서 drop됨
//  }   // ← name drop → &name은 dangling reference
//
//  컴파일러 메시지:
//    error[E0106]: missing lifetime specifier
//    error[E0515]: cannot return reference to local variable `name`
//
//  해결: String을 반환 (소유권 이전)
//  fn make_name() -> String {
//      "Simba".to_string()    // 소유권을 caller에게 넘김
//  }
//
//  ─── 도식: dangling reference 방지 ──────────────────────────────────
//
//  fn make_name() → &str:
//
//  [함수 실행 중]         [함수 반환 후]
//  스택 프레임:           스택 프레임 해제:
//  ┌──────────┐          ┌──────────┐
//  │ name     │          │ (해제됨) │
//  │  ptr ────┼──▶힙     │          │
//  │  len=5   │          └──────────┘
//  └──────────┘                    ↑
//  반환된 &str: ptr ─────────────────┘  ← 해제된 메모리를 가리킴!
//                                           (dangling reference)
//
//  Rust 컴파일러가 이 상황을 100% 방지한다.

struct DemoAnimal { name: String, age: u32 }

impl DemoAnimal {
    fn new(name: &str, age: u32) -> Self {
        DemoAnimal { name: name.to_string(), age }
    }

    // 허용: &self에서 빌린 참조 반환 (생략 규칙 3)
    // 실제 시그니처: fn name<'a>(&'a self) -> &'a str
    fn name(&self) -> &str { &self.name }

    // 허용: 소유권 이전 (참조가 아님)
    fn name_owned(&self) -> String { self.name.clone() }

    // 불허 패턴 — 주석으로만
    // fn name_dangling(&self) -> &str {
    //     let local = format!("{} (동물)", self.name);
    //     &local   // ← 에러: local은 함수 끝에서 drop
    //     // 에러: cannot return reference to local variable `local`
    // }
}

fn demo_return_lifetime() {
    println!("\n  [심화2: 반환 라이프타임 허용/불허]");

    let animal = DemoAnimal::new("Simba", 5);

    // 허용: &self의 필드 참조 반환
    let name_ref: &str = animal.name();     // animal 수명에 묶임
    println!("  name_ref: {}, age: {}", name_ref, animal.age); // age 필드 사용
    // animal이 살아있는 동안 name_ref 유효

    // 허용: 소유권 이전
    let name_owned: String = animal.name_owned();
    println!("  name_owned: {}", name_owned);
    // name_owned는 animal과 무관한 독립 String

    // 수명이 묶이는 증거:
    let ref_from_short: &str;
    {
        let short = DemoAnimal::new("임시", 0);
        // ref_from_short = short.name(); // ← 에러: short가 이 블록에서 drop
        // 에러: `short` does not live long enough
        let _ = short.name();  // 블록 안에서만 사용 → OK
    }
    // ref_from_short는 여기서 사용 불가 (short이 drop됨)
    let _ = ref_from_short;  // 컴파일러가 이 줄 경고 — 미사용 변수
}

// ─── 심화 3: 'a: 'b 라이프타임 서브타이핑(subtyping) ─────────────────────
//
//  'a: 'b (읽기: "'a outlives 'b", 'a는 'b보다 오래 산다)
//
//  'a: 'b 는 "'a는 'b의 서브타입이다"라는 의미다.
//  즉 'a가 사용되는 모든 곳에 'b를 쓸 수 있다.
//  'a ≥ 'b (수명 측면에서)
//
//  언제 필요한가:
//  두 라이프타임이 있고, 반환값의 수명이 더 짧아야 할 때.
//
//  fn longer_with_constraint<'a: 'b, 'b>(
//      x: &'a str, y: &'b str
//  ) -> &'b str
//
//  'a: 'b → x는 y보다 오래 산다.
//  반환값은 'b (더 짧은 쪽)로 제한.
//  x에서 반환해도 'b로 줄어들기 때문에 안전.

fn longer_sub<'a: 'b, 'b>(x: &'a str, y: &'b str) -> &'b str {
    if x.len() >= y.len() { x } else { y }
    // x: &'a str, 반환: &'b str
    // 'a: 'b 이므로 &'a str을 &'b str로 줄여서 반환 가능
}

fn demo_subtyping() {
    println!("\n  [심화3: 'a: 'b 서브타이핑]");

    let long_str = String::from("긴 문자열");
    let result;
    {
        let short_str = String::from("짧음");
        // longer_sub: 'a: 'b 덕분에 'b(=short_str 수명)로 제한됨
        result = longer_sub(&long_str, &short_str);
        println!("  서브타이핑 result: {}", result);
        // result는 short_str 스코프 안에서만 유효
    }
    // println!("{}", result); // ← 에러: result의 수명이 short_str에 묶임
}

// ─── 심화 4: struct 라이프타임 실수 패턴 ─────────────────────────────────
//
//  struct Keeper<'a> { animal: &'a Animal }
//
//  실수 1: struct가 원본보다 오래 살려는 시도
//
//  let keeper;
//  {
//      let simba = Animal::new("Simba", 5);
//      keeper = Keeper { animal: &simba };  // simba 빌림
//  }   // simba drop
//  println!("{}", keeper.animal.name());    // ← 에러
//  // 에러: `simba` does not live long enough
//
//  실수 2: 라이프타임 없이 struct에 참조 필드
//
//  struct Bad {
//      name: &str,   // ← 에러: missing lifetime specifier
//  }
//  // 해결: struct Good<'a> { name: &'a str }
//  // 또는: struct Good { name: String } (소유)
//
//  실수 3: 메서드 반환값의 수명
//
//  impl<'a> Keeper<'a> {
//      // 생략 규칙 3: 반환값 수명 = self 수명
//      fn animal_name(&self) -> &str { self.animal.name() }
//      // 실제: fn animal_name<'b>(&'b self) -> &'b str
//      //
//      // 만약 'a 수명으로 반환하고 싶다면:
//      // fn animal_name(&self) -> &'a str { self.animal.name() }
//      // 이 경우 반환값이 self보다 오래 살 수 있음 (animal이 살아있는 한)
//  }

struct Keeper<'a> {
    name:   &'a str,
    animal: &'a DemoAnimal,
}

impl<'a> Keeper<'a> {
    fn new(name: &'a str, animal: &'a DemoAnimal) -> Self {
        Keeper { name, animal }
    }

    // 생략 규칙 3 적용: 반환 수명 = self 수명 ('b)
    fn intro(&self) -> &str {
        self.name   // &'b str (self가 사는 동안)
    }

    // 명시적으로 'a 수명 반환:
    // animal이 사는 동안 유효 (self보다 길 수 있음)
    fn animal_name(&self) -> &'a str {
        self.animal.name()  // &'a str
    }
}

fn demo_struct_lifetime() {
    println!("\n  [심화4: struct 라이프타임 실수 패턴]");

    let simba = DemoAnimal::new("Simba", 5);
    let keeper_name = String::from("사육사 김씨");

    let keeper = Keeper::new(&keeper_name, &simba);
    println!("  intro(): {}", keeper.intro());
    println!("  animal_name(): {}", keeper.animal_name());

    // intro()와 animal_name()의 수명 차이
    let animal_name_ref: &str;
    {
        let k2 = Keeper::new("이씨", &simba);
        // animal_name_ref = k2.intro();         // ← 에러: k2가 이 블록에서 drop
        animal_name_ref = k2.animal_name();       // OK: simba 수명('a)으로 반환
    }
    // k2 drop됐지만 animal_name_ref는 simba('a)에 묶임 → 여전히 유효
    println!("  animal_name (k2 drop 후): {}", animal_name_ref);
}

// ─── 심화 5: 라이프타임 생략 규칙이 실패하는 경우 ────────────────────────
//
//  생략 규칙이 적용되지 않아 명시적으로 써야 하는 경우:
//
//  1. 입력 참조가 여러 개이고 반환 참조가 그 중 하나
//     fn pick(x: &str, y: &str) -> &str  // ← 에러: 어느 것의 수명?
//     // 해결: fn pick<'a>(x: &'a str, y: &str) -> &'a str
//     //  또는: fn pick<'a>(x: &'a str, y: &'a str) -> &'a str
//
//  2. struct 메서드에서 self가 아닌 파라미터의 수명을 반환
//     impl<'a> Keeper<'a> {
//         fn get_external<'b>(&self, s: &'b str) -> &'b str { s }
//         // 반환이 self가 아닌 s에서 옴 → 생략 불가
//     }
//
//  3. 두 struct 라이프타임이 다른 메서드
//     fn combine<'a, 'b>(a: &'a str, b: &'b str) -> String {
//         format!("{} {}", a, b)  // String 반환 → 참조 아님 → 생략 OK
//     }

fn demo_elision_failure() {
    println!("\n  [심화5: 생략 규칙이 실패하는 경우]");

    // 1. 여러 입력 참조 중 하나를 반환 → 명시 필요
    fn pick_longer<'a>(x: &'a str, _y: &str) -> &'a str { x }

    let a = "긴 문자열";
    let b = "짧";
    println!("  pick_longer: {}", pick_longer(a, b));

    // 2. String 반환은 수명 무관
    fn combine(a: &str, b: &str) -> String {
        format!("{} + {}", a, b)  // 소유된 값 반환 → 수명 불필요
    }
    println!("  combine: {}", combine("Simba", "Nala"));

    // 3. 'static 수명 — 프로그램 전체
    fn get_static() -> &'static str {
        "이 문자열은 바이너리에 내장됨"  // 'static → 수명 제약 없음
    }
    println!("  static: {}", get_static());
}

pub fn run() {
    println!("\n══════ Part 1 심화: 라이프타임 고급 패턴 ══════");
    demo_lifetime_intersection();
    demo_return_lifetime();
    demo_subtyping();
    demo_struct_lifetime();
    demo_elision_failure();
}
