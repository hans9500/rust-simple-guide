// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 1.  라이프타임(Lifetime)                                          ║
// ║                                                                       ║
// ║  라이프타임은 "참조가 얼마나 오래 유효한가"를 컴파일러가 추적하는 방법.    ║
// ║  런타임에 존재하지 않는다 — 순수하게 컴파일 타임 개념이다.                ║
// ║  목적: dangling reference(허상 참조)를 컴파일 타임에 방지한다.           ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod dangling;        // 1-1: dangling reference 문제
pub mod elision;         // 1-2: 생략 규칙
pub mod explicit;        // 1-3: 명시적 'a
pub mod struct_lifetime; // 1-4: struct + 'a
pub mod bounds;          // 1-5: T: 'a, 'static

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 1: 라이프타임(Lifetime)");
    println!("══════════════════════════════════════════════════════════");
    dangling::run();
    elision::run();
    explicit::run();
    struct_lifetime::run();
    bounds::run();
    lifetime_advanced::run();
}
pub mod lifetime_advanced;
