// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 1-4.  struct에 라이프타임 — 빌린 값을 필드로 가질 때              │
// └───────────────────────────────────────────────────────────────────────┘

// ─── String(소유) vs &str(빌림) 필드 비교 ────────────────────────────────
//
//  struct OwnedAnimal {          struct BorrowedAnimal<'a> {
//      name: String,                 name: &'a str,   // 외부에서 빌림
//  }                             }
//
//  OwnedAnimal 메모리:            BorrowedAnimal 메모리:
//  스택              힙            스택
//  ┌──────────┐                   ┌──────────────┐
//  │ name     │                   │ name_ptr   ──┼──▶ (외부 문자열)
//  │  ptr ────┼──▶ "Simba"        │ name_len     │
//  │  len=5   │    (소유)          └──────────────┘
//  │  cap=8   │                   ↑ 외부 데이터가 살아있어야만 유효
//  └──────────┘                   ↑ 'a = 빌린 데이터의 수명
//
//  'a 선언의 의미:
//  "이 struct는 'a 동안만 유효하다.
//   'a 가 끝나면(원본 데이터가 drop되면) 이 struct도 무효다."

// ─── impl<'a> Keeper<'a> ─────────────────────────────────────────────────
//
//  struct에 'a 가 있으면 impl 블록에도 'a 를 선언해야 한다.
//  impl<'a> Keeper<'a>
//   ↑                ↑
//   'a 파라미터 선언   'a 를 사용하는 타입

pub struct AnimalTag<'a> {
    pub label:   &'a str,   // 외부 문자열을 빌림
    pub cage_id: u32,
}

impl<'a> AnimalTag<'a> {
    pub fn new(label: &'a str, cage_id: u32) -> Self {
        AnimalTag { label, cage_id }
    }

    // 반환 &str의 수명 = self의 수명 (생략 규칙 3)
    // 실제: fn label<'b>(&'b self) -> &'b str
    // 그러나 self.label은 'a 수명이므로
    // 더 정확히는: fn label(&self) -> &'a str
    pub fn label(&self) -> &'a str {
        self.label
    }

    pub fn describe(&self) -> String {
        format!("태그[{}] 우리#{}", self.label, self.cage_id)
    }
}

// 라이프타임 + 제네릭 동시 사용
// 'a: 빌린 데이터의 수명, T: 소유된 동물 타입
pub struct ZooBadge<'a, T> {
    pub keeper_name: &'a str,   // 빌림
    pub animal:      T,         // 소유
}

impl<'a, T: std::fmt::Debug> ZooBadge<'a, T> {
    pub fn new(keeper_name: &'a str, animal: T) -> Self {
        ZooBadge { keeper_name, animal }
    }
    pub fn show(&self) {
        println!("  배지: {} 담당 → {:?}", self.keeper_name, self.animal);
    }
}

pub fn run() {
    println!("\n─── Part 1-4: struct 라이프타임 ───");

    let text = String::from("사자");     // text가 원본 데이터 소유
    {
        let tag = AnimalTag::new(&text, 1); // tag는 text를 빌림
        println!("  {}", tag.describe());
        println!("  label: {}", tag.label());
    }   // tag drop — text는 여전히 유효

    // tag가 text보다 오래 살 수 없다:
    // let tag2;
    // { let t = String::from("임시"); tag2 = AnimalTag::new(&t, 2); }
    // println!("{}", tag2.label()); // ← t가 drop됐으므로 컴파일 에러

    // 라이프타임 + 제네릭
    let badge = ZooBadge::new("김씨 사육사", 42u32);
    badge.show();
}
