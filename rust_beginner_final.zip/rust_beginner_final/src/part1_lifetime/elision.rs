// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 1-2.  라이프타임 생략 규칙 (Lifetime Elision Rules)              │
// │                                                                       │
// │  규칙 1: 입력 참조마다 각자 다른 라이프타임 파라미터를 부여.               │
// │          fn f(x: &T, y: &U)  →  fn f<'a,'b>(x:&'a T, y:&'b U)       │
// │                                                                       │
// │  규칙 2: 입력 참조가 정확히 하나면, 출력 = 그 입력의 라이프타임.          │
// │          fn f(x: &T) -> &U  →  fn f<'a>(x:&'a T) -> &'a U           │
// │                                                                       │
// │  규칙 3: 메서드(&self 또는 &mut self 있으면) 출력 = self 라이프타임.    │
// │          fn f(&self, x: &T) -> &U  →  fn f<'a,'b>(&'a self, x:&'b T)│
// │                                           -> &'a U                   │
// └───────────────────────────────────────────────────────────────────────┘

// 규칙 2 적용 — 입력 하나, 생략 가능
// 실제: fn first_char<'a>(s: &'a str) -> &'a str
//
// 주의: 한글은 UTF-8에서 3바이트. s[..1]은 ASCII 전용이라 한글에서 패닉.
// char_indices()로 첫 번째 문자의 바이트 경계를 안전하게 찾는다.
pub fn first_char(s: &str) -> &str {
    match s.char_indices().nth(1) {
        Some((i, _)) => &s[..i],    // 두 번째 문자 시작 위치까지 = 첫 문자
        None         => s,          // 문자가 하나뿐이면 전체 반환
    }
}

// 규칙 3 적용 — &self 메서드, 생략 가능
pub struct Label {
    pub text: String,
}
impl Label {
    // 실제: fn get<'a>(&'a self) -> &'a str
    pub fn get(&self) -> &str {
        &self.text
    }
}

// 생략 불가 — 입력이 여러 개이고 출력이 그 중 하나
// fn ambiguous(x: &str, y: &str) -> &str { x }  // 컴파일 에러
// 명시적 'a 필요:
pub fn pick_first<'a>(x: &'a str, _y: &str) -> &'a str {
    x
}

pub fn run() {
    println!("\n─── Part 1-2: 라이프타임 생략 규칙 ───");

    let s = String::from("동물원");
    println!("  규칙2 (첫 글자): {}", first_char(&s));

    let label = Label { text: "사자 우리".to_string() };
    println!("  규칙3 (get): {}", label.get());

    let a = String::from("첫번째");
    let b = String::from("두번째");
    println!("  명시적 'a: {}", pick_first(&a, &b));
}
