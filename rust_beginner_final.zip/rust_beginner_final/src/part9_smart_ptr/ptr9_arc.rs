// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9-4.  Arc<T> — 멀티 스레드 공유 소유권                           │
// │             (Atomically Reference Counted)                            │
// │                                                                       │
// │  공식 std 문서:                                                         │
// │  "Arc<T> makes it thread safe to have multiple ownership of the       │
// │   same data, but it doesn't add thread safety to its data."           │
// │                                                                       │
// │  Arc<T> vs Rc<T>:                                                     │
// │    Rc<T>:  카운트 증감이 원자적(atomic)이 아님 → 단일 스레드만          │
// │    Arc<T>: 카운트 증감이 원자적 → 멀티 스레드 안전                      │
// │                                                                       │
// │  Arc<T>는 불변 → 스레드 간 가변 공유는 Mutex<T> / RwLock<T> 사용.     │
// │  Arc<RefCell<T>>는 불가 — RefCell은 Sync를 구현하지 않는다.            │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Arc vs Rc 선택 기준 ─────────────────────────────────────────────────
//
//  ┌──────────────────┬──────────────────┬──────────────────┐
//  │                  │  Rc<T>           │  Arc<T>          │
//  ├──────────────────┼──────────────────┼──────────────────┤
//  │ 스레드 안전       │ 단일 스레드만    │ 멀티 스레드 OK   │
//  │ 카운트 방식       │ 일반 usize       │ 원자적 AtomicUsize│
//  │ 성능             │ 빠름 (원자적 아님)│ 약간 느림         │
//  │ Send + Sync      │ 아님             │ T: Send+Sync이면 │
//  │ 가변성           │ 없음 (RefCell필요)│ 없음 (Mutex필요) │
//  └──────────────────┴──────────────────┴──────────────────┘

use std::sync::{Arc, Mutex};
use std::thread;
use crate::part2_patterns::animals::Lion;

pub fn run() {
    println!("\n─── Part 9-4: Arc<T> ───");

    // ── 기본 Arc 사용 ──────────────────────────────────────────────────────
    println!("\n  [Arc<T> 기본]");
    let lion = Arc::new(Lion::new("Simba", 5));
    println!("  strong_count: {}", Arc::strong_count(&lion));

    let lion2 = Arc::clone(&lion);
    println!("  clone 후 strong_count: {}", Arc::strong_count(&lion));
    println!("  lion2: {}", lion2.name());

    // ── 스레드에 Arc 전달 ──────────────────────────────────────────────────
    println!("\n  [Arc<T> + thread]");
    let shared_lion = Arc::new(Lion::new("공유 사자", 7));

    let mut handles = vec![];
    for i in 0..3 {
        let lion_ref = Arc::clone(&shared_lion);
        let handle = thread::spawn(move || {
            // 각 스레드에서 Arc를 통해 Lion에 접근 (읽기만)
            println!("    스레드 {}: {} ({}살)",
                i, lion_ref.name(), lion_ref.age());
        });
        handles.push(handle);
    }
    for h in handles { h.join().unwrap(); }
    println!("  스레드 완료 후 strong_count: {}", Arc::strong_count(&shared_lion));

    // ── Arc<Mutex<T>> — 스레드 간 가변 공유 ─────────────────────────────
    println!("\n  [Arc<Mutex<T>> — 스레드 간 가변 공유]");
    // Arc<RefCell<T>> 는 불가 — RefCell은 Sync 미구현
    // Arc<Mutex<T>>  는 가능 — Mutex는 Sync 구현
    let counter = Arc::new(Mutex::new(0u32));

    let mut handles = vec![];
    for _ in 0..5 {
        let c = Arc::clone(&counter);
        let handle = thread::spawn(move || {
            let mut num = c.lock().unwrap();  // Mutex 잠금
            *num += 1;
        });   // Mutex 잠금 해제 (MutexGuard drop)
        handles.push(handle);
    }
    for h in handles { h.join().unwrap(); }
    println!("  5개 스레드 후 카운터: {}", *counter.lock().unwrap());
}
