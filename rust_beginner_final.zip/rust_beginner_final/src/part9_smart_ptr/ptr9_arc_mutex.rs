// ┌──────────────────────────────────────────────────────────────────
// │ Part 9 보강: Arc<Mutex<T>> 멀티스레드 공유 상태
// │
// │ 공식 문서: std::sync::{Arc, Mutex, RwLock}
// │
// │ Arc<T>:   멀티스레드 Rc. 원자적 참조 카운팅.
// │ Mutex<T>: 상호 배제. 한 번에 하나의 스레드만 접근.
// │ RwLock<T>: 읽기는 여러 스레드, 쓰기는 하나.
// │
// │ Arc<Mutex<T>>: 여러 스레드에서 공유 + 수정
// └──────────────────────────────────────────────────────────────────

use std::sync::{Arc, Mutex, RwLock};
use std::thread;

pub fn run() {
    println!("\n  [Part 9 보강: Arc<Mutex<T>> 멀티스레드]");
    demo_arc_basic();
    demo_arc_mutex();
    demo_rwlock();
    demo_shared_zoo();
}

// ── Arc 기본: 스레드 간 불변 공유 ────────────────────────────────
fn demo_arc_basic() {
    println!("\n  ── Arc<T>: 스레드 간 불변 데이터 공유 ──");

    // Arc: 불변 데이터를 여러 스레드에서 공유
    let zoo_name = Arc::new(String::from("서울 동물원"));
    println!("  strong_count: {}", Arc::strong_count(&zoo_name));

    let mut handles = vec![];
    for i in 0..3 {
        let name = Arc::clone(&zoo_name);  // clone = 카운트 증가만
        let handle = thread::spawn(move || {
            println!("  스레드 {}: {} 에서 작업 중", i, name);
        });
        handles.push(handle);
    }

    for h in handles { h.join().unwrap(); }
    println!("  모든 스레드 완료, strong_count: {}",
             Arc::strong_count(&zoo_name));
}

// ── Arc<Mutex<T>>: 스레드 간 가변 공유 ──────────────────────────
fn demo_arc_mutex() {
    println!("\n  ── Arc<Mutex<T>>: 공유 가변 상태 ──");

    // Arc로 소유권 공유, Mutex로 배타 접근 보장
    let visitor_count = Arc::new(Mutex::new(0u32));
    let mut handles = vec![];

    for _ in 0..5 {
        let counter = Arc::clone(&visitor_count);
        let handle = thread::spawn(move || {
            // lock(): MutexGuard<u32> 반환 — drop 시 자동 해제
            let mut count = counter.lock().unwrap();
            *count += 1;
            // MutexGuard가 여기서 drop → 잠금 해제
        });
        handles.push(handle);
    }

    for h in handles { h.join().unwrap(); }

    let final_count = *visitor_count.lock().unwrap();
    println!("  5개 스레드 카운트 결과: {} (기대: 5)", final_count);

    // Mutex 잠금 오염(Poisoning): 스레드 패닉 시 Mutex가 오염됨
    // lock().unwrap()이 패닉 → is_poisoned()로 체크 가능
    println!("  오염 여부: {}", visitor_count.is_poisoned());
}

// ── RwLock: 읽기 많고 쓰기 적을 때 ──────────────────────────────
fn demo_rwlock() {
    println!("\n  ── RwLock: 읽기 다수, 쓰기 단수 ──");

    let animals = Arc::new(RwLock::new(vec![
        "사자".to_string(),
        "오리".to_string(),
    ]));

    // 여러 읽기 스레드
    let mut read_handles = vec![];
    for i in 0..3 {
        let data = Arc::clone(&animals);
        let h = thread::spawn(move || {
            let list = data.read().unwrap();  // 읽기 잠금 — 동시 가능
            println!("  읽기 스레드 {}: {} 마리", i, list.len());
        });
        read_handles.push(h);
    }
    for h in read_handles { h.join().unwrap(); }

    // 쓰기 스레드 — 단독 접근
    {
        let mut list = animals.write().unwrap();
        list.push("뱀".to_string());
        println!("  쓰기 후: {} 마리", list.len());
    }

    println!("  최종: {:?}", animals.read().unwrap().as_slice());
}

// ── 실전: 공유 동물원 상태 ────────────────────────────────────────
#[derive(Debug)]
struct ZooState {
    animals:  Vec<String>,
    visitors: u32,
    is_open:  bool,
}

impl ZooState {
    fn new() -> Self {
        ZooState { animals: Vec::new(), visitors: 0, is_open: true }
    }
}

fn demo_shared_zoo() {
    println!("\n  ── 실전: 공유 동물원 상태 ──");

    let zoo = Arc::new(Mutex::new(ZooState::new()));
    let mut handles = vec![];

    // 동물 추가 스레드들
    let new_animals = vec!["사자", "오리", "뱀", "코끼리"];
    for animal in new_animals {
        let zoo_ref = Arc::clone(&zoo);
        let h = thread::spawn(move || {
            let mut state = zoo_ref.lock().unwrap();
            state.animals.push(animal.to_string());
            println!("  {} 추가됨", animal);
        });
        handles.push(h);
    }

    // 방문객 카운트 스레드들
    for _ in 0..3 {
        let zoo_ref = Arc::clone(&zoo);
        let h = thread::spawn(move || {
            let mut state = zoo_ref.lock().unwrap();
            state.visitors += 10;
        });
        handles.push(h);
    }

    for h in handles { h.join().unwrap(); }

    // 최종 상태 확인
    let final_state = zoo.lock().unwrap();
    let mut sorted = final_state.animals.clone();
    sorted.sort();
    println!("  최종 동물: {:?}", sorted);
    println!("  총 방문객: {}", final_state.visitors);
    println!("  영업 중: {}", final_state.is_open);
}
