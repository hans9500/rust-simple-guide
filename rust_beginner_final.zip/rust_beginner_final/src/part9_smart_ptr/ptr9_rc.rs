// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9-2.  Rc<T> — 단일 스레드 공유 소유권 (Reference Counted)        │
// │                                                                       │
// │  Rc<T>는 단일 스레드 환경에서 하나의 값을 여러 곳에서 소유할 때 사용.   │
// │  내부적으로 참조 카운트(reference count)를 유지한다.                    │
// │  카운트가 0이 되면 값을 drop한다.                                       │
// │                                                                       │
// │  주의: Rc<T>는 Sync + Send를 구현하지 않는다 → 멀티 스레드 불가.       │
// │  멀티 스레드: Arc<T> 사용.                                             │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Rc<T> 메모리 구조 ────────────────────────────────────────────────────
//
//  힙 (RcBox<T>):
//  ┌────────────────────────────────────────┐
//  │  strong_count: usize  (강한 참조 수)   │
//  │  weak_count:   usize  (약한 참조 수)   │
//  │  value:        T      (실제 데이터)    │
//  └────────────────────────────────────────┘
//        ↑              ↑              ↑
//   Rc::clone()    Rc::downgrade()  Rc::strong_count()
//
//  스택 (각 Rc<T> 변수):
//  ┌──────────┐   ┌──────────┐   ┌──────────┐
//  │  ptr ────┼─┐ │  ptr ────┼─┤ │  ptr ────┼─┘
//  └──────────┘ └─┤          └──┘ └──────────┘
//               힙의 동일한 RcBox를 가리킴
//               strong_count = 3
//
//  Rc<T>가 drop될 때:
//    strong_count -= 1
//    strong_count == 0 이면 T를 drop하고 힙 해제

use std::rc::Rc;
use crate::part2_patterns::animals::Lion;

pub fn run() {
    println!("\n─── Part 9-2: Rc<T> ───");

    // ── 기본 사용 ─────────────────────────────────────────────────────────
    println!("\n  [Rc<T> 기본]");
    let lion = Rc::new(Lion::new("Simba", 5));
    println!("  생성 후 strong_count: {}", Rc::strong_count(&lion));

    // Rc::clone() — 포인터만 복사, 카운트 증가 (데이터 복사 아님)
    let lion2 = Rc::clone(&lion);  // Rc::clone 은 T::clone이 아님
    println!("  clone 후 strong_count: {}", Rc::strong_count(&lion));

    {
        let lion3 = Rc::clone(&lion);
        println!("  lion3 생성 후 strong_count: {}", Rc::strong_count(&lion));
        // lion3는 &T처럼 읽기만 가능 (&mut 불가 — 공유이므로)
        println!("  lion3 이름: {}", lion3.name());
    }   // lion3 drop → strong_count -= 1

    println!("  lion3 drop 후 strong_count: {}", Rc::strong_count(&lion));
    println!("  lion2 이름: {}", lion2.name());
    drop(lion2);
    println!("  lion2 drop 후 strong_count: {}", Rc::strong_count(&lion));

    // ── Rc<T>는 불변 — 읽기만 가능 ──────────────────────────────────────
    println!("\n  [Rc<T>는 불변 공유]");
    let shared = Rc::new(Lion::new("공유 사자", 5));
    let ref1 = Rc::clone(&shared);
    let ref2 = Rc::clone(&shared);

    println!("  ref1 name: {}", ref1.name());
    println!("  ref2 name: {}", ref2.name());
    // ref1.feed(); // 컴파일 에러: cannot borrow as mutable (Rc는 &mut 불가)
    // 가변성이 필요하면 RefCell<T>와 함께 사용

    // ── Rc<T> + Deref ────────────────────────────────────────────────────
    println!("\n  [Rc<T> Deref — 자동 역참조]");
    // Rc<T>는 Deref<Target = T>를 구현 → T의 메서드를 직접 호출 가능
    let rc_lion = Rc::new(Lion::new("Mufasa", 10));
    println!("  is_senior (Deref): {}", rc_lion.is_senior()); // Rc → Lion 자동

    // ── Rc를 함수에 전달 ──────────────────────────────────────────────────
    println!("\n  [Rc 함수 전달]");
    fn describe_lion(lion: &Rc<Lion>) {
        println!("  [fn] {} (strong_count: {})",
            lion.name(), Rc::strong_count(lion));
    }
    describe_lion(&rc_lion);

    // 이 시점에서 rc_lion의 strong_count
    println!("  rc_lion strong_count: {}", Rc::strong_count(&rc_lion));
}
