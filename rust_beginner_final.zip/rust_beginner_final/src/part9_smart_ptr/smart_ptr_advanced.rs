// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9 심화.  스마트 포인터 고급 — 실수 패턴과 안전한 사용법            │
// └───────────────────────────────────────────────────────────────────────┘

use std::rc::Rc;
use std::cell::RefCell;

// ─── 심화 1: 순환 참조 실제 메모리 누수 증명 ──────────────────────────────
//
//  Rc로 순환 참조를 만들면 strong_count가 0이 되지 않아
//  메모리가 절대 해제되지 않는다.
//
//  ┌─── a (Rc, strong=2) ───┐      ┌─── b (Rc, strong=2) ───┐
//  │ tail: Some(Rc::clone(b))│─────▶│ tail: Some(Rc::clone(a))│
//  └─────────────────────────┘◀─────└─────────────────────────┘
//
//  a를 drop: strong(a) = 2 → 1 (b.tail이 a를 참조)
//  b를 drop: strong(b) = 2 → 1 (a.tail이 b를 참조)
//  두 count 모두 0이 되지 않음 → 메모리 누수!
//
//  Drop이 호출되지 않는다는 증거:
//  impl Drop for ... 에 println! 추가 → 메시지 안 출력

#[derive(Debug)]
struct Node {
    id:   u32,
    next: Option<Rc<RefCell<Node>>>,
}

impl Node {
    fn new(id: u32) -> Rc<RefCell<Self>> {
        Rc::new(RefCell::new(Node { id, next: None }))
    }
}

impl Drop for Node {
    fn drop(&mut self) {
        println!("    [Drop] Node {} 해제", self.id);
    }
}

fn demo_cycle_leak() {
    println!("\n  [심화1: 순환 참조 메모리 누수 증명]");

    println!("  [정상 케이스 — Drop 호출됨]");
    {
        let a = Node::new(1);
        let b = Node::new(2);
        // b → a (단방향, 순환 없음)
        b.borrow_mut().next = Some(Rc::clone(&a));
    }
    // a, b 모두 drop → Drop 메시지 출력

    println!("\n  [순환 참조 — Drop 호출 안 됨!]");
    {
        let a = Node::new(10);
        let b = Node::new(20);
        a.borrow_mut().next = Some(Rc::clone(&b));  // a → b
        b.borrow_mut().next = Some(Rc::clone(&a));  // b → a (순환!)
        println!("  strong_count(a): {}", Rc::strong_count(&a));
        println!("  strong_count(b): {}", Rc::strong_count(&b));
    }
    // a, b가 스코프를 벗어나도 count가 1로 남아 Drop 미호출
    // → "Node 10/20 해제" 메시지가 안 나옴 → 메모리 누수!
    println!("  (Drop 메시지 없음 = 메모리 누수 발생!)");
}

// ─── 심화 2: RefCell 패닉 시나리오와 안전한 대안 ─────────────────────────
//
//  RefCell 규칙 위반 → 런타임 panic:
//    borrow() + borrow_mut() 동시 → BorrowMutError panic
//    borrow_mut() + borrow_mut() 동시 → BorrowMutError panic
//
//  안전한 대안: try_borrow() / try_borrow_mut()
//    → Result<Ref<T>, BorrowError> / Result<RefMut<T>, BorrowMutError>
//    → 실패 시 panic 대신 Err 반환

fn demo_refcell_panic() {
    println!("\n  [심화2: RefCell 패닉과 안전한 대안]");

    let cell = RefCell::new(vec![1u32, 2, 3]);

    // 안전: try_borrow
    match cell.try_borrow() {
        Ok(v)  => println!("  try_borrow OK: {:?}", *v),
        Err(e) => println!("  try_borrow 실패: {}", e),
    }

    // 동시 borrow 시뮬레이션 — try_borrow_mut으로 안전하게
    {
        let r1 = cell.borrow();              // 공유 빌림
        let result = cell.try_borrow_mut();  // 배타 빌림 시도
        match result {
            Ok(_)  => println!("  동시 배타 빌림: OK (불가능)"),
            Err(e) => println!("  동시 배타 빌림 실패(예상됨): {}", e),
        }
        drop(r1);
    }

    // r1 해제 후 배타 빌림 가능
    {
        let result = cell.try_borrow_mut();
        match result {
            Ok(mut v) => { v.push(4); println!("  배타 빌림 후 push: {:?}", *v); }
            Err(e)    => println!("  실패: {}", e),
        }
    }

    // panic 발생 시나리오 (주석으로만)
    // let r1 = cell.borrow();
    // let r2 = cell.borrow_mut(); // ← panic: already borrowed: BorrowMutError
}

// ─── 심화 3: Deref 강제 변환(Deref coercion) 연쇄 ────────────────────────
//
//  Deref coercion: &Box<String> → &String → &str 자동 변환
//
//  규칙:
//    T: Deref<Target = U> 이면 &T → &U 자동 변환
//
//  연쇄:
//    Box<String>: Deref<Target = String>
//    String:      Deref<Target = str>
//    → &Box<String> → &String → &str (두 단계 자동)
//
//  Vec<T>: Deref<Target = [T]>
//    → &Vec<i32> → &[i32] 자동
//
//  활용:
//    fn takes_str(s: &str) { ... }
//    let s = Box::new(String::from("hello"));
//    takes_str(&s);  // &Box<String> → &String → &str 자동 변환

fn takes_str(s: &str) {
    println!("    &str 받음: {}", s);
}
fn takes_slice(s: &[i32]) {
    println!("    &[i32] 받음: {:?}", s);
}

fn demo_deref_coercion() {
    println!("\n  [심화3: Deref 강제 변환 연쇄]");

    // Box<String> → String → str (두 단계)
    let boxed_str = Box::new(String::from("Simba"));
    takes_str(&boxed_str);          // &Box<String> → &String → &str
    takes_str(&*boxed_str);         // 명시적 역참조 → &String → &str
    takes_str(boxed_str.as_str());  // 직접 변환

    // Vec<i32> → [i32]
    let vec = vec![1i32, 2, 3, 4];
    takes_slice(&vec);              // &Vec<i32> → &[i32]
    takes_slice(&vec[1..3]);        // 슬라이스

    // String → str
    let owned = String::from("Nala");
    takes_str(&owned);              // &String → &str

    // Rc<String> → String → str
    let rc_str = Rc::new(String::from("Mufasa"));
    takes_str(&rc_str);             // &Rc<String> → &String → &str

    println!("\n  [Deref 연쇄 도식]");
    println!("  &Box<String> → &String → &str  (Box→String→str)");
    println!("  &Vec<T>      → &[T]            (Vec→slice)");
    println!("  &Rc<String>  → &String → &str  (Rc→String→str)");
}

// ─── 심화 4: Box<dyn Trait> + Clone 문제와 해결책 ────────────────────────
//
//  dyn Trait은 object-safe해야 하므로 Clone 직접 사용 불가:
//    Clone::clone() → Self 반환 → object-unsafe
//
//  해결: clone_box 메서드 추가
//    trait SoundClone: Sound {
//        fn clone_box(&self) -> Box<dyn SoundClone>;
//    }
//    impl<T: Sound + Clone + 'static> SoundClone for T {
//        fn clone_box(&self) -> Box<dyn SoundClone> {
//            Box::new(self.clone())
//        }
//    }

use crate::part2_patterns::animals::Lion;
use crate::part2_patterns::pattern2_trait::Sound;

trait SoundClone: Sound {
    fn clone_box(&self) -> Box<dyn SoundClone>;
}

impl<T: Sound + Clone + 'static> SoundClone for T {
    fn clone_box(&self) -> Box<dyn SoundClone> {
        Box::new(self.clone())
    }
}

fn demo_dyn_clone() {
    println!("\n  [심화4: Box<dyn Trait> + Clone 해결책]");

    let original: Box<dyn SoundClone> = Box::new(Lion::new("Simba", 5));
    let cloned = original.clone_box();

    println!("  original: {}", original.make_sound());
    println!("  cloned:   {}", cloned.make_sound());
    println!("  (Box<dyn Trait>는 Clone 불가 → clone_box 패턴으로 해결)");
}

// ─── 심화 5: Cell<T>의 내부 가변성 — UnsafeCell ──────────────────────────
//
//  Cell<T>와 RefCell<T>의 내부는 UnsafeCell<T>로 구현된다.
//  UnsafeCell은 Rust에서 공유 참조(&T)를 통해 수정을 허용하는 유일한 방법이다.
//
//  Cell<T>:
//    - T: Copy 타입에 최적화
//    - get(): T 복사 반환 (참조 아님)
//    - set(): T 설정
//    - borrow guard 없음 (안전: 값을 복사해서 내보내므로)
//
//  RefCell<T>:
//    - 어떤 타입이든 사용 가능
//    - borrow()/borrow_mut(): Ref/RefMut guard 반환
//    - 런타임 빌림 카운트 추적
//
//  언제 Cell vs RefCell:
//    T: Copy → Cell<T> (더 효율적)
//    T: !Copy → RefCell<T>

use std::cell::Cell;

fn demo_cell_vs_refcell() {
    println!("\n  [심화5: Cell vs RefCell 선택]");

    // Cell<T> — Copy 타입, 빠름
    struct Lion2 {
        name:   String,
        age:    Cell<u32>,      // Copy 타입 → Cell
        hungry: Cell<bool>,     // Copy 타입 → Cell
    }
    impl Lion2 {
        fn new(name: &str, age: u32) -> Self {
            Lion2 { name: name.to_string(), age: Cell::new(age), hungry: Cell::new(true) }
        }
        fn name(&self) -> &str { &self.name }
        // &self로 내부 상태 수정 가능 — Cell 덕분
        fn birthday(&self) { self.age.set(self.age.get() + 1); }
        fn feed(&self)     { self.hungry.set(false); }
    }

    let lion = Lion2::new("Simba", 4);
    println!("  [{}] Cell 전: 나이={}, 배고픔={}", lion.name(), lion.age.get(), lion.hungry.get());
    lion.birthday();    // &self로 수정 가능!
    lion.feed();
    println!("  [{}] Cell 후: 나이={}, 배고픔={}", lion.name(), lion.age.get(), lion.hungry.get());

    // RefCell<T> — 비Copy 타입
    struct Zoo2 {
        name:    String,
        animals: RefCell<Vec<String>>,  // Vec: !Copy → RefCell
    }
    impl Zoo2 {
        fn new(name: &str) -> Self {
            Zoo2 { name: name.to_string(), animals: RefCell::new(vec![]) }
        }
        fn name(&self) -> &str { &self.name }
        // &self로 Vec 수정 가능
        fn add(&self, animal: &str) {
            self.animals.borrow_mut().push(animal.to_string());
        }
    }

    let zoo = Zoo2::new("서울");
    zoo.add("사자");
    zoo.add("오리");
    println!("  [{}동물원] RefCell 동물들: {:?}", zoo.name(), zoo.animals.borrow());
}

pub fn run() {
    println!("\n══════ Part 9 심화: 스마트 포인터 고급 ══════");
    demo_cycle_leak();
    demo_refcell_panic();
    demo_deref_coercion();
    demo_dyn_clone();
    demo_cell_vs_refcell();
}
