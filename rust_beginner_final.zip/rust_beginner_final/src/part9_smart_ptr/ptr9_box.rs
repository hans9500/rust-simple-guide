// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9-1.  Box<T> — 힙 할당, 단일 소유권                              │
// │                                                                       │
// │  Box<T>는 데이터를 힙에 저장하고 스택에 포인터를 둔다.                  │
// │  단일 소유권: Box가 drop되면 힙 데이터도 해제.                          │
// │                                                                       │
// │  주요 용도:                                                             │
// │    1. 재귀 타입 (크기를 컴파일 타임에 알 수 없을 때)                    │
// │    2. 크기가 큰 데이터를 이동할 때 (포인터만 복사)                      │
// │    3. Box<dyn Trait> — 소유권 있는 trait object                        │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Box<T> 메모리 구조 ───────────────────────────────────────────────────
//
//  스택                  힙
//  ┌──────────────┐     ┌───────────────────────────┐
//  │ Box<Lion>    │     │ Lion { name_ptr, len, cap, │
//  │  ptr (8B) ───┼────▶│        age, hungry }       │
//  └──────────────┘     └───────────────────────────┘
//  8바이트 포인터만       실제 데이터 (Box가 소유)
//  스택에 있음
//
//  Box<dyn Sound> (fat pointer, 16바이트):
//  스택                  힙                    static
//  ┌──────────────┐     ┌──────────────────┐  ┌──────────────┐
//  │ data_ptr(8B)─┼────▶│ Lion 데이터       │  │ LION_VTABLE  │
//  │ vtbl_ptr(8B)─┼─────┼──────────────────┼─▶│ size, align, │
//  └──────────────┘     └──────────────────┘  │ drop, fns... │
//                                             └──────────────┘
//
// ─── 재귀 타입에서 Box가 필요한 이유 ─────────────────────────────────────
//
//  enum BadList {
//      Cons(i32, BadList),  // 크기 무한: BadList가 BadList를 포함
//      Nil,
//  }
//  // 컴파일 에러: recursive type `BadList` has infinite size
//
//  enum GoodList {
//      Cons(i32, Box<GoodList>),  // Box = 8바이트 포인터 → 크기 확정
//      Nil,
//  }

use crate::part2_patterns::animals::Lion;
use crate::part2_patterns::pattern2_trait::Sound;

// 재귀 enum — Box로 크기 확정
#[derive(Debug)]
enum AnimalList {
    Cons(String, Box<AnimalList>),   // 이름 + 다음 노드 (힙)
    Nil,
}

impl AnimalList {
    fn new() -> Self { AnimalList::Nil }

    fn prepend(self, name: &str) -> Self {
        AnimalList::Cons(name.to_string(), Box::new(self))
    }

    fn len(&self) -> usize {
        match self {
            AnimalList::Nil            => 0,
            AnimalList::Cons(_, tail)  => 1 + tail.len(),
        }
    }

    fn head(&self) -> Option<&str> {
        match self {
            AnimalList::Nil           => None,
            AnimalList::Cons(name, _) => Some(name),
        }
    }
}

pub fn run() {
    println!("\n─── Part 9-1: Box<T> ───");

    // ── 기본 힙 할당 ──────────────────────────────────────────────────────
    println!("\n  [Box<T> 기본 힙 할당]");
    let stack_lion = Lion::new("Stack", 1);     // 스택 (정확히는 소유권이 스택에)
    let heap_lion  = Box::new(Lion::new("Heap", 2));  // 힙에 저장

    // *를 통한 역참조(deref)
    println!("  stack: {}", stack_lion.name());
    println!("  heap:  {}", heap_lion.name());   // Box가 Deref 구현 → 자동 역참조
    println!("  heap 역참조: {}", (*heap_lion).name());

    // Box가 drop되면 힙 데이터도 해제
    {
        let temp = Box::new(Lion::new("Temp", 3));
        println!("  temp: {}", temp.name());
    }   // temp(Box) drop → 힙의 Lion도 해제

    // ── 재귀 타입 ─────────────────────────────────────────────────────────
    println!("\n  [재귀 타입 — AnimalList]");
    let list = AnimalList::new()
        .prepend("Kaa")
        .prepend("Nagini")
        .prepend("Simba");

    println!("  리스트 길이: {}", list.len());
    println!("  첫 번째: {:?}", list.head());

    // ── Box<dyn Trait> — 소유권 있는 trait object ─────────────────────────
    println!("\n  [Box<dyn Sound> — 소유권 있는 trait object]");
    // Vec<Box<dyn Sound>>: 여러 타입을 하나의 Vec에 — 소유권 있음
    // Vec<&dyn Sound>:     빌림. 원본이 살아있어야 함.
    use crate::part2_patterns::animals::{Duck, Snake};

    let mut zoo: Vec<Box<dyn Sound>> = Vec::new();
    zoo.push(Box::new(Lion::new("Simba", 5)));
    zoo.push(Box::new(Duck::new("Donald", 3)));
    zoo.push(Box::new(Snake::new("Nagini", 8, true)));
    zoo.push(Box::new(Snake::new("Kaa", 5, false)));

    for animal in &zoo {
        println!("  {}", animal.make_sound());
    }
    // zoo가 drop될 때 각 Box<dyn Sound>가 drop → 힙의 동물 데이터도 해제

    // ── 크기가 큰 데이터 이동 ─────────────────────────────────────────────
    println!("\n  [Box — 이동 시 포인터만 복사]");
    #[derive(Debug)]
    struct BigData { _data: [u8; 1024] }  // 1KB 데이터

    let big = Box::new(BigData { _data: [0u8; 1024] });
    let moved = big;  // Box 포인터(8B)만 이동, 힙 데이터는 그대로
    println!("  BigData(1KB) 이동 완료 — 포인터(8B)만 복사됨");
    drop(moved);      // 여기서 힙 해제
}
