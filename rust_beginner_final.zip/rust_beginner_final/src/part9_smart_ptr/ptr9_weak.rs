// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9-5.  Weak<T> — 순환 참조 방지                                   │
// │                                                                       │
// │  Rc::clone()   → strong_count 증가 → 값 drop을 막음                   │
// │  Rc::downgrade()→ weak_count 증가  → 값 drop을 막지 않음              │
// │                                                                       │
// │  Weak<T>.upgrade() → Option<Rc<T>>                                    │
// │    Some(rc): 원본이 아직 살아있음                                       │
// │    None:     원본이 이미 drop됨                                         │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 순환 참조 문제 ──────────────────────────────────────────────────────
//
//  Rc를 쓰다 보면 순환 참조가 생길 수 있다:
//
//  ┌─── a (Rc) ───┐      ┌─── b (Rc) ───┐
//  │ strong=1      │      │ strong=1      │
//  │ neighbor: ────┼─────▶│ neighbor: ───┼────┐
//  └───────────────┘      └──────────────┘    │
//        ▲                                     │
//        └─────────────────────────────────────┘
//
//  a와 b가 서로를 Rc로 참조 → strong_count가 절대 0이 안 됨 → 메모리 누수
//
//  해결: 한쪽을 Weak로:
//
//  ┌─── a (Rc) ───┐      ┌─── b (Rc) ───┐
//  │ strong=1      │      │ strong=1      │
//  │ child:  ──────┼─────▶│ parent: ─────┼──▶ (Weak, 카운트 안 올림)
//  └───────────────┘      └──────────────┘
//        ↑
//        b.parent.upgrade() → Some(Rc to a) or None

use std::rc::{Rc, Weak};
use std::cell::RefCell;

#[derive(Debug)]
struct ZooNode {
    name:     String,
    parent:   RefCell<Weak<ZooNode>>,     // 부모: Weak (순환 방지)
    children: RefCell<Vec<Rc<ZooNode>>>, // 자식: Rc (강한 참조)
}

impl ZooNode {
    fn new(name: &str) -> Rc<Self> {
        Rc::new(ZooNode {
            name:     name.to_string(),
            parent:   RefCell::new(Weak::new()),
            children: RefCell::new(vec![]),
        })
    }

    fn add_child(parent: &Rc<ZooNode>, child: &Rc<ZooNode>) {
        // 자식 → 부모: Weak 참조
        *child.parent.borrow_mut() = Rc::downgrade(parent);
        // 부모 → 자식: Rc 참조
        parent.children.borrow_mut().push(Rc::clone(child));
    }

    fn parent_name(&self) -> Option<String> {
        self.parent.borrow()
            .upgrade()                          // Weak → Option<Rc>
            .map(|p| p.name.clone())
    }
}

pub fn run() {
    println!("\n─── Part 9-5: Weak<T> — 순환 참조 방지 ───");

    // ── 기본 Weak 사용 ─────────────────────────────────────────────────────
    println!("\n  [Weak 기본 — upgrade()]");
    let strong = Rc::new("Simba".to_string());
    let weak: Weak<String> = Rc::downgrade(&strong);

    println!("  strong_count: {}", Rc::strong_count(&strong));
    println!("  weak_count:   {}", Rc::weak_count(&strong));

    // upgrade — 원본이 살아있으면 Some
    if let Some(val) = weak.upgrade() {
        println!("  upgrade() → Some: {}", val);
    }

    // strong drop → weak가 가리키는 값도 해제
    drop(strong);
    println!("  strong drop 후 upgrade(): {:?}", weak.upgrade()); // None

    // ── 트리 구조 — Weak로 부모 역참조 ───────────────────────────────────
    println!("\n  [트리 구조 — Weak 부모 참조]");
    let root  = ZooNode::new("동물원 본관");
    let wing1 = ZooNode::new("포유류관");
    let wing2 = ZooNode::new("파충류관");
    let cage1 = ZooNode::new("사자 우리");
    let cage2 = ZooNode::new("뱀 우리");

    ZooNode::add_child(&root,  &wing1);
    ZooNode::add_child(&root,  &wing2);
    ZooNode::add_child(&wing1, &cage1);
    ZooNode::add_child(&wing2, &cage2);

    // 자식에서 부모 이름 접근 (Weak::upgrade)
    println!("  cage1 부모: {:?}", cage1.parent_name());
    println!("  wing1 부모: {:?}", wing1.parent_name());
    println!("  root 부모:  {:?}", root.parent_name()); // None

    // strong_count: root만 강한 참조가 2개 (root 변수 + wing1의 children)
    println!("\n  [strong_count 확인]");
    println!("  root strong_count:  {}", Rc::strong_count(&root));   // 1
    println!("  wing1 strong_count: {}", Rc::strong_count(&wing1)); // 2 (변수 + root.children)
    println!("  cage1 strong_count: {}", Rc::strong_count(&cage1)); // 2

    // root drop 시 체인으로 자식들도 해제 (순환 없음)
    println!("\n  [스마트 포인터 전체 요약]");
    println!("  Box<T>         : 힙 할당, 단일 소유권, 재귀 타입");
    println!("  Rc<T>          : 단일 스레드 공유 소유권, 참조 카운팅");
    println!("  Arc<T>         : 멀티 스레드 공유 소유권, 원자적 카운팅");
    println!("  RefCell<T>     : 런타임 빌림 검사, interior mutability");
    println!("  Cell<T>        : Copy 타입 interior mutability");
    println!("  Weak<T>        : 비소유 참조, 순환 참조 방지");
    println!("  Rc<RefCell<T>> : 단일 스레드 공유 + 가변");
    println!("  Arc<Mutex<T>>  : 멀티 스레드 공유 + 가변");
}
