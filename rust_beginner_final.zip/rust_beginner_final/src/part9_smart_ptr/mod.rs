// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 9.  스마트 포인터(Smart Pointer)                                 ║
// ║                                                                       ║
// ║  공식 std 문서 기반.                                                    ║
// ║                                                                       ║
// ║  ptr9_box      — Box<T>: 힙 할당, 단일 소유권, 재귀 타입               ║
// ║  ptr9_rc       — Rc<T>: 단일 스레드 공유 소유권, 참조 카운팅            ║
// ║  ptr9_refcell  — RefCell<T>: 런타임 빌림 검사 (interior mutability)    ║
// ║  ptr9_arc      — Arc<T>: 멀티 스레드 공유 소유권                       ║
// ║  ptr9_weak     — Weak<T>: 순환 참조 방지                               ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod ptr9_box;
pub mod ptr9_rc;
pub mod ptr9_refcell;
pub mod ptr9_arc;
pub mod ptr9_weak;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 9: 스마트 포인터(Smart Pointer)");
    println!("══════════════════════════════════════════════════════════");
    ptr9_box::run();
    ptr9_rc::run();
    ptr9_refcell::run();
    ptr9_arc::run();
    ptr9_weak::run();
    smart_ptr_advanced::run();
    ptr9_arc_mutex::run();
}
pub mod smart_ptr_advanced;
pub mod ptr9_rc_refcell_deep;
pub mod ptr9_arc_mutex;
