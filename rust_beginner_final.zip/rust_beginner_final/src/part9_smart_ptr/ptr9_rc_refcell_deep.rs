// ┌─────────────────────────────────────────────────────────────────────┐
// │  Rc/RefCell/Arc 심화 — 조합 패턴과 실전 예제                         │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Rc<RefCell<T>> — 공유 가변성 패턴                                   │
// │                                                                     │
// │  let shared = Rc::new(RefCell::new(vec![]));                        │
// │                                                                     │
// │  메모리 구조:                                                        │
// │  ┌───────────┐    ┌──────────────────────────┐                     │
// │  │ owner_a   │──▶ │ RcBox { strong:3, weak:0 │                     │
// │  │ owner_b   │──▶ │   RefCell {               │                     │
// │  │ owner_c   │──▶ │     borrow_state: 0       │                     │
// │  └───────────┘    │     value: Vec<i32>       │                     │
// │                   │   }                       │                     │
// │                   └──────────────────────────┘                     │
// │                                                                     │
// │  borrow_state: 0 = 미사용, +N = N개 불변빌림, -1 = 가변빌림          │
// └─────────────────────────────────────────────────────────────────────┘

// ┌─────────────────────────────────────────────────────────────────────┐
// │  Weak<T> — 순환 참조 방지                                            │
// │                                                                     │
// │  강한 참조(Rc): strong_count 증가 → 살아있음                         │
// │  약한 참조(Weak): strong_count 증가 안 함 → drop 방지 안 함          │
// │                                                                     │
// │  순환 참조 문제:                                                     │
// │  A ──Rc──▶ B ──Rc──▶ A  (서로 강한 참조)                           │
// │    → strong_count 절대 0 안 됨 → 메모리 누수                        │
// │                                                                     │
// │  해결:                                                               │
// │  A ──Rc──▶ B ──Weak──▶ A  (B→A는 약한 참조)                        │
// │    → A drop 시 Weak는 None 반환 → 정상 해제                         │
// └─────────────────────────────────────────────────────────────────────┘

use std::rc::{Rc, Weak};
use std::cell::RefCell;
use std::sync::{Arc, Mutex};

pub fn run() {
    println!("\n  [Rc/RefCell/Arc 심화]");
    demo_rc_refcell_combo();
    demo_shared_state();
    demo_weak_ref();
    demo_arc_mutex();
}

fn demo_rc_refcell_combo() {
    println!("\n  ── Rc<RefCell<T>> 공유 가변성 ──");

    let zoo = Rc::new(RefCell::new(vec!["사자".to_string()]));

    // 여러 소유자
    let section_a = Rc::clone(&zoo);
    let section_b = Rc::clone(&zoo);

    // 각각 수정 가능
    section_a.borrow_mut().push("오리".to_string());
    section_b.borrow_mut().push("뱀".to_string());

    println!("  소유자 수: {}", Rc::strong_count(&zoo));
    println!("  동물 목록: {:?}", zoo.borrow());

    // 빌림 상태 확인
    let _r1 = zoo.borrow();      // 불변 빌림 1
    let _r2 = zoo.borrow();      // 불변 빌림 2 — OK
    // zoo.borrow_mut();          // 패닉! 불변 빌림 중
    println!("  동시 불변 빌림 가능");
}

fn demo_shared_state() {
    println!("\n  ── 공유 상태 패턴 ──");

    // 트리 구조에서 공유 데이터
    #[derive(Debug)]
    struct Node {
        value: i32,
        children: Vec<Rc<RefCell<Node>>>,
    }

    impl Node {
        fn new(v: i32) -> Rc<RefCell<Self>> {
            Rc::new(RefCell::new(Node { value: v, children: vec![] }))
        }
        fn add_child(parent: &Rc<RefCell<Self>>, child: Rc<RefCell<Self>>) {
            parent.borrow_mut().children.push(child);
        }
    }

    let root = Node::new(1);
    let child_a = Node::new(2);
    let child_b = Node::new(3);
    Node::add_child(&root, Rc::clone(&child_a));
    Node::add_child(&root, Rc::clone(&child_b));

    println!("  루트 값: {}", root.borrow().value);
    println!("  자식 수: {}", root.borrow().children.len());

    // 자식 노드를 다른 곳에서도 참조 가능
    child_a.borrow_mut().value = 20;
    println!("  child_a 수정 후: {}", root.borrow().children[0].borrow().value);
}

fn demo_weak_ref() {
    println!("\n  ── Weak<T> 순환 참조 방지 ──");

    #[derive(Debug)]
    struct Animal {
        name: String,
        parent: Option<Weak<RefCell<Animal>>>,
        children: Vec<Rc<RefCell<Animal>>>,
    }

    impl Animal {
        fn new(name: &str) -> Rc<RefCell<Self>> {
            Rc::new(RefCell::new(Animal {
                name: name.to_string(),
                parent: None,
                children: vec![],
            }))
        }
    }

    let parent = Animal::new("사자");
    let child  = Animal::new("아기사자");

    // 자식 → 부모: Weak (순환 방지)
    child.borrow_mut().parent = Some(Rc::downgrade(&parent));
    // 부모 → 자식: Rc (강한 참조)
    parent.borrow_mut().children.push(Rc::clone(&child));

    println!("  부모 strong_count: {}", Rc::strong_count(&parent));
    println!("  자식 strong_count: {}", Rc::strong_count(&child));

    // Weak → Rc 업그레이드
    if let Some(weak_parent) = &child.borrow().parent {
        if let Some(p) = weak_parent.upgrade() {
            println!("  자식의 부모: {}", p.borrow().name);
        }
    }

    drop(parent);  // parent drop → child.parent.upgrade() = None
    let borrowed = child.borrow();
    if let Some(weak) = &borrowed.parent {
        println!("  부모 drop 후 upgrade: {:?}", weak.upgrade());
    }
}

fn demo_arc_mutex() {
    println!("\n  ── Arc<Mutex<T>> 멀티 스레드 ──");

    let counter = Arc::new(Mutex::new(0u32));
    let mut handles = vec![];

    for i in 0..5 {
        let c = Arc::clone(&counter);
        let h = std::thread::spawn(move || {
            let mut val = c.lock().unwrap();
            *val += 1;
            println!("  스레드{}: counter = {}", i, *val);
        });
        handles.push(h);
    }
    for h in handles { h.join().unwrap(); }
    println!("  최종 counter: {}", counter.lock().unwrap());

    // RwLock: 읽기 다수, 쓰기 단수
    let data = Arc::new(std::sync::RwLock::new(vec!["사자", "오리"]));
    let d2 = Arc::clone(&data);
    let reader = std::thread::spawn(move || {
        let r = d2.read().unwrap();
        println!("  읽기: {:?}", *r);
    });
    reader.join().unwrap();
    data.write().unwrap().push("뱀");
    println!("  쓰기 후: {:?}", data.read().unwrap());
}
