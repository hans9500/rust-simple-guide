// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 9-3.  RefCell<T> — 런타임 빌림 검사 (interior mutability)        │
// │                                                                       │
// │  공식 std 문서:                                                         │
// │  "Cell<T>, RefCell<T>, and OnceCell<T> allow doing this in a          │
// │   single-threaded way — they do not implement Sync."                  │
// │                                                                       │
// │  컴파일 타임 빌림 규칙을 런타임으로 미루는 패턴.                         │
// │  .borrow()     → Ref<T>      (공유 빌림, 런타임 추적)                  │
// │  .borrow_mut() → RefMut<T>   (배타 빌림, 런타임 추적)                  │
// │  규칙 위반 시: 컴파일 에러 아님 → 런타임 panic                         │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 컴파일 타임 vs 런타임 빌림 검사 비교 ────────────────────────────────
//
//  컴파일 타임 (&T, &mut T):
//  ┌────────────────────────────────────────────────────┐
//  │  let mut lion = Lion::new("Simba", 5);             │
//  │  let r1 = &lion;          // 공유 빌림             │
//  │  let w  = &mut lion;      // ← 컴파일 에러!        │
//  │  // r1과 w가 동시에 존재 불가                       │
//  └────────────────────────────────────────────────────┘
//
//  런타임 (RefCell<T>):
//  ┌────────────────────────────────────────────────────┐
//  │  let cell = RefCell::new(Lion::new("Simba", 5));   │
//  │  let r1 = cell.borrow();     // 공유 빌림 OK       │
//  │  let r2 = cell.borrow();     // 추가 공유 빌림 OK  │
//  │  drop(r1); drop(r2);         // 공유 빌림 해제      │
//  │  let w = cell.borrow_mut();  // 배타 빌림 OK       │
//  │  // 동시에 존재하면 → panic                        │
//  └────────────────────────────────────────────────────┘
//
// ─── Rc<RefCell<T>> 패턴 — 공유 + 가변 ──────────────────────────────────
//
//  공식 std 문서가 보여주는 패턴:
//    let shared_map: Rc<RefCell<_>> = Rc::new(RefCell::new(HashMap::new()));
//
//  ┌──────────────────────────────────────────────────────────┐
//  │  Rc<RefCell<Lion>>                                        │
//  │                                                           │
//  │  스택(a)        힙 RcBox                                  │
//  │  ┌─────────┐   ┌──────────────────────────────────┐      │
//  │  │ ptr ────┼──▶│ strong_count: 2                  │      │
//  │  └─────────┘   │ weak_count:   0                  │      │
//  │                │ value: RefCell {                  │      │
//  │  스택(b)        │   borrow_state: 0 (없음)         │      │
//  │  ┌─────────┐   │   value: UnsafeCell<Lion>         │      │
//  │  │ ptr ────┼──▶│ }                                │      │
//  │  └─────────┘   └──────────────────────────────────┘      │
//  │                                                           │
//  │  a.borrow_mut().feed() → Lion의 hungry를 변경             │
//  │  b.borrow().name()     → a가 borrow_mut 중이면 panic!     │
//  └──────────────────────────────────────────────────────────┘

use std::cell::{Cell, RefCell};
use std::rc::Rc;
use crate::part2_patterns::animals::Lion;

pub fn run() {
    println!("\n─── Part 9-3: RefCell<T> + Cell<T> ───");

    // ── RefCell<T> 기본 ───────────────────────────────────────────────────
    println!("\n  [RefCell<T> 기본]");
    let cell = RefCell::new(Lion::new("Simba", 5));

    // 불변 참조 — borrow()
    {
        let r1 = cell.borrow();
        let r2 = cell.borrow();  // 공유 빌림 여러 개 OK
        println!("  r1={}, r2={}", r1.name(), r2.name());
    }   // r1, r2 drop (Ref가 drop되면 borrow 카운트 감소)

    // 가변 참조 — borrow_mut()
    {
        let mut w = cell.borrow_mut();
        w.feed();
        w.birthday();
    }   // w drop

    println!("  수정 후: {}", cell.borrow().status());

    // ── Rc<RefCell<T>> — 공유 + 가변 ─────────────────────────────────────
    println!("\n  [Rc<RefCell<T>> — 공유 + 가변]");
    let shared = Rc::new(RefCell::new(Lion::new("Mufasa", 9)));

    let owner_a = Rc::clone(&shared);
    let owner_b = Rc::clone(&shared);
    let owner_c = Rc::clone(&shared);

    // owner_a를 통해 수정
    owner_a.borrow_mut().feed();
    println!("  owner_a 수정 후");

    // owner_b, owner_c 도 변경 확인
    println!("  owner_b: {}", owner_b.borrow().status());
    println!("  owner_c: {}", owner_c.borrow().status());

    // strong_count 확인
    println!("  strong_count: {}", Rc::strong_count(&shared));

    // ── Cell<T> — Copy 타입용 interior mutability ─────────────────────────
    println!("\n  [Cell<T> — Copy 타입 interior mutability]");
    // Cell<T>는 T: Copy 타입에 최적화. get()/set()으로 접근.
    // RefCell처럼 borrow guard 없이 값 복사로 동작.
    let cell_age = Cell::new(5u32);
    println!("  초기 나이: {}", cell_age.get());
    cell_age.set(cell_age.get() + 1);
    println!("  수정 후 나이: {}", cell_age.get());

    // struct 안에서 Cell 활용 — &self로 내부 상태 수정 가능
    struct CachedLion {
        lion:       Lion,
        access_count: Cell<u32>,  // &self로도 수정 가능
    }
    impl CachedLion {
        fn new(lion: Lion) -> Self {
            CachedLion { lion, access_count: Cell::new(0) }
        }
        fn name(&self) -> &str {
            self.access_count.set(self.access_count.get() + 1);
            self.lion.name()
        }
        fn access_count(&self) -> u32 { self.access_count.get() }
    }

    let cached = CachedLion::new(Lion::new("Simba", 5));
    println!("  이름: {}", cached.name());
    println!("  이름: {}", cached.name());
    println!("  접근 횟수: {}", cached.access_count());

    // ── panic 상황 ────────────────────────────────────────────────────────
    println!("\n  [RefCell 런타임 패닉 시나리오 — 주석으로]");
    println!("  // let r = cell.borrow();");
    println!("  // let w = cell.borrow_mut(); ← panic: already borrowed");
    println!("  실제 위반 시 런타임에 BorrowError 또는 BorrowMutError panic");
}
