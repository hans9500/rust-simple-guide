// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 6-2.  Option<T>                                                  │
// │                                                                       │
// │  Option<T>는 표준 라이브러리의 enum이다:                                │
// │    pub enum Option<T> { None, Some(T) }                               │
// │                                                                       │
// │  Rust에는 null이 없다. "값이 없을 수 있음"을 Option<T>로 표현한다.      │
// │  공식 Book: "When the None case, it protects us from assuming that    │
// │  we have a value when we might have null"                             │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Option 메서드 지도 ───────────────────────────────────────────────────
//
//  Some(v) ──▶ 값이 있음
//  None    ──▶ 값이 없음
//
//  소비(값 꺼내기):
//    .unwrap()          — Some이면 꺼냄, None이면 panic
//    .unwrap_or(d)      — Some이면 꺼냄, None이면 d 반환
//    .unwrap_or_else(f) — Some이면 꺼냄, None이면 f() 실행
//    .expect("msg")     — Some이면 꺼냄, None이면 msg와 함께 panic
//
//  변환(Option 유지):
//    .map(f)            — Some(v) → Some(f(v)), None → None
//    .and_then(f)       — Some(v) → f(v) (f는 Option<U> 반환), None → None
//    .filter(p)         — Some(v)이고 p(v)가 true면 Some(v), 아니면 None
//    .or(opt)           — Some이면 그대로, None이면 opt
//    .or_else(f)        — Some이면 그대로, None이면 f()
//
//  검사:
//    .is_some()         — Some이면 true
//    .is_none()         — None이면 true
//
//  참조:
//    .as_ref()          — Option<T> → Option<&T>

use crate::part2_patterns::animals::Lion;

// 동물원에서 이름으로 사자 찾기 — 없을 수도 있으므로 Option 반환
pub fn find_lion<'a>(pride: &'a [Lion], name: &str) -> Option<&'a Lion> {
    pride.iter().find(|l| l.name() == name)
}

// 나이 검증 — 유효하면 Lion, 아니면 None
pub fn create_valid_lion(name: &str, age: u32) -> Option<Lion> {
    if age <= Lion::MAX_AGE {
        Some(Lion::new(name, age))
    } else {
        None
    }
}

pub fn run() {
    println!("\n─── Part 6-2: Option<T> ───");

    // 기본 Some / None
    println!("\n  [Some / None 기본]");
    let some_lion: Option<Lion> = Some(Lion::new("Simba", 5));
    let no_lion:   Option<Lion> = None;

    println!("  some_lion.is_some(): {}", some_lion.is_some());
    println!("  no_lion.is_none():   {}", no_lion.is_none());

    // unwrap 계열
    println!("\n  [unwrap 계열]");
    let pride = vec![
        Lion::new("Simba",  5),
        Lion::new("Nala",   4),
        Lion::new("Mufasa", 10),
        Lion::new("Scar",   9),
    ];

    // unwrap_or — None일 때 기본값
    let found = find_lion(&pride, "Simba")
        .map(|l| l.name().to_string())
        .unwrap_or_else(|| "없음".to_string());
    println!("  Simba 찾기: {}", found);

    let not_found = find_lion(&pride, "Ghost")
        .map(|l| l.name().to_string())
        .unwrap_or("없음".to_string());
    println!("  Ghost 찾기: {}", not_found);

    // map — Option 안의 값 변환
    println!("\n  [map — 변환]");
    let age = find_lion(&pride, "Mufasa")
        .map(|l| l.age());          // Option<&Lion> → Option<u32>
    println!("  Mufasa 나이: {:?}", age);

    let is_senior = find_lion(&pride, "Mufasa")
        .map(|l| l.is_senior());    // Option<&Lion> → Option<bool>
    println!("  Mufasa 시니어: {:?}", is_senior);

    // and_then — 체이닝 (flatMap)
    println!("\n  [and_then — 체이닝]");
    let status = find_lion(&pride, "Simba")
        .and_then(|l| {
            if l.age() > 3 { Some(l.status()) }
            else           { None }
        });
    println!("  Simba 상태: {:?}", status);

    // filter
    println!("\n  [filter]");
    let senior = find_lion(&pride, "Mufasa")
        .filter(|l| l.is_senior());
    println!("  Mufasa 시니어 필터: {}", senior.map(|l| l.name()).unwrap_or("해당없음"));

    // create_valid_lion
    println!("\n  [유효성 검사 → Option]");
    let valid   = create_valid_lion("Young", 5);
    let invalid = create_valid_lion("Ancient", 99);
    println!("  나이 5 생성: {:?}", valid.map(|l| l.name().to_string()));
    println!("  나이 99 생성: {:?}", invalid.map(|l| l.name().to_string()));

    // if let — Option 언팩
    println!("\n  [if let — Option 언팩]");
    if let Some(lion) = find_lion(&pride, "Nala") {
        println!("  Nala 발견: {}", lion.status());
    }
    if let Some(lion) = find_lion(&pride, "Ghost") {
        println!("  Ghost 발견: {}", lion.status());
    } else {
        println!("  Ghost 없음");
    }

    // while let
    println!("\n  [while let — 스택 소비]");
    let mut stack: Vec<Option<&str>> = vec![
        Some("Simba"), None, Some("Nala"), Some("Scar"), None,
    ];
    while let Some(item) = stack.pop() {
        match item {
            Some(name) => println!("  꺼냄: {}", name),
            None       => println!("  빈 슬롯"),
        }
    }

    // Option 체이닝
    println!("\n  [Option 메서드 체이닝]");
    let eldest_senior_name: Option<String> = pride.iter()
        .max_by_key(|l| l.age())
        .filter(|l| l.is_senior())
        .map(|l| l.name().to_string());
    println!("  최고령 시니어: {:?}", eldest_senior_name);
}
