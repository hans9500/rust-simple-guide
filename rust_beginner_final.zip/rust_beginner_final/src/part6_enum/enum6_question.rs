// ┌──────────────────────────────────────────────────────────────────
// │ Part 6 보강: ? 연산자 실전 패턴
// │
// │ 기존 enum6_result.rs에서 ? 기초를 배웠다면
// │ 여기서는 실전 체이닝과 에러 변환 패턴을 다룬다.
// └──────────────────────────────────────────────────────────────────

use std::fmt;
use std::num::{ParseIntError, ParseFloatError};

pub fn run() {
    println!("\n  [Part 6 보강: ? 연산자 실전]");
    demo_question_chaining();
    demo_error_propagation();
    demo_option_question();
    demo_collect_results();
}

// ── 에러 타입 정의 ─────────────────────────────────────────────────
#[derive(Debug)]
enum ZooLoadError {
    EmptyInput,
    WrongFormat(String),
    InvalidAge(ParseIntError),
    InvalidWeight(ParseFloatError),
    AgeOutOfRange(u32),
}

impl fmt::Display for ZooLoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::EmptyInput           => write!(f, "입력이 비어있음"),
            Self::WrongFormat(s)       => write!(f, "형식 오류: {}", s),
            Self::InvalidAge(e)        => write!(f, "나이 파싱 오류: {}", e),
            Self::InvalidWeight(e)     => write!(f, "체중 파싱 오류: {}", e),
            Self::AgeOutOfRange(age)   => write!(f, "나이 {} 는 범위 초과 (0~50)", age),
        }
    }
}

impl From<ParseIntError>   for ZooLoadError {
    fn from(e: ParseIntError)   -> Self { Self::InvalidAge(e) }
}
impl From<ParseFloatError> for ZooLoadError {
    fn from(e: ParseFloatError) -> Self { Self::InvalidWeight(e) }
}

#[derive(Debug)]
struct Animal {
    name:    String,
    age:     u32,
    weight:  f64,
}

// ── ? 체이닝 ──────────────────────────────────────────────────────
// CSV 한 줄 파싱: "Simba,5,190.5"
fn parse_animal(line: &str) -> Result<Animal, ZooLoadError> {
    if line.trim().is_empty() {
        return Err(ZooLoadError::EmptyInput);
    }
    let parts: Vec<&str> = line.split(',').collect();
    if parts.len() != 3 {
        return Err(ZooLoadError::WrongFormat(
            format!("필드 3개 필요, {} 개 받음", parts.len())
        ));
    }
    let name   = parts[0].trim().to_string();
    let age: u32   = parts[1].trim().parse()?;   // ? → From<ParseIntError>
    let weight: f64 = parts[2].trim().parse()?;  // ? → From<ParseFloatError>

    if age > 50 {
        return Err(ZooLoadError::AgeOutOfRange(age));
    }
    Ok(Animal { name, age, weight })
}

fn demo_question_chaining() {
    println!("\n  ── ? 체이닝 ──");

    let cases = [
        ("Simba,5,190.5",    "정상"),
        ("Donald,3,2.5",     "정상"),
        ("",                  "빈 입력"),
        ("Nagini,abc,15.0",  "나이 파싱 실패"),
        ("Dumbo,10",         "필드 수 오류"),
        ("Ghost,100,50.0",   "나이 범위 초과"),
        ("Cobra,4,xyz",      "체중 파싱 실패"),
    ];

    for (input, desc) in &cases {
        match parse_animal(input) {
            Ok(a)  => println!("  ✓ {}: {} {}살 {}kg", desc, a.name, a.age, a.weight),
            Err(e) => println!("  ✗ {}: {}", desc, e),
        }
    }
}

// ── 에러 전파: 여러 함수에 걸친 ? ─────────────────────────────────
fn validate_name(name: &str) -> Result<String, ZooLoadError> {
    if name.is_empty() {
        return Err(ZooLoadError::EmptyInput);
    }
    Ok(name.to_string())
}

fn parse_and_validate(line: &str) -> Result<Animal, ZooLoadError> {
    let animal = parse_animal(line)?;  // 파싱
    let name   = validate_name(&animal.name)?;  // 검증
    Ok(Animal { name, ..animal })
}

fn load_zoo(lines: &[&str]) -> Result<Vec<Animal>, ZooLoadError> {
    // ? 로 첫 번째 에러에서 즉시 반환
    let mut animals = Vec::new();
    for &line in lines {
        animals.push(parse_and_validate(line)?);
    }
    Ok(animals)
}

fn demo_error_propagation() {
    println!("\n  ── 에러 전파 ──");

    // 모두 성공
    let ok_lines = &["Simba,5,190.5", "Donald,3,2.5", "Nagini,8,15.0"];
    match load_zoo(ok_lines) {
        Ok(zoo)  => println!("  로드 성공: {} 마리", zoo.len()),
        Err(e)   => println!("  로드 실패: {}", e),
    }

    // 중간에 실패 — 첫 번째 에러에서 즉시 반환
    let bad_lines = &["Simba,5,190.5", "INVALID", "Nagini,8,15.0"];
    match load_zoo(bad_lines) {
        Ok(zoo)  => println!("  로드 성공: {} 마리", zoo.len()),
        Err(e)   => println!("  로드 실패 (첫 에러에서 중단): {}", e),
    }
}

// ── Option에서 ? ───────────────────────────────────────────────────
fn find_heaviest(animals: &[Animal]) -> Option<&Animal> {
    if animals.is_empty() {
        return None;  // 또는 None?  (즉시 반환)
    }
    animals.iter().max_by(|a, b| {
        a.weight.partial_cmp(&b.weight).unwrap()
    })
}

fn heaviest_name(animals: &[Animal]) -> Option<String> {
    // ? 로 None 전파
    let heaviest = find_heaviest(animals)?;
    Some(format!("{} ({}kg)", heaviest.name, heaviest.weight))
}

fn demo_option_question() {
    println!("\n  ── Option + ? ──");

    let animals = vec![
        Animal { name: "Simba".to_string(),  age: 5, weight: 190.5 },
        Animal { name: "Dumbo".to_string(),  age: 10, weight: 4000.0 },
        Animal { name: "Donald".to_string(), age: 3, weight: 2.5 },
    ];

    println!("  가장 무거운: {:?}", heaviest_name(&animals));
    println!("  빈 목록: {:?}", heaviest_name(&[]));
}

// ── collect::<Result<Vec<_>, _>>() ────────────────────────────────
fn demo_collect_results() {
    println!("\n  ── collect로 Result<Vec> 만들기 ──");

    let raw = vec!["Simba,5,190.5", "Donald,3,2.5", "Nagini,8,15.0"];

    // 모두 성공 → Ok(Vec<Animal>)
    let result: Result<Vec<Animal>, ZooLoadError> =
        raw.iter().map(|line| parse_animal(line)).collect();
    println!("  전부 성공: {} 마리", result.unwrap().len());

    // 하나라도 실패 → Err(첫 번째 에러)
    let bad = vec!["Simba,5,190.5", "INVALID", "Donald,3,2.5"];
    let result2: Result<Vec<Animal>, ZooLoadError> =
        bad.iter().map(|line| parse_animal(line)).collect();
    println!("  실패 포함: {}", result2.unwrap_err());

    // 에러를 무시하고 성공한 것만 — filter_map + ok()
    let partial: Vec<Animal> = bad.iter()
        .filter_map(|line| parse_animal(line).ok())
        .collect();
    println!("  성공만: {} 마리", partial.len());
}
