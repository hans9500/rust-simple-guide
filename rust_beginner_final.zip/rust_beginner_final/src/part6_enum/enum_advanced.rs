// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 6 심화.  enum 고급 — 실수 패턴과 컴파일 에러 해부                 │
// └───────────────────────────────────────────────────────────────────────┘

use crate::part2_patterns::animals::Lion;

// ─── 심화 1: Option 체이닝 실수 — unwrap() 남용 ──────────────────────────
//
//  .unwrap()은 None이면 panic → 프로덕션 코드에서 위험
//
//  흔한 실수:
//  let name = find_lion(&pride, "Ghost").unwrap().name(); // Ghost 없으면 panic!
//  // thread 'main' panicked at 'called `Option::unwrap()` on a `None` value'
//
//  언제 unwrap()이 허용되는가:
//    1. 테스트 코드
//    2. 로직상 반드시 Some임이 확실한 경우 (그러나 이때도 expect()가 낫다)
//    3. 프로토타이핑
//
//  프로덕션 패턴:
//    .unwrap_or(default)         — 기본값
//    .unwrap_or_else(|| ...)     — 지연 기본값
//    .expect("이유")              — panic이지만 메시지 포함
//    if let Some(v) = opt { ... } — 안전한 처리
//    ? 연산자                     — 상위로 전파
//
//  .unwrap_or vs .unwrap_or_else 차이:
//
//  // 비효율: Some이어도 기본값이 항상 생성됨
//  let lion = find_lion(&pride, "Ghost")
//      .unwrap_or(Lion::new("기본", 0));   // Lion::new 항상 실행
//
//  // 효율적: None일 때만 생성
//  let lion = find_lion(&pride, "Ghost")
//      .unwrap_or_else(|| Lion::new("기본", 0));  // 지연 실행

fn find_lion<'a>(pride: &'a [Lion], name: &str) -> Option<&'a Lion> {
    pride.iter().find(|l| l.name() == name)
}

fn demo_option_mistakes() {
    println!("\n  [심화1: Option 실수 패턴]");

    let pride = vec![
        Lion::new("Simba", 5),
        Lion::new("Nala",  4),
    ];

    // unwrap_or vs unwrap_or_else 차이 시연
    println!("  [unwrap_or — 항상 평가]");
    let name1 = find_lion(&pride, "Simba")
        .map(|l| l.name().to_string())
        .unwrap_or_else(|| {
            println!("    (기본값 생성 — None일 때만 실행)");
            "없음".to_string()
        });
    println!("  Simba 찾기: {}", name1);  // 기본값 생성 안 됨

    println!("  [unwrap_or_else — None일 때만 평가]");
    let name2 = find_lion(&pride, "Ghost")
        .map(|l| l.name().to_string())
        .unwrap_or_else(|| {
            println!("    (기본값 생성 — None이므로 실행됨)");
            "없음".to_string()
        });
    println!("  Ghost 찾기: {}", name2);

    // and_then 체이닝 — None이면 즉시 None 반환 (단락 평가)
    println!("\n  [and_then 체이닝 — 단락 평가]");
    let result = find_lion(&pride, "Simba")
        .and_then(|l| if l.age() > 3 { Some(l) } else { None })
        .and_then(|l| if l.is_hungry() { Some(l.status()) } else { None });
    println!("  Simba 체이닝: {:?}", result);

    // 중첩 Option 평탄화
    println!("\n  [중첩 Option — flatten()]");
    let nested: Option<Option<&str>> = Some(Some("Simba"));
    let flat = nested.flatten();
    println!("  flatten: {:?}", flat);

    let nested_none: Option<Option<&str>> = Some(None);
    println!("  flatten(Some(None)): {:?}", nested_none.flatten());
}

// ─── 심화 2: ? 연산자 실수 패턴 ──────────────────────────────────────────
//
//  실수 1: 반환 타입이 Result가 아닌 함수에서 ? 사용
//
//  fn main() {
//      let n: u32 = "abc".parse()?;  // ← 에러!
//  }
//  // 에러: the `?` operator can only be used in a function that returns
//  //       `Result` or `Option` (or another type that implements `FromResidual`)
//  // 해결: fn main() -> Result<(), Box<dyn std::error::Error>>
//
//  실수 2: 에러 타입이 다를 때 From 변환 필요
//
//  fn f() -> Result<(), MyError> {
//      let n: u32 = "abc".parse()?;  // ParseIntError → MyError로 변환 필요
//  }
//  // 에러: the trait `From<ParseIntError>` is not implemented for `MyError`
//  // 해결: impl From<ParseIntError> for MyError { ... }
//  //   또는: Box<dyn Error> 사용
//
//  ? 연산자의 정확한 내부 동작:
//  let x = expr?;
//  →
//  let x = match expr {
//      Ok(val)  => val,
//      Err(e)   => return Err(From::from(e)),  // From 변환 포함
//  };

use std::num::ParseIntError;

#[derive(Debug)]
enum ZooParseError {
    InvalidAge(ParseIntError),
    InvalidName(String),
}

impl From<ParseIntError> for ZooParseError {
    fn from(e: ParseIntError) -> Self {
        ZooParseError::InvalidAge(e)
    }
}

impl std::fmt::Display for ZooParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        match self {
            ZooParseError::InvalidAge(e)  => write!(f, "나이 파싱 실패: {}", e),
            ZooParseError::InvalidName(s) => write!(f, "이름 오류: {}", s),
        }
    }
}

// ? 연산자: ParseIntError → From → ZooParseError
fn parse_lion(name: &str, age_str: &str) -> Result<Lion, ZooParseError> {
    if name.is_empty() {
        return Err(ZooParseError::InvalidName("빈 이름".to_string()));
    }
    let age: u32 = age_str.parse()?;  // ParseIntError → ZooParseError (From)
    Ok(Lion::new(name, age))
}

fn demo_question_mark() {
    println!("\n  [심화2: ? 연산자 실수와 From 변환]");

    let cases = vec![
        ("Simba", "5"),
        ("Nala",  "abc"),    // ParseIntError → ZooParseError
        ("",      "4"),      // InvalidName
        ("Scar",  "9"),
    ];

    for (name, age) in &cases {
        match parse_lion(name, age) {
            Ok(lion)  => println!("  ✅ {}", lion.status()),
            Err(e)    => println!("  ❌ {}", e),
        }
    }
}

// ─── 심화 3: enum 크기 최적화 ─────────────────────────────────────────────
//
//  Null Pointer Optimization (NPO):
//    Option<Box<T>>는 Box<T>와 같은 크기
//    None = null pointer (0)
//    Some(ptr) = non-null pointer
//
//  Option<T>의 일반적인 크기:
//    Option<u32>      = 8바이트 (u32 4B + 태그 4B, 정렬)
//    Option<&T>       = 8바이트 (NPO: None=null, 일반 참조와 동일)
//    Option<Box<T>>   = 8바이트 (NPO)
//    Option<NonZeroU32> = 4바이트 (NonZeroU32는 0이 불가 → 0=None)
//
//  enum 크기 = 태그 + 가장 큰 variant의 크기:
//    enum Small { A(u8), B(u8) }         → 2바이트 (태그 1B + 데이터 1B)
//    enum Medium { A(u8), B(u32) }       → 8바이트 (태그 + u32 크기 맞춤)
//    enum Large { A(u8), B([u8; 1000]) } → 1001바이트 이상

fn demo_enum_sizes() {
    println!("\n  [심화3: enum 크기와 NPO]");
    use std::mem::size_of;

    println!("  bool:              {} bytes", size_of::<bool>());
    println!("  Option<bool>:      {} bytes", size_of::<Option<bool>>());
    // bool은 0 또는 1만 유효 → 2가 None이 될 수 있어 NPO 가능
    // 실제로는 구현에 따라 다름

    println!("  &Lion:             {} bytes", size_of::<&Lion>());
    println!("  Option<&Lion>:     {} bytes", size_of::<Option<&Lion>>());
    // NPO: null reference = None

    println!("  Box<Lion>:         {} bytes", size_of::<Box<Lion>>());
    println!("  Option<Box<Lion>>: {} bytes", size_of::<Option<Box<Lion>>>());
    // NPO: null Box = None

    println!("  u32:               {} bytes", size_of::<u32>());
    println!("  Option<u32>:       {} bytes", size_of::<Option<u32>>());
    // NPO 불가: u32는 0도 유효값 → 별도 태그 필요

    // match exhaustiveness — 새 variant 추가 시 안전망
    println!("\n  [match exhaustiveness — 새 variant 안전망]");
    #[derive(Debug)]
    enum Status { Ok, Warning, Error }

    // 세 variant를 모두 사용 — exhaustive match로 전부 처리
    for s in [Status::Ok, Status::Warning, Status::Error] {
        let msg = match s {
            Status::Ok      => "정상",
            Status::Warning => "경고",
            Status::Error   => "오류",
            // 새 variant (예: Status::Critical) 추가 시
            // 이 match에서 컴파일 에러 → 런타임 버그 방지
        };
        println!("  상태: {}", msg);
    }
}

// ─── 심화 4: Result 에러 타입 변환 패턴 ──────────────────────────────────
//
//  여러 에러 타입을 하나의 함수에서 처리하는 방법:
//
//  1. Box<dyn Error> — 동적 디스패치, 가장 유연
//     fn f() -> Result<(), Box<dyn std::error::Error>> {
//         "abc".parse::<u32>()?;  // 어떤 에러든 Box<dyn Error>로
//         Ok(())
//     }
//
//  2. 커스텀 enum + From 구현 — 타입 안전, 명시적
//     enum MyError { Parse(ParseIntError), Io(IoError) }
//     impl From<ParseIntError> for MyError { ... }
//     impl From<IoError> for MyError { ... }
//
//  3. thiserror 크레이트 — 보일러플레이트 최소화 (외부 크레이트)
//
//  map_err로 에러 타입 변환:
//  fn f() -> Result<u32, String> {
//      "abc".parse::<u32>()
//          .map_err(|e| e.to_string())  // ParseIntError → String
//  }

fn demo_error_conversion() {
    println!("\n  [심화4: 에러 타입 변환 패턴]");

    // map_err — 에러 타입 변환
    fn parse_age_as_string(s: &str) -> Result<u32, String> {
        s.parse::<u32>().map_err(|e| format!("파싱 실패: {}", e))
    }

    println!("  '5' 파싱: {:?}", parse_age_as_string("5"));
    println!("  'abc' 파싱: {:?}", parse_age_as_string("abc"));

    // Box<dyn Error> — 여러 에러 타입 통합
    fn multi_error_fn(s: &str) -> Result<Lion, Box<dyn std::error::Error>> {
        let age: u32 = s.parse()?;          // ParseIntError → Box<dyn Error>
        if age > Lion::MAX_AGE {
            return Err(format!("나이 {} 초과", age).into()); // String → Box<dyn Error>
        }
        Ok(Lion::new("파싱된 사자", age))
    }

    for input in &["5", "abc", "30"] {
        match multi_error_fn(input) {
            Ok(l)  => println!("  '{}' → {}", input, l.status()),
            Err(e) => println!("  '{}' → 에러: {}", input, e),
        }
    }
}

pub fn run() {
    println!("\n══════ Part 6 심화: enum 고급 ══════");
    demo_option_mistakes();
    demo_question_mark();
    demo_enum_sizes();
    demo_error_conversion();
}
