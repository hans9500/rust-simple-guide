// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 6-1.  기본 enum — variant 종류                                   │
// │                                                                       │
// │  Rust의 enum은 C의 tagged union + 패턴 매칭의 조합이다.                 │
// │  공식 Book: "Rust's enums are most similar to algebraic data types    │
// │             in functional languages such as F#, OCaml, and Haskell"   │
// │                                                                       │
// │  variant 세 종류:                                                      │
// │    unit variant    — 데이터 없음          AnimalKind::Lion             │
// │    tuple variant   — 이름 없는 데이터     Sound::Roar(String)          │
// │    struct variant  — 이름 있는 데이터     Event::Fed { name, amount }  │
// └───────────────────────────────────────────────────────────────────────┘

// ─── 도식: enum 메모리 레이아웃 ──────────────────────────────────────────
//
//  enum의 크기 = discriminant(태그) + 가장 큰 variant의 크기
//
//  enum AnimalKind {          메모리 (개념적):
//      Lion,                  ┌─────────────────────────┐
//      Duck,                  │ tag  │ payload           │
//      Snake(bool),           │ 0    │ (없음)            │  Lion
//  }                          │ 1    │ (없음)            │  Duck
//                             │ 2    │ bool (1바이트)    │  Snake(true/false)
//                             └─────────────────────────┘
//
//  Rust 컴파일러는 null pointer optimization 등을 통해
//  실제로는 더 작게 만들 수 있다.
//  예: Option<Box<T>>는 Box<T>와 같은 크기 (None = null pointer)

use std::fmt;

// ── unit variant: 데이터 없음 ────────────────────────────────────────────
#[derive(Debug, Clone, PartialEq)]
pub enum AnimalKind {
    Lion,
    Duck,
    Snake,
}

// ── tuple variant: 이름 없는 데이터 ─────────────────────────────────────
#[derive(Debug, Clone)]
pub enum AnimalSound {
    Roar(String),           // 단일 값
    Quack(String, u32),     // 여러 값 (소리, 크기)
    Hiss { venomous: bool, sound: String }, // struct variant
}

// ── struct variant: 이름 있는 데이터 ─────────────────────────────────────
#[derive(Debug)]
pub enum ZooEvent {
    AnimalArrived {
        name:    String,
        kind:    AnimalKind,
        age:     u32,
    },
    AnimalFed {
        name:    String,
        food:    String,
        amount:  f64,
    },
    AnimalRetired {
        name:    String,
        reason:  String,
    },
    CageOpened(u32),        // tuple variant — 우리 번호
    CageClosed(u32),
    EmergencyAlert,         // unit variant
}

impl fmt::Display for ZooEvent {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            ZooEvent::AnimalArrived { name, kind, age } =>
                write!(f, "🐾 {} ({:?}, {}살) 도착", name, kind, age),
            ZooEvent::AnimalFed { name, food, amount } =>
                write!(f, "🍖 {} 에게 {} {}kg 급식", name, food, amount),
            ZooEvent::AnimalRetired { name, reason } =>
                write!(f, "👋 {} 은퇴: {}", name, reason),
            ZooEvent::CageOpened(n) =>
                write!(f, "🔓 우리 #{} 개방", n),
            ZooEvent::CageClosed(n) =>
                write!(f, "🔒 우리 #{} 잠금", n),
            ZooEvent::EmergencyAlert =>
                write!(f, "🚨 긴급 경보!"),
        }
    }
}

// ── 재귀 enum — Box로 크기 확정 ──────────────────────────────────────────
//
//  재귀 타입은 컴파일 타임에 크기를 알 수 없다.
//  Box<T>로 감싸면 Box 포인터 크기(8바이트)로 확정된다.
//
//  enum FoodChain {            컴파일 에러: 크기 무한
//      End,
//      Link(AnimalKind, FoodChain),  ← FoodChain이 FoodChain을 포함
//  }
//
//  enum FoodChain {            OK: Box 포인터 크기로 확정
//      End,
//      Link(AnimalKind, Box<FoodChain>),
//  }
#[derive(Debug)]
pub enum FoodChain {
    End,
    Link(AnimalKind, Box<FoodChain>),
}

impl FoodChain {
    pub fn depth(&self) -> usize {
        match self {
            FoodChain::End           => 0,
            FoodChain::Link(_, next) => 1 + next.depth(),
        }
    }
}

pub fn run() {
    println!("\n─── Part 6-1: 기본 enum ───");

    // unit variant
    println!("\n  [unit variant]");
    let kind = AnimalKind::Snake;
    println!("  kind: {:?}", kind);
    println!("  is Lion: {}", kind == AnimalKind::Lion);

    // tuple variant
    println!("\n  [tuple variant]");
    let sounds = vec![
        AnimalSound::Roar("으르렁~".to_string()),
        AnimalSound::Quack("꽥꽥!".to_string(), 3),
        AnimalSound::Hiss { venomous: true, sound: "쉬이익".to_string() },
    ];
    for s in &sounds {
        match s {
            AnimalSound::Roar(s)              => println!("  사자: {}", s),
            AnimalSound::Quack(s, vol)        => println!("  오리: {} (크기{})", s, vol),
            AnimalSound::Hiss { venomous, sound } =>
                println!("  뱀: {} (독: {})", sound, venomous),
        }
    }

    // struct variant + Display
    println!("\n  [struct variant — ZooEvent]");
    let events = vec![
        ZooEvent::AnimalArrived { name: "Simba".into(), kind: AnimalKind::Lion, age: 5 },
        ZooEvent::AnimalFed { name: "Simba".into(), food: "고기".into(), amount: 5.0 },
        ZooEvent::CageOpened(1),
        ZooEvent::AnimalRetired { name: "Mufasa".into(), reason: "고령".into() },
        ZooEvent::EmergencyAlert,
    ];
    for event in &events {
        println!("  {}", event);
    }

    // 재귀 enum
    println!("\n  [재귀 enum — FoodChain]");
    let chain = FoodChain::Link(
        AnimalKind::Lion,
        Box::new(FoodChain::Link(
            AnimalKind::Snake,
            Box::new(FoodChain::Link(
                AnimalKind::Duck,
                Box::new(FoodChain::End),
            )),
        )),
    );
    println!("  먹이사슬 깊이: {}", chain.depth());
}
