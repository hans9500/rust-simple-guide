// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 6-3.  Result<T, E>                                              │
// │                                                                       │
// │  pub enum Result<T, E> { Ok(T), Err(E) }                             │
// │                                                                       │
// │  실패 가능한 연산의 결과를 타입 시스템에서 강제 처리.                    │
// │  ? 연산자: Ok면 값을 꺼내고, Err면 현재 함수에서 즉시 반환.            │
// │                                                                       │
// │  ? 내부 동작:                                                           │
// │    let x = expr?;                                                     │
// │    ≡                                                                  │
// │    let x = match expr {                                               │
// │        Ok(val)  => val,                                               │
// │        Err(e)   => return Err(From::from(e)),  // From 변환 포함      │
// │    };                                                                 │
// └───────────────────────────────────────────────────────────────────────┘

// ─── Result 메서드 지도 ───────────────────────────────────────────────────
//
//  Ok(v) ──▶ 성공, 값 v
//  Err(e)──▶ 실패, 에러 e
//
//  소비:
//    .unwrap()          — Ok면 꺼냄, Err면 panic
//    .unwrap_or(d)      — Ok면 꺼냄, Err면 d
//    .unwrap_or_else(f) — Ok면 꺼냄, Err면 f(e)
//    .expect("msg")     — Ok면 꺼냄, Err면 msg와 함께 panic
//
//  변환:
//    .map(f)            — Ok(v) → Ok(f(v)), Err → Err
//    .map_err(f)        — Ok → Ok, Err(e) → Err(f(e))
//    .and_then(f)       — Ok(v) → f(v), Err → Err
//    .or(res)           — Ok면 그대로, Err면 res
//
//  검사:
//    .is_ok()           — Ok면 true
//    .is_err()          — Err면 true
//
//  ? 연산자: 함수 반환 타입이 Result일 때 사용 가능

use crate::part2_patterns::animals::Lion;

// 에러 타입 정의
#[derive(Debug)]
pub enum ZooError {
    AgeOutOfRange { name: String, age: u32, max: u32 },
    NameTooShort  { name: String },
    AlreadyExists { name: String },
    NotFound      { name: String },
}

impl std::fmt::Display for ZooError {
    fn fmt(&self, f: &mut std::fmt::Formatter) -> std::fmt::Result {
        match self {
            ZooError::AgeOutOfRange { name, age, max } =>
                write!(f, "'{}' 나이 {}는 최대 {}를 초과", name, age, max),
            ZooError::NameTooShort { name } =>
                write!(f, "이름 '{}'이 너무 짧음 (최소 2글자)", name),
            ZooError::AlreadyExists { name } =>
                write!(f, "'{}' 이미 존재", name),
            ZooError::NotFound { name } =>
                write!(f, "'{}' 찾을 수 없음", name),
        }
    }
}

// 이름 검증
fn validate_name(name: &str) -> Result<(), ZooError> {
    if name.chars().count() < 2 {
        Err(ZooError::NameTooShort { name: name.to_string() })
    } else {
        Ok(())
    }
}

// 나이 검증
fn validate_age(name: &str, age: u32) -> Result<(), ZooError> {
    if age > Lion::MAX_AGE {
        Err(ZooError::AgeOutOfRange { name: name.to_string(), age, max: Lion::MAX_AGE })
    } else {
        Ok(())
    }
}

// ? 연산자 — 두 검증을 체이닝
// 반환 타입이 Result이므로 ? 사용 가능
fn create_lion(name: &str, age: u32) -> Result<Lion, ZooError> {
    validate_name(name)?;   // Err면 즉시 반환
    validate_age(name, age)?;  // Err면 즉시 반환
    Ok(Lion::new(name, age))
}

// 복수 연산을 ? 로 체이닝
fn register_and_feed(name: &str, age: u32) -> Result<String, ZooError> {
    let mut lion = create_lion(name, age)?;  // 실패 시 즉시 반환
    lion.feed();
    Ok(format!("{} 등록 및 급식 완료", lion.name()))
}

// Box<dyn Error> — 여러 에러 타입을 하나로
fn parse_age(s: &str) -> Result<u32, Box<dyn std::error::Error>> {
    let age: u32 = s.trim().parse()?;  // ParseIntError → Box<dyn Error>
    Ok(age)
}

// impl Error — ZooError를 std::error::Error trait으로 구현
impl std::error::Error for ZooError {}

pub fn run() {
    println!("\n─── Part 6-3: Result<T, E> ───");

    // 기본 Ok / Err
    println!("\n  [Ok / Err 기본]");
    let ok:  Result<Lion, ZooError> = Ok(Lion::new("Simba", 5));
    let err: Result<Lion, ZooError> = Err(ZooError::NotFound { name: "Ghost".into() });
    println!("  ok.is_ok():   {}", ok.is_ok());
    println!("  err.is_err(): {}", err.is_err());

    // create_lion — ? 연산자 체이닝
    println!("\n  [? 연산자 — 검증 체이닝]");
    let cases = vec![
        ("Simba", 5u32),
        ("X", 3),        // 이름 너무 짧음
        ("Ancient", 99), // 나이 초과
        ("Nala", 4),
    ];
    for (name, age) in &cases {
        match create_lion(name, *age) {
            Ok(lion)  => println!("  ✅ 생성 성공: {}", lion.status()),
            Err(e)    => println!("  ❌ 생성 실패: {}", e),
        }
    }

    // map / map_err / and_then
    println!("\n  [map / and_then]");
    let status = create_lion("Mufasa", 10)
        .map(|l| l.status());              // Ok(Lion) → Ok(String)
    println!("  map 결과: {:?}", status);

    let hungry_result = create_lion("Nala", 4)
        .and_then(|l| {                    // Ok(Lion) → Result<bool, ZooError>
            if l.is_hungry() { Ok(true) }
            else             { Err(ZooError::NotFound { name: "배고픔".into() }) }
        });
    println!("  and_then 결과: {:?}", hungry_result);

    // unwrap_or_else
    println!("\n  [unwrap_or_else]");
    let lion = create_lion("Ghost", 99)
        .unwrap_or_else(|e| {
            println!("  에러 처리 중: {}", e);
            Lion::new("기본 사자", 0)
        });
    println!("  fallback: {}", lion.name());

    // register_and_feed — ? 체이닝
    println!("\n  [register_and_feed — ? 체이닝]");
    match register_and_feed("Simba", 5) {
        Ok(msg)  => println!("  ✅ {}", msg),
        Err(e)   => println!("  ❌ {}", e),
    }
    match register_and_feed("X", 5) {
        Ok(msg)  => println!("  ✅ {}", msg),
        Err(e)   => println!("  ❌ {}", e),
    }

    // parse_age — Box<dyn Error>
    println!("\n  [Box<dyn Error> — 여러 에러 타입 통합]");
    for s in &["5", "abc", " 10 "] {
        match parse_age(s) {
            Ok(n)  => println!("  '{}' → 나이 {}", s, n),
            Err(e) => println!("  '{}' → 파싱 실패: {}", s, e),
        }
    }

    // if let Err / Ok
    println!("\n  [if let Err]");
    if let Err(e) = create_lion("Z", 1) {
        println!("  예상된 에러: {}", e);
    }
}
