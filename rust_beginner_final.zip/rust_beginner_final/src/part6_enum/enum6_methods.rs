// ┌───────────────────────────────────────────────────────────────────────┐
// │  Part 6-4.  enum에 impl 붙이기                                         │
// │                                                                       │
// │  struct 처럼 enum에도 impl 블록을 붙일 수 있다.                          │
// │  trait을 구현할 수도 있다.                                              │
// └───────────────────────────────────────────────────────────────────────┘
use std::fmt;

#[derive(Debug, Clone, PartialEq)]
pub enum AnimalStatus {
    Healthy,
    Sick    { disease: String },
    Hungry  { days_without_food: u32 },
    Retired { reason: String },
}

impl AnimalStatus {
    // 연관 함수
    pub fn default_healthy() -> Self { AnimalStatus::Healthy }

    // &self 메서드
    pub fn is_ok(&self) -> bool {
        matches!(self, AnimalStatus::Healthy)
    }

    pub fn needs_attention(&self) -> bool {
        matches!(self, AnimalStatus::Sick { .. } | AnimalStatus::Hungry { .. })
    }

    pub fn priority(&self) -> u32 {
        match self {
            AnimalStatus::Healthy                     => 0,
            AnimalStatus::Hungry { days_without_food }=> *days_without_food,
            AnimalStatus::Sick   { .. }               => 100,
            AnimalStatus::Retired{ .. }               => 0,
        }
    }

    pub fn description(&self) -> String {
        match self {
            AnimalStatus::Healthy                      => "건강".to_string(),
            AnimalStatus::Sick { disease }             => format!("아픔: {}", disease),
            AnimalStatus::Hungry { days_without_food } => format!("굶은 지 {}일", days_without_food),
            AnimalStatus::Retired { reason }           => format!("은퇴: {}", reason),
        }
    }
}

impl fmt::Display for AnimalStatus {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "[{}]", self.description())
    }
}

// enum에 trait 구현
pub trait Urgency {
    fn is_urgent(&self) -> bool;
    fn urgency_level(&self) -> &'static str;
}

impl Urgency for AnimalStatus {
    fn is_urgent(&self) -> bool {
        self.priority() >= 50
    }
    fn urgency_level(&self) -> &'static str {
        match self.priority() {
            0       => "정상",
            1..=2   => "낮음",
            3..=9   => "보통",
            10..=99 => "높음",
            _       => "위급",
        }
    }
}

pub fn run() {
    println!("\n─── Part 6-4: enum에 impl ───");

    let statuses = vec![
        AnimalStatus::Healthy,
        AnimalStatus::Sick { disease: "감기".to_string() },
        AnimalStatus::Hungry { days_without_food: 3 },
        AnimalStatus::Retired { reason: "고령".to_string() },
    ];

    for s in &statuses {
        println!("  {} | ok:{} | 주의:{} | 우선순위:{} | 긴급:{}({})",
            s,
            s.is_ok(),
            s.needs_attention(),
            s.priority(),
            s.is_urgent(),
            s.urgency_level(),
        );
    }

    // matches! 매크로
    println!("\n  [matches! 매크로]");
    let s = AnimalStatus::Hungry { days_without_food: 5 };
    println!("  Hungry: {}", matches!(s, AnimalStatus::Hungry { .. }));
    println!("  Sick or Hungry: {}",
        matches!(s, AnimalStatus::Sick { .. } | AnimalStatus::Hungry { .. }));
}
