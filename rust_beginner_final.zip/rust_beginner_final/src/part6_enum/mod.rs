// ╔═══════════════════════════════════════════════════════════════════════╗
// ║  Part 6.  enum 완전 가이드                                             ║
// ║                                                                       ║
// ║  Rust의 enum은 대수적 데이터 타입(algebraic data type)이다.             ║
// ║  공식 Book ch6 기반.                                                   ║
// ║                                                                       ║
// ║  enum6_basic    — 기본 enum, unit/tuple/struct variant                 ║
// ║  enum6_option   — Option<T>: Some, None, 메서드들                     ║
// ║  enum6_result   — Result<T,E>: Ok, Err, ? 연산자                      ║
// ║  enum6_methods  — enum에 impl 붙이기                                   ║
// ╚═══════════════════════════════════════════════════════════════════════╝

pub mod enum6_basic;
pub mod enum6_option;
pub mod enum6_result;
pub mod enum6_methods;

pub fn run() {
    println!("\n══════════════════════════════════════════════════════════");
    println!(" Part 6: enum 완전 가이드");
    println!("══════════════════════════════════════════════════════════");
    enum6_basic::run();
    enum6_option::run();
    enum6_result::run();
    enum6_methods::run();
    enum_advanced::run();
    enum6_question::run();
}
pub mod enum_advanced;
pub mod enum6_question;
